# Thermal Mapping Analysis

An internal-network Flask application for maintaining Data Logger and Fluke SuperDAQ sensor calibration records, validating study time series, calculating results, and generating Excel reports.

## Verification Boundary

The supplied `Report_Table.xls` was inspected directly. It has one worksheet (`Sheet1`), report metadata above a table header on row 12, columns for ID, Date/time, Temperature, and Humidity, and the instrument identifier `DL001`. The file contains 673 readings from 2025-04-06 16:56 through 2025-04-13 16:56, exactly 15 minutes apart, with no duplicate timestamps or missing temperature/RH values. Logger text timestamps use `MM/DD/YYYY hh:mm:ss AM/PM`; zero-padded and unpadded month/day/hour values are accepted, and Excel-native timestamp cells are also supported.

The supplied `dat00001.xlsx` SuperDAQ export was also inspected directly. Its `dat00001` worksheet has 1,478 rows, an Excel-native `Time` column, and 21 channel columns with headers such as `Ch 101 (C)` and `Ch 120 (C)`. The importer preserves those full header strings for exact sensor-kit matching and does not infer channel assignment from order or sensor serial number. Values are passed to the existing validation and analysis path without automatic invalid/disconnected reading removal.

No calibration certificate examples were supplied. Each certificate channel therefore requires an explicit `Indication + correction` or `Indication - correction` setting. The setting is never inferred from correction signs. The sign convention must be compared with actual certificate wording before operational approval.

The calculation, validation, importer, report, SQLite, backup, and lock behavior have automated local tests. This project has not been installed or qualified on the laboratory server. It is not ready for routine laboratory release until any additional Data Logger export format, actual certificate convention examples, and laboratory acceptance tests have been verified.

## Cloud preparation

The application supports SQLite for local development and PostgreSQL through `DATABASE_URL` for production. The PostgreSQL driver is included in `requirements.txt`; the analysis engine does not depend on the database backend. Set `DATABASE_URL` to the Neon connection string and set `THERMAL_MAPPING_SECRET` or `SECRET_KEY` to a long secret. Render supplies `PORT`, which `run.py` uses automatically.

The shared master database contains users, equipment, calibration data, SuperDAQ kits and sensors, settings, calibration history, and administrative audit entries. Study uploads are processed in per-request temporary directories under `instance/temporary_uploads`; preview files are cleaned after export and abandoned temporary entries older than 24 hours are removed at request time. Study results and reports are not written to the database or permanent cloud storage; reports are returned as browser downloads.

To migrate an existing SQLite master database to an already-created Neon database:

```powershell
python -m thermal_mapping.migrate_db `
  --source "instance\thermal_mapping.sqlite3" `
  --target "$env:DATABASE_URL"
```

The migration is additive and uses conflict-safe inserts. Keep the SQLite source unchanged and verify record counts and representative calibration points before switching production traffic. Do not migrate temporary uploads, study files, or generated reports.

Both authenticated roles can create new equipment, kits, sensors, and calibration records. New records are validated and published immediately without storing the submitting user's identity. Only Admins can modify or delete existing master records, change settings, or manage users. Historical calibration snapshots are retained when an existing record is changed, and Admin changes are recorded in the audit log.

## Requirements

- Windows Server or Windows workstation inside the laboratory LAN.
- Python 3.10 or later. Local development verification used Python 3.13.5.
- A local disk location for the SQLite database and application instance files.
- A server-accessible local or UNC report destination.
- Windows Firewall access limited to the laboratory's private network.

Normal operation uses no cloud service, external authentication, or internet-hosted assets. Authentication is local to the SQLite database. The application does not retain completed studies or rejected-file history. Temporary uploads are removed after each request.

## Windows Installation

Open PowerShell in the project directory:

```powershell
py -3.13 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

Set the server paths before initializing the database. Keep the database on the server's local disk, not on the report share:

```powershell
$env:THERMAL_MAPPING_SECRET = "replace-with-a-long-random-value"
$env:THERMAL_MAPPING_DATABASE = "C:\ThermalMapping\instance\thermal_mapping.sqlite3"
$env:THERMAL_MAPPING_LOCK = "C:\ThermalMapping\instance\analysis.lock"
$env:THERMAL_MAPPING_HOST = "0.0.0.0"
$env:THERMAL_MAPPING_PORT = "8080"
$env:THERMAL_MAPPING_INITIAL_ADMIN_USERNAME = "admin"
$env:THERMAL_MAPPING_INITIAL_ADMIN_PASSWORD = "use-a-unique-password-of-at-least-12-characters"
$env:THERMAL_MAPPING_SESSION_TIMEOUT_MINUTES = "30"
python -m thermal_mapping.init_db
```

On the first initialization of an empty database, the initial-admin variables create one active Admin account. They never overwrite an existing user or Admin. Keep the password out of source control and set it in the Windows service account environment. After signing in, use **Users** to create operational User accounts and additional Admin accounts.

Every page and state-changing request requires an authenticated active account. Users can run studies, view registry information, import study files, and export reports. Only Admin accounts can change calibration/device records, manage SuperDAQ registry data, change settings, create backups, or manage users. Sessions expire after the configured inactivity timeout, and deactivated accounts are rejected on the next request. Login and state-changing forms use CSRF tokens.

The matching non-secret variable names are listed in [`config.example.env`](config.example.env). That file is an example and is not automatically loaded; configure the variables in the Windows account or service environment that launches the application.

Set the report output directory in **Settings** to the approved local or UNC destination. The application will fail clearly if the directory is missing or inaccessible; it does not save to a fallback location.

Run tests and start the LAN server:

```powershell
python -m pytest -q
python run.py
```

Browse to `http://<server-hostname-or-IP>:8080`. Waitress binds to all interfaces by default. Restrict inbound port 8080 in Windows Firewall to the laboratory's private network. Do not expose this unauthenticated internal application to the public internet. For multi-computer deployment, run one application process; it serves concurrent browser requests with threads and uses an OS-managed lock file so only one analysis can run at a time.

For an unattended launch, use the laboratory's approved Windows service manager or Task Scheduler configured with the same working directory, Python environment, and environment variables. Stop the process cleanly before replacing the database or application files. No service wrapper is included in this project.

## Routine Use

1. Use **Import from Excel** on the Data Loggers page for a first-time logger registry import, or add loggers individually. The import preview groups temperature and RH correction points by equipment code; resolve every reported issue and select the existing correction convention for each instrument/channel before committing. The import requires full calibration dates, matches correction rows only by the code embedded in `Indication`, and never overwrites existing equipment. Future changes are made manually. For a first-time SuperDAQ import, open **SuperDAQ Kits** → **Import from Excel** and select the workbook containing **Equipment details** and **corrections**. The preview matches each correction by kit serial number and exact channel identifier, shows every sensor and its points, and imports the temperature convention as **Indication + correction**. The import never overwrites existing kit or sensor data; an exact re-import is a no-op. Later changes are made manually. SuperDAQ kits and sensors can also be added individually. Registry records can be removed from their list pages; removing a kit also removes its registered sensors.
2. Use **Update Calibration Certificate** to enter the latest certificate dates, traceability, correction points, and certificate-defined sign convention. An incomplete record remains visible but is not selectable for the affected analysis channel.
3. Configure the report destination in Settings.
4. Prepare a study with explicit start/end timestamps, interval, analysis mode, limits, files, and unique equipment assignments. Select **Data Logger** to retain the existing workflow, or **Fluke SuperDAQ** to upload one `.xlsx` export, select a registered kit, and map each detected channel to at most one sensor from that kit. SuperDAQ studies are temperature-only.
	When files are selected, the application reads each embedded Data Logger code and automatically selects the matching complete registry record. Unmatched or incomplete identifiers are flagged in that file's row; temporary identification uploads are removed after matching.
5. The server validates every assigned file and the entire configured time grid before calculating any results. If a requested study boundary falls between readings, it rounds up to the next timestamp shared by all assigned Data Loggers or mapped SuperDAQ channels. The sampling interval is inferred from the first two readings, rounded to the nearest whole minute, and must be consistent across assigned channels. The verified Data Logger format uses an exact timestamp grid; verified SuperDAQ exports may contain sub-minute timestamp jitter and are validated using their actual readings within the selected window. The requested and effective boundaries are both recorded in the report. A boundary after the recorded range rejects the complete study.
6. Calibration extrapolation is permitted and reported with its channel, indication, and calibrated range. Time-series gaps are never filled.
7. Expired certificates require an explicit confirmation showing the Data Logger or sensor code, serial number when recorded, and due date. Confirmation does not imply metrological suitability.
8. After successful analysis, review the **Results Preview** table and interactive temperature, humidity (when selected), and MKT charts. Select individual sensors in each chart legend to show or hide them. Use **Save to Excel** to choose the report name and destination folder; the workbook retains the existing summary sheets and adds one detailed corrected-reading worksheet with a time-series chart for each included logger or sensor. **Back to Study** retains the calculated preview without recalculating, and **Finish** returns to the dashboard.

The report's `MKT (°C)` column is the corrected arithmetic average required for compatibility with the existing laboratory heading; it is not pharmaceutical Mean Kinetic Temperature. Standard deviation uses the sample formula (`n - 1`). Time outside limits is accumulated by sampling interval, clipped to the configured study window, and uses the study duration as the percentage denominator. Limits are inclusive.

Study input timestamps and report generation use the Windows server's local timezone. Configure and document the server timezone before routine use.

## Manual Backup and Restore

Backups are manual only. In the application, open **Settings** and select **Create Manual Backup**. A transactionally consistent SQLite backup is written under the configured instance folder's `backups` directory. Copy that backup to the laboratory's approved backup storage. Also record the non-secret deployment settings and separately protect the `THERMAL_MAPPING_SECRET`; do not put secrets in source control.

To restore:

1. Stop the application process or Windows task/service.
2. Copy the chosen backup to the configured database path. Remove any stale `-wal` and `-shm` files beside the database only after the application has stopped.
3. Restore the environment settings and report destination configuration.
4. Verify the restored database before restarting:

```powershell
python -c "import sqlite3,sys; c=sqlite3.connect(sys.argv[1]); print(c.execute('PRAGMA integrity_check').fetchone()[0]); c.close()" "$env:THERMAL_MAPPING_DATABASE"
```

The expected output is `ok`. Start the application and verify the equipment registry and Settings page. Reports are written separately to the configured report destination; the application database is not a completed-study archive.

## Test Coverage

The automated suite includes deterministic synthetic calculation tests and, when the supplied workbooks are available beside the project, integration tests against both the real `.xls` Data Logger sample and the real `.xlsx` SuperDAQ export. It covers Excel equipment/correction preview, exact code matching, variable calibration points, import idempotency, correction interpolation/extrapolation and sign conventions, exact SuperDAQ channel mapping, sensor-kit isolation, temperature-only reports, strict time grids, missing timestamps, pooled means, sample standard deviation, inclusive limits, clipped exceedance durations, report contents/naming, equipment persistence, manual database backup, and analysis-lock exclusion/recovery.

Any additional Data Logger export format, actual calibration-certificate sign conventions, LAN multi-client deployment, and laboratory-server qualification remain unverified pending the required laboratory inputs and environment.