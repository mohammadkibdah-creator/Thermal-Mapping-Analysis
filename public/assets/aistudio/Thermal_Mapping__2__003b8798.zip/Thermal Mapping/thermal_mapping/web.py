from __future__ import annotations

import json
import math
import os
import re
import secrets
import sqlite3
import tempfile
from datetime import date, datetime
from pathlib import Path

from flask import Flask, abort, flash, g, jsonify, redirect, render_template, request, send_file, session, url_for

from . import __version__
from .analysis import (
    AssignedLogger,
    StudyValidationError,
    analyze_study,
    infer_sampling_interval_minutes,
    snap_study_boundaries,
)
from .analysis_lock import AnalysisAlreadyRunning, analysis_lock
from .auth import (
    SESSION_USER_ID,
    csrf_token,
    login_user,
    logout_user,
    password_hash,
    password_matches,
    session_is_expired,
    touch_session,
    validate_csrf,
)
from .calibration import CalibrationCurve, CalibrationError
from .domain import (
    AnalysisMode,
    ChannelLimits,
    ChannelResult,
    CorrectionConvention,
    CorrectionPoint,
    LoggerResult,
    LoggerSeries,
    ParsedFile,
    StudyResults,
)
from .equipment_import import EquipmentImportPreview, parse_equipment_workbook
from .importers import (
    ReportTableImportError,
    SuperDAQImportError,
    import_data_file,
    import_superdaq_file,
)
from .reports import LoggerReportSnapshot, generate_report
from .storage import (
    connect,
    count_active_admins,
    create_user as create_user_record,
    create_sensor_kit,
    delete_equipment,
    delete_sensor_kit,
    delete_superdaq_sensor,
    get_equipment,
    get_equipment_many,
    get_settings,
    get_user,
    get_user_by_username,
    initialize_database,
    INTEGRITY_ERRORS,
    is_postgresql,
    list_equipment,
    get_sensor_kit,
    get_superdaq_sensor,
    get_superdaq_sensors_many,
    import_superdaq_kit,
    list_sensor_kits,
    list_users,
    list_superdaq_sensors,
    parse_points,
    record_audit,
    save_equipment,
    save_new_equipment_many,
    save_settings,
    save_sensor_kit,
    save_superdaq_sensor,
    set_username,
    set_user_active,
    set_user_password,
    update_user_login,
)
from .superdaq_equipment_import import (
    parse_superdaq_equipment_workbook,
    registry_import_status,
)


def _persistent_secret_key(instance_path: str | Path) -> str:
    key_path = Path(instance_path) / "secret.key"
    try:
        key = key_path.read_text(encoding="ascii").strip() if key_path.is_file() else ""
        if not key:
            key = secrets.token_hex(32)
            key_path.parent.mkdir(parents=True, exist_ok=True)
            key_path.write_text(key, encoding="ascii")
        return key
    except OSError as exc:
        raise RuntimeError(f"Unable to create or read the application secret key at {key_path}.") from exc


def _cleanup_temporary_uploads(instance_path: str | Path, max_age_hours: int = 24) -> None:
    directory = Path(instance_path) / "temporary_uploads"
    if not directory.is_dir():
        return
    cutoff = datetime.now().timestamp() - max_age_hours * 3600
    for item in directory.iterdir():
        try:
            if item.stat().st_mtime < cutoff:
                if item.is_dir():
                    import shutil
                    shutil.rmtree(item)
                else:
                    item.unlink()
        except OSError:
            continue


def _audit_actor() -> str:
    user = getattr(g, "current_user", None)
    return user["username"] if user else "test-mode"


def _parse_point_fields(form, field: str, channel: str) -> tuple[CorrectionPoint, ...]:
    points: list[CorrectionPoint] = []
    indications = form.getlist(f"{field}_indication")
    corrections = form.getlist(f"{field}_correction")
    if len(indications) != len(corrections):
        raise ValueError(f"{channel} correction rows are incomplete.")
    for row_number, (indication_text, correction_text) in enumerate(zip(indications, corrections), 1):
        indication_text = indication_text.strip()
        correction_text = correction_text.strip()
        if not indication_text and not correction_text:
            continue
        if not indication_text or not correction_text:
            raise ValueError(f"{channel} correction row {row_number} is missing a required value.")
        try:
            points.append(CorrectionPoint(float(indication_text), float(correction_text)))
        except ValueError as exc:
            raise ValueError(f"{channel} correction row {row_number} contains a non-numeric value.") from exc
    if any(not math.isfinite(point.indication) or not math.isfinite(point.correction) for point in points):
        raise ValueError(f"{channel} correction values must be finite numbers.")
    if len(points) >= 2:
        CalibrationCurve(points, CorrectionConvention.INDICATION_PLUS_CORRECTION)
    return tuple(points)


def _points_json(points: tuple[CorrectionPoint, ...]) -> str:
    return json.dumps([{"indication": p.indication, "correction": p.correction} for p in points])


def _point_rows(value: str) -> list[dict[str, str]]:
    try:
        return [
            {"indication": str(item["indication"]), "correction": str(item["correction"])}
            for item in parse_points(value)
        ]
    except (ValueError, KeyError, TypeError):
        return []


def _submitted_point_rows(form, field: str) -> list[dict[str, str]]:
    indications = form.getlist(f"{field}_indication")
    corrections = form.getlist(f"{field}_correction")
    row_count = max(len(indications), len(corrections))
    return [
        {
            "indication": indications[index] if index < len(indications) else "",
            "correction": corrections[index] if index < len(corrections) else "",
        }
        for index in range(row_count)
    ]


def _curves_from_record(record: dict, mode: AnalysisMode) -> tuple[CalibrationCurve, CalibrationCurve | None]:
    if not record["description"].strip() or not record["serial_number"].strip() or not record["traceability"].strip():
        raise ValueError(f"Data Logger {record['equipment_code']}: description, serial number, and traceability are required.")
    try:
        calibration_date = date.fromisoformat(record["calibration_date"])
        due_date = date.fromisoformat(record["due_date"])
    except ValueError as exc:
        raise ValueError(f"Data Logger {record['equipment_code']}: valid calibration and due dates are required.") from exc
    if due_date < calibration_date:
        raise ValueError(f"Data Logger {record['equipment_code']}: calibration due date precedes calibration date.")
    if not record["temperature_enabled"]:
        raise ValueError(f"Data Logger {record['equipment_code']}: temperature channel is not enabled.")
    if not record["temperature_convention"]:
        raise ValueError(f"Data Logger {record['equipment_code']}: temperature correction convention is not configured.")
    try:
        temperature_points = [CorrectionPoint(**item) for item in parse_points(record["temperature_points_json"])]
        temperature_curve = CalibrationCurve(temperature_points, CorrectionConvention(record["temperature_convention"]))
    except (ValueError, KeyError, TypeError) as exc:
        raise ValueError(f"Data Logger {record['equipment_code']}: temperature calibration is incomplete: {exc}") from exc

    humidity_curve = None
    if mode is AnalysisMode.TEMPERATURE_AND_HUMIDITY:
        if not record["humidity_enabled"]:
            raise ValueError(f"Data Logger {record['equipment_code']}: relative humidity channel is not enabled.")
        if not record["humidity_convention"]:
            raise ValueError(f"Data Logger {record['equipment_code']}: RH correction convention is not configured.")
        try:
            humidity_points = [CorrectionPoint(**item) for item in parse_points(record["humidity_points_json"])]
            humidity_curve = CalibrationCurve(humidity_points, CorrectionConvention(record["humidity_convention"]))
        except (ValueError, KeyError, TypeError) as exc:
            raise ValueError(f"Data Logger {record['equipment_code']}: RH calibration is incomplete: {exc}") from exc
    return temperature_curve, humidity_curve


def _temperature_curve_from_sensor(record: dict) -> CalibrationCurve:
    if not record["name"].strip() or not record["channel_identifier"].strip():
        raise ValueError(
            f"SuperDAQ sensor {record['sensor_code']}: name and channel identifier are required."
        )
    if not record["traceability"].strip():
        raise ValueError(f"SuperDAQ sensor {record['sensor_code']}: traceability is required.")
    try:
        calibration_date = date.fromisoformat(record["calibration_date"])
        due_date = date.fromisoformat(record["due_date"])
    except ValueError as exc:
        raise ValueError(
            f"SuperDAQ sensor {record['sensor_code']}: valid calibration and due dates are required."
        ) from exc
    if due_date < calibration_date:
        raise ValueError(
            f"SuperDAQ sensor {record['sensor_code']}: calibration due date precedes calibration date."
        )
    if not record["temperature_convention"]:
        raise ValueError(
            f"SuperDAQ sensor {record['sensor_code']}: temperature correction convention is not configured."
        )
    try:
        points = [CorrectionPoint(**item) for item in parse_points(record["temperature_points_json"])]
        return CalibrationCurve(points, CorrectionConvention(record["temperature_convention"]))
    except (ValueError, KeyError, TypeError) as exc:
        raise ValueError(
            f"SuperDAQ sensor {record['sensor_code']}: temperature calibration is incomplete: {exc}"
        ) from exc


def _equipment_import_preview_data(preview: EquipmentImportPreview) -> dict:
    counts = {item["equipment_code"]: item for item in preview.counts}
    return {
        "equipment": [
            {
                **record,
                "temperature_points": preview.points.get(record["equipment_code"], {}).get(
                    "temperature", ()
                ),
                "humidity_points": preview.points.get(record["equipment_code"], {}).get(
                    "relative_humidity", ()
                ),
                "temperature_count": counts.get(record["equipment_code"], {}).get(
                    "temperature", 0
                ),
                "humidity_count": counts.get(record["equipment_code"], {}).get(
                    "relative_humidity", 0
                ),
            }
            for record in preview.equipment
        ],
        "issues": preview.issues,
        "can_import": preview.can_import,
    }


def _device_status(record: dict) -> str:
    if not _channel_eligible(record, AnalysisMode.TEMPERATURE):
        return "Incomplete"
    if record["humidity_enabled"] and not _channel_eligible(record, AnalysisMode.TEMPERATURE_AND_HUMIDITY):
        return "Incomplete"
    return "Complete"


def _certificate_expired(record: dict) -> bool:
    try:
        return date.fromisoformat(record["due_date"]) < date.today()
    except ValueError:
        return False


def _channel_eligible(record: dict, mode: AnalysisMode) -> bool:
    try:
        _curves_from_record(record, mode)
    except ValueError:
        return False
    return True


def _preview_directory(app: Flask) -> Path:
    directory = Path(app.instance_path) / "temporary_uploads"
    directory.mkdir(parents=True, exist_ok=True)
    return directory


def _preview_path(app: Flask, token: str) -> Path:
    if not re.fullmatch(r"[A-Za-z0-9_-]{32}", token):
        raise ValueError("Invalid preview reference.")
    return _preview_directory(app) / f"preview_{token}.json"


def _result_channel_payload(result: ChannelResult) -> dict[str, float]:
    return {
        "mean": result.mean,
        "minimum": result.minimum,
        "maximum": result.maximum,
        "sample_standard_deviation": result.sample_standard_deviation,
        "below_minutes": result.below_minutes,
        "below_percent": result.below_percent,
        "above_minutes": result.above_minutes,
        "above_percent": result.above_percent,
    }


def _preview_payload(
    *,
    study_name: str,
    start: datetime,
    end: datetime,
    requested_start: datetime,
    requested_end: datetime,
    sampling_interval_minutes: int,
    mode: AnalysisMode,
    temperature_limits: ChannelLimits,
    humidity_limits: ChannelLimits | None,
    snapshots: tuple[LoggerReportSnapshot, ...],
    results: StudyResults,
    warnings: tuple[str, ...],
    expired_certificate_confirmed: bool,
    acquisition_system: str,
    sensor_kit: str,
) -> dict:
    return {
        "study_name": study_name,
        "start": start.isoformat(),
        "end": end.isoformat(),
        "requested_start": requested_start.isoformat(),
        "requested_end": requested_end.isoformat(),
        "sampling_interval_minutes": sampling_interval_minutes,
        "mode": mode.value,
        "temperature_limits": {"lower": temperature_limits.lower, "upper": temperature_limits.upper},
        "humidity_limits": (
            {"lower": humidity_limits.lower, "upper": humidity_limits.upper}
            if humidity_limits else None
        ),
        "warnings": list(warnings),
        "expired_certificate_confirmed": expired_certificate_confirmed,
        "acquisition_system": acquisition_system,
        "sensor_kit": sensor_kit,
        "snapshots": [
            {
                "equipment_code": item.equipment_code,
                "description": item.description,
                "serial_number": item.serial_number,
                "traceability": item.traceability,
                "calibration_date": item.calibration_date,
                "due_date": item.due_date,
                "temperature_points": [point.__dict__ for point in item.temperature_points],
                "temperature_convention": item.temperature_convention.value,
                "humidity_points": [point.__dict__ for point in item.humidity_points],
                "humidity_convention": item.humidity_convention.value if item.humidity_convention else None,
                "source_channel": item.source_channel,
                "position": item.position,
                "certificate_number": item.certificate_number,
                "provider": item.provider,
                "sensor_name": item.sensor_name,
            }
            for item in snapshots
        ],
        "results": {
            "logger_results": [
                {
                    "equipment_code": item.equipment_code,
                    "temperature": _result_channel_payload(item.temperature),
                    "humidity": _result_channel_payload(item.humidity) if item.humidity else None,
                }
                for item in results.logger_results
            ],
            "global_temperature_mean": results.global_temperature_mean,
            "global_humidity_mean": results.global_humidity_mean,
            "warnings": list(results.warnings),
            "series": [
                {
                    "equipment_code": item.equipment_code,
                    "timestamps": [timestamp.isoformat() for timestamp in item.timestamps],
                    "temperatures": list(item.temperatures),
                    "humidities": list(item.humidities),
                    "original_temperatures": list(item.original_temperatures),
                    "temperature_corrections": list(item.temperature_corrections),
                    "original_humidities": list(item.original_humidities),
                    "humidity_corrections": list(item.humidity_corrections),
                }
                for item in results.series
            ],
        },
    }


def _write_preview(app: Flask, payload: dict) -> str:
    token = secrets.token_urlsafe(24).replace("-", "_").replace("~", "_")
    path = _preview_path(app, token)
    path.write_text(json.dumps(payload), encoding="utf-8")
    return token


def _read_preview(app: Flask, token: str) -> dict:
    path = _preview_path(app, token)
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise ValueError("This results preview is no longer available. Run the study again.") from exc
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError("The results preview could not be read. Run the study again.") from exc


def _channel_result(data: dict | None) -> ChannelResult | None:
    if data is None:
        return None
    return ChannelResult(**data)


def _preview_results(payload: dict) -> StudyResults:
    result_data = payload["results"]
    return StudyResults(
        logger_results=tuple(
            LoggerResult(
                item["equipment_code"],
                _channel_result(item["temperature"]),
                _channel_result(item["humidity"]),
            )
            for item in result_data["logger_results"]
        ),
        global_temperature_mean=result_data["global_temperature_mean"],
        global_humidity_mean=result_data["global_humidity_mean"],
        warnings=tuple(result_data["warnings"]),
        series=tuple(
            LoggerSeries(
                item["equipment_code"],
                tuple(datetime.fromisoformat(value) for value in item["timestamps"]),
                tuple(item["temperatures"]),
                tuple(item["humidities"]),
                tuple(item.get("original_temperatures", ())),
                tuple(item.get("temperature_corrections", ())),
                tuple(item.get("original_humidities", ())),
                tuple(item.get("humidity_corrections", ())),
            )
            for item in result_data["series"]
        ),
    )


def _preview_snapshots(payload: dict) -> tuple[LoggerReportSnapshot, ...]:
    return tuple(
        LoggerReportSnapshot(
            equipment_code=item["equipment_code"],
            description=item["description"],
            serial_number=item["serial_number"],
            traceability=item["traceability"],
            calibration_date=item["calibration_date"],
            due_date=item["due_date"],
            temperature_points=tuple(CorrectionPoint(**point) for point in item["temperature_points"]),
            temperature_convention=CorrectionConvention(item["temperature_convention"]),
            humidity_points=tuple(CorrectionPoint(**point) for point in item["humidity_points"]),
            humidity_convention=(
                CorrectionConvention(item["humidity_convention"])
                if item["humidity_convention"] else None
            ),
            source_channel=item["source_channel"],
            position=item["position"],
            certificate_number=item["certificate_number"],
            provider=item["provider"],
            sensor_name=item["sensor_name"],
        )
        for item in payload["snapshots"]
    )


def create_app(config: dict | None = None) -> Flask:
    instance_path = config.get("INSTANCE_PATH") if config else None
    app = Flask(
        __name__,
        instance_relative_config=True,
        instance_path=instance_path,
        template_folder="../templates",
        static_folder="../static",
    )
    app.config.update(
        SECRET_KEY=(
            os.environ.get("SECRET_KEY")
            or os.environ.get("THERMAL_MAPPING_SECRET")
            or _persistent_secret_key(app.instance_path)
        ),
        DATABASE=(
            os.environ.get("DATABASE_URL")
            or os.environ.get("THERMAL_MAPPING_DATABASE")
            or str(Path(app.instance_path) / "thermal_mapping.sqlite3")
        ),
        ANALYSIS_LOCK=os.environ.get("THERMAL_MAPPING_LOCK") or str(Path(app.instance_path) / "analysis.lock"),
        SESSION_TIMEOUT_MINUTES=int(os.environ.get("THERMAL_MAPPING_SESSION_TIMEOUT_MINUTES", "30")),
        AUTH_DISABLED=False,
        MAX_CONTENT_LENGTH=128 * 1024 * 1024,
    )
    if config:
        app.config.update(config)
    if not config or "AUTH_DISABLED" not in config:
        app.config["AUTH_DISABLED"] = bool(app.config.get("TESTING", False))
    Path(app.instance_path).mkdir(parents=True, exist_ok=True)
    initialize_database(app.config["DATABASE"])
    initial_username = os.environ.get("THERMAL_MAPPING_INITIAL_ADMIN_USERNAME", "").strip()
    initial_password = os.environ.get("THERMAL_MAPPING_INITIAL_ADMIN_PASSWORD", "")
    if initial_username and initial_password and not list_users(app.config["DATABASE"]):
        create_user_record(app.config["DATABASE"], initial_username, password_hash(initial_password), "Admin")
    app.config.update(
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=bool(app.config.get("SESSION_COOKIE_SECURE", False)),
        SESSION_COOKIE_NAME="thermal_mapping_session",
        PERMANENT_SESSION_LIFETIME=app.config["SESSION_TIMEOUT_MINUTES"] * 60,
    )

    @app.get("/branding/RSS_JNMI_Lock-Up.png")
    def institutional_logo():
        logo_path = Path(app.root_path).parent / "RSS_JNMI_Lock-Up.png"
        if not logo_path.is_file():
            abort(404)
        return send_file(logo_path, mimetype="image/png", max_age=3600)

    def database_path() -> str:
        return app.config["DATABASE"]

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if request.method == "POST":
            validate_csrf()
            username = request.form.get("username", "").strip()
            user = get_user_by_username(database_path(), username)
            if not user or not user["is_active"] or not password_matches(user["password_hash"], request.form.get("password", "")):
                flash("Invalid username or password.", "error")
            else:
                login_user(user)
                update_user_login(database_path(), user["user_id"])
                destination = request.args.get("next", "")
                return redirect(
                    destination
                    if destination.startswith("/") and not destination.startswith("//")
                    else url_for("dashboard")
                )
        return render_template("login.html")

    @app.post("/logout")
    def logout():
        validate_csrf()
        logout_user()
        return redirect(url_for("login"))

    @app.get("/users")
    def user_management():
        return render_template("users.html", users=list_users(database_path()))

    @app.post("/users/new")
    def create_user():
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        role = request.form.get("role", "User")
        if len(username) < 3 or len(password) < 12 or role not in {"Admin", "User"}:
            flash("Usernames require at least 3 characters and passwords at least 12 characters.", "error")
        else:
            try:
                create_user_record(database_path(), username, password_hash(password), role)
                flash(f"User {username} was created.", "success")
            except INTEGRITY_ERRORS:
                flash("That username is already in use.", "error")
        return redirect(url_for("user_management"))

    @app.post("/users/<int:user_id>/username")
    def update_username(user_id: int):
        user = get_user(database_path(), user_id)
        username = request.form.get("username", "").strip()
        if user is None:
            abort(404)
        if len(username) < 3:
            flash("Usernames must be at least 3 characters.", "error")
        else:
            try:
                set_username(database_path(), user_id, username)
                flash(f"Username updated for {user['username']}.", "success")
            except INTEGRITY_ERRORS:
                flash("That username is already in use.", "error")
        return redirect(url_for("user_management"))

    @app.post("/users/<int:user_id>/toggle")
    def toggle_user(user_id: int):
        user = get_user(database_path(), user_id)
        if user is None:
            abort(404)
        if user["is_active"] and user["role"] == "Admin" and count_active_admins(database_path()) <= 1:
            flash("The last active Admin cannot be deactivated.", "error")
        else:
            set_user_active(database_path(), user_id, not bool(user["is_active"]))
            flash(f"User {user['username']} status updated.", "success")
        return redirect(url_for("user_management"))

    @app.post("/users/<int:user_id>/password")
    def reset_user_password(user_id: int):
        user = get_user(database_path(), user_id)
        password = request.form.get("password", "")
        if user is None:
            abort(404)
        if len(password) < 12:
            flash("Passwords must be at least 12 characters.", "error")
        else:
            set_user_password(database_path(), user_id, password_hash(password))
            flash(f"Password reset for {user['username']}.", "success")
        return redirect(url_for("user_management"))

    @app.context_processor
    def inject_auth_metadata():
        return {
            "current_user": getattr(g, "current_user", None),
            "csrf_token": csrf_token,
        }

    @app.before_request
    def enforce_authentication():
        _cleanup_temporary_uploads(app.instance_path)
        if app.config.get("AUTH_DISABLED"):
            return None
        if request.endpoint in {"login", "institutional_logo", "static"}:
            return None
        user = get_user(database_path(), session[SESSION_USER_ID]) if session.get(SESSION_USER_ID) else None
        if user is None or not user["is_active"]:
            logout_user()
            return redirect(url_for("login", next=request.full_path))
        timeout = int(app.config["SESSION_TIMEOUT_MINUTES"])
        if session_is_expired(session.get("auth_last_activity"), timeout) or not touch_session(timeout):
            flash("Your session expired. Please sign in again.", "error")
            return redirect(url_for("login", next=request.full_path))
        g.current_user = user
        if request.method == "POST":
            validate_csrf()
        admin_paths = (
            request.path.startswith("/settings"),
            request.path == "/backup",
            request.path.startswith("/equipment/")
            and request.method == "POST"
            and "/import/" not in request.path
            and not request.path.endswith("/new"),
            request.path.startswith("/sensor-kits/")
            and request.method == "POST"
            and (
                "/edit" in request.path
                or request.path.endswith("/delete")
            ),
            request.path.startswith("/users"),
        )
        if any(admin_paths) and user["role"] != "Admin":
            abort(403)
        return None

    @app.context_processor
    def inject_app_metadata():
        settings = get_settings(database_path())
        return {"application_name": settings["application_name"], "application_version": __version__}

    @app.get("/")
    def dashboard():
        devices = list_equipment(database_path())
        sensor_kits = list_sensor_kits(database_path())
        statuses = [_device_status(device) for device in devices]
        temperature_eligible = sum(
            _channel_eligible(device, AnalysisMode.TEMPERATURE) for device in devices
        )
        return render_template(
            "dashboard.html",
            total=len(devices),
            sensor_kit_total=len(sensor_kits),
            eligible=temperature_eligible,
            incomplete=statuses.count("Incomplete"),
            expired=sum(_certificate_expired(device) for device in devices),
        )

    @app.get("/equipment")
    def equipment_list():
        imported_count = request.args.get("imported", "")
        if imported_count.isdigit() and int(imported_count) > 0:
            flash(f"Imported {imported_count} Data Loggers with their calibration records.", "success")
        devices = list_equipment(database_path())
        for device in devices:
            device["status"] = _device_status(device)
            device["expired"] = _certificate_expired(device)
        return render_template("equipment_list.html", devices=devices)

    @app.post("/equipment/<code>/delete")
    def delete_equipment_record(code: str):
        if get_equipment(database_path(), code) is None:
            abort(404)
        try:
            with analysis_lock(app.config["ANALYSIS_LOCK"]):
                deleted = delete_equipment(database_path(), code)
        except AnalysisAlreadyRunning as exc:
            flash(str(exc), "error")
            return redirect(url_for("equipment_list"))
        if deleted:
            record_audit(
                database_path(), "delete", "equipment", code,
                _audit_actor(), "shared record deleted",
            )
            flash(f"Data Logger {code} was removed from the registry.", "success")
        else:
            flash(f"Data Logger {code} was not found in the registry.", "error")
        return redirect(url_for("equipment_list"))

    @app.get("/equipment/import")
    def equipment_import_page():
        return render_template("equipment_import.html")

    @app.post("/equipment/import/preview")
    def equipment_import_preview():
        upload = request.files.get("workbook")
        if not upload or not upload.filename:
            return jsonify({"error": "Select the Data Logger Excel workbook."}), 400
        file_name = Path(upload.filename).name
        if Path(file_name).suffix.lower() != ".xlsx":
            return jsonify({"error": "The Data Logger import requires an .xlsx workbook."}), 400
        temporary_directory = Path(app.instance_path) / "temporary_uploads"
        temporary_directory.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix="equipment_import_", dir=temporary_directory) as batch_dir:
            stored = Path(batch_dir) / file_name
            upload.save(stored)
            try:
                existing_codes = {
                    item["equipment_code"] for item in list_equipment(database_path())
                }
                preview = parse_equipment_workbook(stored, existing_codes)
            except (ValueError, OSError) as exc:
                return jsonify({"error": str(exc)}), 400
        return jsonify(_equipment_import_preview_data(preview))

    @app.post("/equipment/import/commit")
    def equipment_import_commit():
        upload = request.files.get("workbook")
        if not upload or not upload.filename:
            return jsonify({"error": "Select the Data Logger Excel workbook again to import."}), 400
        file_name = Path(upload.filename).name
        if Path(file_name).suffix.lower() != ".xlsx":
            return jsonify({"error": "The Data Logger import requires an .xlsx workbook."}), 400
        try:
            conventions = json.loads(request.form.get("conventions", ""))
        except json.JSONDecodeError:
            return jsonify({"error": "Calibration conventions are missing or invalid."}), 400
        if not isinstance(conventions, dict):
            return jsonify({"error": "Calibration conventions must be supplied for each instrument."}), 400

        temporary_directory = Path(app.instance_path) / "temporary_uploads"
        temporary_directory.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix="equipment_import_", dir=temporary_directory) as batch_dir:
            stored = Path(batch_dir) / file_name
            upload.save(stored)
            try:
                existing_codes = {
                    item["equipment_code"] for item in list_equipment(database_path())
                }
                preview = parse_equipment_workbook(stored, existing_codes)
            except (ValueError, OSError) as exc:
                return jsonify({"error": str(exc)}), 400
            issues = list(preview.issues)
            records: list[dict] = []
            if not issues:
                for equipment in preview.equipment:
                    code = equipment["equipment_code"]
                    selected = conventions.get(code)
                    if not isinstance(selected, dict):
                        issues.append(f"{code}: select correction conventions for both channels.")
                        continue
                    try:
                        temperature_convention = CorrectionConvention(selected.get("temperature", ""))
                        humidity_convention = CorrectionConvention(selected.get("relative_humidity", ""))
                        temperature_points = [
                            CorrectionPoint(point["indication"], point["correction"])
                            for point in preview.points[code]["temperature"]
                        ]
                        humidity_points = [
                            CorrectionPoint(point["indication"], point["correction"])
                            for point in preview.points[code]["relative_humidity"]
                        ]
                        CalibrationCurve(temperature_points, temperature_convention)
                        CalibrationCurve(humidity_points, humidity_convention)
                    except (ValueError, KeyError, TypeError, CalibrationError) as exc:
                        issues.append(f"{code}: invalid calibration convention or points: {exc}")
                        continue
                    record = dict(equipment)
                    record.update({
                        "temperature_convention": temperature_convention.value,
                        "temperature_points_json": _points_json(tuple(temperature_points)),
                        "humidity_convention": humidity_convention.value,
                        "humidity_points_json": _points_json(tuple(humidity_points)),
                        "notes": "",
                    })
                    records.append(record)
            if issues:
                return jsonify({
                    "error": "Import is blocked until every validation issue is resolved.",
                    "issues": issues,
                }), 422
            try:
                with analysis_lock(app.config["ANALYSIS_LOCK"]):
                    save_new_equipment_many(database_path(), records)
            except AnalysisAlreadyRunning as exc:
                return jsonify({"error": str(exc)}), 409
            except (ValueError, INTEGRITY_ERRORS) as exc:
                return jsonify({"error": str(exc)}), 409

        return jsonify({
            "imported": len(records),
            "message": f"Imported {len(records)} Data Loggers with their temperature and RH calibration points.",
        })

    @app.route("/equipment/new", methods=["GET", "POST"])
    @app.route("/equipment/<code>/edit", methods=["GET", "POST"])
    def equipment_form(code: str | None = None):
        existing = get_equipment(database_path(), code) if code else None
        if code and existing is None:
            abort(404)
        record = existing or {
            "equipment_code": "", "description": "", "serial_number": "", "manufacturer": "",
            "traceability": "", "temperature_enabled": 1, "humidity_enabled": 0, "notes": "",
            "calibration_date": "", "due_date": "", "temperature_convention": "",
            "temperature_points_json": "[]", "humidity_convention": "", "humidity_points_json": "[]",
        }
        record["temperature_point_rows"] = _point_rows(record.get("temperature_points_json", "[]"))
        record["humidity_point_rows"] = _point_rows(record.get("humidity_points_json", "[]"))
        if request.method == "POST":
            record["temperature_point_rows"] = _submitted_point_rows(request.form, "temperature")
            record["humidity_point_rows"] = _submitted_point_rows(request.form, "humidity")
            action = request.form.get("action", "save_equipment")
            equipment_code = request.form.get("equipment_code", "").strip().upper()
            if not re.fullmatch(r"[A-Z0-9][A-Z0-9_-]{1,31}", equipment_code):
                flash("Equipment code must use 2 to 32 letters, numbers, underscores, or hyphens.", "error")
                return render_template("equipment_form.html", record=record, is_new=existing is None)
            if existing and equipment_code != existing["equipment_code"]:
                flash("The equipment code cannot be changed after registration.", "error")
                return render_template("equipment_form.html", record=record, is_new=False)

            updated = dict(record)
            updated.update({
                "equipment_code": equipment_code,
                "description": request.form.get("description", "").strip(),
                "serial_number": request.form.get("serial_number", "").strip(),
                "manufacturer": request.form.get("manufacturer", "").strip(),
                "traceability": request.form.get("traceability", "").strip(),
                "temperature_enabled": int(request.form.get("temperature_enabled") == "on"),
                "humidity_enabled": int(request.form.get("humidity_enabled") == "on"),
                "notes": request.form.get("notes", "").strip(),
            })
            calibration_date = request.form.get("calibration_date", "").strip()
            due_date = request.form.get("due_date", "").strip()
            try:
                if calibration_date:
                    date.fromisoformat(calibration_date)
                if due_date:
                    date.fromisoformat(due_date)
                if calibration_date and due_date and date.fromisoformat(due_date) < date.fromisoformat(calibration_date):
                    raise ValueError("Calibration due date must be on or after the calibration date.")
                temp_points = _parse_point_fields(request.form, "temperature", "Temperature")
                rh_points = _parse_point_fields(request.form, "humidity", "Relative humidity")
                temp_convention_value = request.form.get("temperature_convention", "").strip()
                rh_convention_value = request.form.get("humidity_convention", "").strip()
                temp_convention = CorrectionConvention(temp_convention_value) if temp_convention_value else None
                rh_convention = CorrectionConvention(rh_convention_value) if rh_convention_value else None
                if action == "update_certificate":
                    if not calibration_date or not due_date:
                        raise ValueError("Calibration date and due date are required.")
                    if not updated["traceability"]:
                        raise ValueError("Traceability information is required for a calibration certificate.")
                    if updated["temperature_enabled"] and (len(temp_points) < 2 or temp_convention is None):
                        raise ValueError("At least two temperature correction points and a convention are required.")
                    if updated["humidity_enabled"] and (len(rh_points) < 2 or rh_convention is None):
                        raise ValueError("At least two RH correction points and a convention are required for the enabled RH channel.")
            except (ValueError, CalibrationError) as exc:
                flash(str(exc), "error")
                return render_template("equipment_form.html", record=record, is_new=existing is None)
            updated.update({
                "calibration_date": calibration_date,
                "due_date": due_date,
                "temperature_convention": temp_convention.value if temp_convention else "",
                "temperature_points_json": _points_json(temp_points),
                "humidity_convention": rh_convention.value if rh_convention else "",
                "humidity_points_json": _points_json(rh_points),
            })
            if existing is None:
                updated.update({
                    "temperature_points_json": updated["temperature_points_json"] or "[]",
                    "humidity_points_json": updated["humidity_points_json"] or "[]",
                })
            try:
                save_equipment(database_path(), updated)
            except INTEGRITY_ERRORS:
                flash(f"Equipment code {equipment_code} is already registered.", "error")
                return render_template("equipment_form.html", record=updated, is_new=existing is None)
            if existing:
                record_audit(
                    database_path(), "update", "equipment", equipment_code,
                    _audit_actor(), "shared record modified",
                )
            flash(f"Data Logger {equipment_code} saved.", "success")
            return redirect(url_for("equipment_list"))

        return render_template("equipment_form.html", record=record, is_new=existing is None)

    @app.get("/sensor-kits")
    def sensor_kit_list():
        imported_count = request.args.get("imported", "")
        already_imported = request.args.get("already_imported", "")
        if imported_count.isdigit() and int(imported_count) > 0:
            flash(
                f"Imported SuperDAQ kit with {imported_count} sensor(s) and calibration records.",
                "success",
            )
        elif already_imported == "1":
            flash(
                "This SuperDAQ kit and its sensors were already imported; no data was changed.",
                "success",
            )
        kits = list_sensor_kits(database_path())
        for kit in kits:
            kit["sensors"] = list_superdaq_sensors(database_path(), kit["kit_code"])
        return render_template("sensor_kit_list.html", kits=kits)

    @app.get("/sensor-kits/import")
    def superdaq_equipment_import_page():
        return render_template("superdaq_import.html")

    @app.post("/sensor-kits/import/preview")
    def superdaq_equipment_import_preview():
        upload = request.files.get("workbook")
        if not upload or not upload.filename:
            return jsonify({"error": "Select the SuperDAQ equipment Excel workbook."}), 400
        file_name = Path(upload.filename).name
        if Path(file_name).suffix.lower() != ".xlsx":
            return jsonify({"error": "The SuperDAQ equipment import requires an .xlsx workbook."}), 400
        temporary_directory = Path(app.instance_path) / "temporary_uploads"
        temporary_directory.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(
            prefix="superdaq_equipment_import_", dir=temporary_directory
        ) as batch_dir:
            stored = Path(batch_dir) / file_name
            upload.save(stored)
            try:
                preview = parse_superdaq_equipment_workbook(stored)
            except (ValueError, OSError) as exc:
                return jsonify({"error": str(exc)}), 400

        issues, existing_kit_code = registry_import_status(
            preview,
            list_sensor_kits(database_path()),
            list_superdaq_sensors(database_path()),
        )
        sensors = [
            {
                **sensor,
                "temperature_points": list(sensor["temperature_points"]),
                "temperature_count": len(sensor["temperature_points"]),
            }
            for sensor in preview.sensors
        ]
        return jsonify({
            "kit": preview.kit,
            "sensors": sensors,
            "total_points": sum(sensor["temperature_count"] for sensor in sensors),
            "issues": list(issues),
            "can_import": not issues,
            "already_imported": existing_kit_code is not None,
            "existing_kit_code": existing_kit_code,
        })

    @app.post("/sensor-kits/import/commit")
    def superdaq_equipment_import_commit():
        upload = request.files.get("workbook")
        if not upload or not upload.filename:
            return jsonify({"error": "Select the SuperDAQ workbook again to import."}), 400
        file_name = Path(upload.filename).name
        if Path(file_name).suffix.lower() != ".xlsx":
            return jsonify({"error": "The SuperDAQ equipment import requires an .xlsx workbook."}), 400
        temporary_directory = Path(app.instance_path) / "temporary_uploads"
        temporary_directory.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(
            prefix="superdaq_equipment_import_", dir=temporary_directory
        ) as batch_dir:
            stored = Path(batch_dir) / file_name
            upload.save(stored)
            try:
                preview = parse_superdaq_equipment_workbook(stored)
            except (ValueError, OSError) as exc:
                return jsonify({"error": str(exc)}), 400

        try:
            with analysis_lock(app.config["ANALYSIS_LOCK"]):
                issues, existing_kit_code = registry_import_status(
                    preview,
                    list_sensor_kits(database_path()),
                    list_superdaq_sensors(database_path()),
                )
                if issues:
                    return jsonify({
                        "error": "Import is blocked until every validation issue is resolved.",
                        "issues": list(issues),
                    }), 422
                if existing_kit_code:
                    return jsonify({
                        "imported": 0,
                        "sensors_imported": 0,
                        "already_imported": True,
                        "kit_code": existing_kit_code,
                    })
                kit_code = import_superdaq_kit(
                    database_path(), preview.kit, list(preview.sensors)
                )
        except AnalysisAlreadyRunning as exc:
            return jsonify({"error": str(exc)}), 409
        except (ValueError, INTEGRITY_ERRORS) as exc:
            return jsonify({"error": str(exc)}), 409
        return jsonify({
            "imported": 1,
            "sensors_imported": len(preview.sensors),
            "already_imported": False,
            "kit_code": kit_code,
        })

    @app.post("/sensor-kits/<kit_code>/delete")
    def delete_sensor_kit_record(kit_code: str):
        if get_sensor_kit(database_path(), kit_code) is None:
            abort(404)
        try:
            with analysis_lock(app.config["ANALYSIS_LOCK"]):
                deleted, sensor_count = delete_sensor_kit(database_path(), kit_code)
        except AnalysisAlreadyRunning as exc:
            flash(str(exc), "error")
            return redirect(url_for("sensor_kit_list"))
        if deleted:
            record_audit(
                database_path(), "delete", "sensor_kit", kit_code,
                _audit_actor(), "shared record deleted",
            )
            flash(
                f"SuperDAQ kit {kit_code} and its {sensor_count} registered sensor(s) were removed.",
                "success",
            )
        else:
            flash(f"SuperDAQ kit {kit_code} was not found in the registry.", "error")
        return redirect(url_for("sensor_kit_list"))

    @app.route("/sensor-kits/new", methods=["GET", "POST"])
    @app.route("/sensor-kits/<kit_code>/edit", methods=["GET", "POST"])
    def sensor_kit_form(kit_code: str | None = None):
        existing = get_sensor_kit(database_path(), kit_code) if kit_code else None
        if kit_code and existing is None:
            abort(404)
        record = existing or {
            "kit_code": "", "name": "", "serial_number": "", "status": "Active", "notes": ""
        }
        if request.method == "POST":
            updated = {
                "kit_code": existing["kit_code"] if existing else "",
                "name": request.form.get("name", "").strip(),
                "serial_number": request.form.get("serial_number", "").strip(),
                "status": request.form.get("status", "Active").strip(),
                "notes": request.form.get("notes", "").strip(),
            }
            if not updated["name"]:
                flash("A kit name or description is required.", "error")
                return render_template(
                    "sensor_kit_form.html", record=updated, is_new=existing is None
                )
            if updated["status"] not in {"Active", "Inactive"}:
                flash("Select a valid kit status.", "error")
                return render_template(
                    "sensor_kit_form.html", record=updated, is_new=existing is None
                )
            try:
                if existing:
                    save_sensor_kit(database_path(), updated)
                    kit_identifier = existing["kit_code"]
                else:
                    kit_identifier = create_sensor_kit(database_path(), updated)
            except INTEGRITY_ERRORS:
                flash("The sensor kit could not be saved because its generated code is already in use.", "error")
                return render_template(
                    "sensor_kit_form.html", record=updated, is_new=existing is None
                )
            if existing:
                record_audit(
                    database_path(), "update", "sensor_kit", kit_identifier,
                    _audit_actor(), "shared record modified",
                )
            flash(f"SuperDAQ sensor kit {kit_identifier} saved.", "success")
            return redirect(url_for("sensor_kit_list"))
        return render_template("sensor_kit_form.html", record=record, is_new=existing is None)

    @app.route("/sensor-kits/<kit_code>/sensors/new", methods=["GET", "POST"])
    @app.route(
        "/sensor-kits/<kit_code>/sensors/<sensor_code>/edit",
        methods=["GET", "POST"],
    )
    def superdaq_sensor_form(kit_code: str, sensor_code: str | None = None):
        kit = get_sensor_kit(database_path(), kit_code)
        if kit is None:
            abort(404)
        existing = get_superdaq_sensor(database_path(), sensor_code) if sensor_code else None
        if sensor_code and (existing is None or existing["kit_code"] != kit_code):
            abort(404)
        record = existing or {
            "sensor_code": "", "kit_code": kit_code, "name": "", "channel_identifier": "",
            "serial_number": "", "position": "", "calibration_date": "", "due_date": "",
            "certificate_number": "", "provider": "", "traceability": "",
            "temperature_convention": "", "temperature_points_json": "[]", "notes": "",
        }
        record["temperature_point_rows"] = _point_rows(record.get("temperature_points_json", "[]"))
        if request.method == "POST":
            record["temperature_point_rows"] = _submitted_point_rows(request.form, "temperature")
            sensor_identifier = request.form.get("sensor_code", "").strip().upper()
            channel_identifier = request.form.get("channel_identifier", "").strip()
            if not re.fullmatch(r"[A-Z0-9][A-Z0-9_-]{1,31}", sensor_identifier):
                flash(
                    "Sensor code must use 2 to 32 letters, numbers, underscores, or hyphens.",
                    "error",
                )
                return render_template(
                    "superdaq_sensor_form.html", record=record, kit=kit, is_new=existing is None
                )
            if existing and sensor_identifier != existing["sensor_code"]:
                flash("A sensor code cannot be changed after registration.", "error")
                return render_template(
                    "superdaq_sensor_form.html", record=record, kit=kit, is_new=False
                )
            updated = {
                "sensor_code": sensor_identifier,
                "kit_code": kit_code,
                "name": request.form.get("name", "").strip(),
                "channel_identifier": channel_identifier,
                "serial_number": request.form.get("serial_number", "").strip(),
                "position": existing["position"] if existing else "",
                "calibration_date": request.form.get("calibration_date", "").strip(),
                "due_date": request.form.get("due_date", "").strip(),
                "certificate_number": existing["certificate_number"] if existing else "",
                "provider": existing["provider"] if existing else "",
                "traceability": request.form.get("traceability", "").strip(),
                "temperature_convention": request.form.get(
                    "temperature_convention", ""
                ).strip(),
                "notes": request.form.get("notes", "").strip(),
            }
            if existing is None and get_superdaq_sensor(database_path(), sensor_identifier):
                flash(f"Sensor code {sensor_identifier} is already registered.", "error")
                return render_template(
                    "superdaq_sensor_form.html", record={**record, **updated}, kit=kit,
                    is_new=True,
                )
            try:
                if not updated["name"] or not channel_identifier:
                    raise ValueError("Sensor name and channel identifier are required.")
                if updated["calibration_date"]:
                    date.fromisoformat(updated["calibration_date"])
                if updated["due_date"]:
                    date.fromisoformat(updated["due_date"])
                if (
                    updated["calibration_date"]
                    and updated["due_date"]
                    and date.fromisoformat(updated["due_date"])
                    < date.fromisoformat(updated["calibration_date"])
                ):
                    raise ValueError("Calibration due date must be on or after the calibration date.")
                points = _parse_point_fields(request.form, "temperature", "Temperature")
                convention_value = updated["temperature_convention"]
                convention = CorrectionConvention(convention_value) if convention_value else None
                if request.form.get("action") == "update_certificate":
                    if not updated["calibration_date"] or not updated["due_date"]:
                        raise ValueError("Calibration date and due date are required.")
                    if not updated["traceability"]:
                        raise ValueError("Traceability information is required for a calibration certificate.")
                    if len(points) < 2 or convention is None:
                        raise ValueError(
                            "At least two temperature correction points and a convention are required."
                        )
            except (ValueError, CalibrationError) as exc:
                flash(str(exc), "error")
                return render_template(
                    "superdaq_sensor_form.html", record={**record, **updated}, kit=kit,
                    is_new=existing is None,
                )
            updated["temperature_points_json"] = _points_json(points)
            try:
                save_superdaq_sensor(database_path(), updated)
            except INTEGRITY_ERRORS:
                flash(
                    "Sensor code must be unique, and channel identifiers must be unique within a kit.",
                    "error",
                )
                return render_template(
                    "superdaq_sensor_form.html", record={**record, **updated}, kit=kit,
                    is_new=existing is None,
                )
            if existing:
                record_audit(
                    database_path(), "update", "sensor", sensor_identifier,
                    _audit_actor(), "shared record modified",
                )
            flash(f"SuperDAQ sensor {sensor_identifier} saved.", "success")
            return redirect(url_for("sensor_kit_list"))
        return render_template(
            "superdaq_sensor_form.html", record=record, kit=kit, is_new=existing is None
        )

    @app.post("/sensor-kits/<kit_code>/sensors/<sensor_code>/delete")
    def delete_superdaq_sensor_record(kit_code: str, sensor_code: str):
        sensor = get_superdaq_sensor(database_path(), sensor_code)
        if sensor is None or sensor["kit_code"] != kit_code:
            abort(404)
        try:
            with analysis_lock(app.config["ANALYSIS_LOCK"]):
                deleted = delete_superdaq_sensor(database_path(), sensor_code)
        except AnalysisAlreadyRunning as exc:
            flash(str(exc), "error")
            return redirect(url_for("sensor_kit_list"))
        if deleted:
            record_audit(
                database_path(), "delete", "sensor", sensor_code,
                _audit_actor(), "shared record deleted",
            )
            flash(f"SuperDAQ sensor {sensor_code} was removed from kit {kit_code}.", "success")
        else:
            flash(f"SuperDAQ sensor {sensor_code} was not found in the registry.", "error")
        return redirect(url_for("sensor_kit_list"))

    @app.get("/study")
    def study_setup():
        devices = list_equipment(database_path())
        device_choices = [
            {
                "equipment_code": device["equipment_code"],
                "serial_number": device["serial_number"],
                "due_date": device["due_date"],
                "temperature_eligible": _channel_eligible(device, AnalysisMode.TEMPERATURE),
                "humidity_eligible": _channel_eligible(device, AnalysisMode.TEMPERATURE_AND_HUMIDITY),
            }
            for device in devices
        ]
        kits = []
        for kit in list_sensor_kits(database_path()):
            kit["sensors"] = list_superdaq_sensors(database_path(), kit["kit_code"])
            kits.append(kit)
        resume_token = request.args.get("preview", "")
        resume_preview_url = None
        if resume_token:
            try:
                _read_preview(app, resume_token)
                resume_preview_url = url_for("results_preview", token=resume_token)
            except ValueError:
                flash("The previous results preview is no longer available.", "error")
        return render_template(
            "study.html",
            devices=device_choices,
            sensor_kits=kits,
            resume_preview_url=resume_preview_url,
        )

    @app.post("/study/identify")
    def identify_files():
        acquisition_system = request.form.get("acquisition_system", "data_logger")
        if acquisition_system == "fluke_superdaq":
            kit_code = request.form.get("kit_code", "")
            kit = get_sensor_kit(database_path(), kit_code)
            if kit is None or kit["status"] != "Active":
                return jsonify({"error": "Select an active registered SuperDAQ sensor kit."}), 400
            uploads = [
                upload for upload in request.files.getlist("files")
                if upload and upload.filename
            ]
            if len(uploads) != 1:
                return jsonify({"error": "Select exactly one SuperDAQ Excel export."}), 400
            upload = uploads[0]
            file_name = Path(upload.filename).name
            if Path(file_name).suffix.lower() != ".xlsx":
                return jsonify({"error": "SuperDAQ studies require an .xlsx export."}), 400
            temporary_directory = Path(app.instance_path) / "temporary_uploads"
            temporary_directory.mkdir(parents=True, exist_ok=True)
            with tempfile.TemporaryDirectory(prefix="identify_superdaq_", dir=temporary_directory) as batch_dir:
                stored = Path(batch_dir) / file_name
                upload.save(stored)
                try:
                    parsed = import_superdaq_file(stored)
                except (SuperDAQImportError, OSError) as exc:
                    return jsonify({"error": str(exc)}), 400
            sensors = list_superdaq_sensors(database_path(), kit_code)
            sensors_by_channel = {
                sensor["channel_identifier"]: sensor["sensor_code"]
                for sensor in sensors
            }
            return jsonify({
                "file_name": file_name,
                "format_name": parsed.format_name,
                "channels": [
                    {
                        "channel_name": channel,
                        "sensor_code": sensors_by_channel.get(channel),
                    }
                    for channel in parsed.channels
                ],
            })

        mode_value = request.form.get("mode", AnalysisMode.TEMPERATURE.value)
        try:
            mode = AnalysisMode(mode_value)
        except ValueError:
            mode = AnalysisMode.TEMPERATURE
        registered = {
            device["equipment_code"].casefold(): device
            for device in list_equipment(database_path())
        }
        uploads = [upload for upload in request.files.getlist("files") if upload and upload.filename]
        temporary_directory = Path(app.instance_path) / "temporary_uploads"
        temporary_directory.mkdir(parents=True, exist_ok=True)
        matches: list[dict[str, str | bool | None]] = []
        with tempfile.TemporaryDirectory(prefix="identify_", dir=temporary_directory) as batch_dir:
            for index, upload in enumerate(uploads):
                file_name = Path(upload.filename).name
                if Path(file_name).suffix.lower() != ".xls":
                    matches.append({
                        "file_name": file_name,
                        "equipment_code": None,
                        "matched": False,
                        "selectable": False,
                        "message": "Unsupported file format.",
                    })
                    continue
                stored = Path(batch_dir) / f"{index:03d}_{file_name}"
                upload.save(stored)
                try:
                    parsed = import_data_file(stored)
                except (ReportTableImportError, OSError) as exc:
                    matches.append({
                        "file_name": file_name,
                        "equipment_code": None,
                        "matched": False,
                        "selectable": False,
                        "message": str(exc),
                    })
                    continue
                code = parsed.instrument_code
                if not code:
                    matches.append({
                        "file_name": file_name,
                        "equipment_code": None,
                        "matched": False,
                        "selectable": False,
                        "message": "No Data Logger code was found in the file.",
                    })
                    continue
                record = registered.get(code.casefold())
                if record is None:
                    matches.append({
                        "file_name": file_name,
                        "equipment_code": code,
                        "matched": False,
                        "selectable": False,
                        "message": f"Detected {code}; no matching registered Data Logger.",
                    })
                    continue
                if not _channel_eligible(record, mode):
                    matches.append({
                        "file_name": file_name,
                        "equipment_code": code,
                        "matched": True,
                        "selectable": False,
                        "message": f"Detected {code}; its calibration record is incomplete for this analysis mode.",
                    })
                    continue
                matches.append({
                    "file_name": file_name,
                    "equipment_code": record["equipment_code"],
                    "matched": True,
                    "selectable": True,
                    "message": f"Identified and assigned {record['equipment_code']}.",
                })
        return jsonify(matches)

    @app.post("/study/analyze")
    def run_analysis():
        try:
            with analysis_lock(app.config["ANALYSIS_LOCK"]):
                return _perform_analysis(app, database_path())
        except AnalysisAlreadyRunning as exc:
            flash(str(exc), "error")
            return redirect(url_for("study_setup"))
        except StudyValidationError as exc:
            for issue in exc.issues:
                flash(issue, "error")
            return redirect(url_for("study_setup"))
        except (ValueError, ReportTableImportError, SuperDAQImportError, OSError) as exc:
            flash(str(exc), "error")
            return redirect(url_for("study_setup"))
        except Exception:
            flash(
                "Analysis failed unexpectedly. No successful report was confirmed; review the inputs and report destination, then retry.",
                "error",
            )
            return redirect(url_for("study_setup"))

    @app.get("/study/preview/<token>")
    def results_preview(token: str):
        try:
            payload = _read_preview(app, token)
        except ValueError as exc:
            flash(str(exc), "error")
            return redirect(url_for("study_setup"))
        results = _preview_results(payload)
        settings = get_settings(database_path())
        return render_template(
            "results_preview.html",
            payload=payload,
            results=results,
            report_directory=settings["report_directory"],
            mkt=[
                {"name": item.equipment_code, "value": item.temperature.mean}
                for item in results.logger_results
            ],
            token=token,
        )

    @app.post("/study/preview/<token>/export")
    def export_preview(token: str):
        try:
            payload = _read_preview(app, token)
            settings = get_settings(database_path())
            report_directory = settings["report_directory"].strip()
            if is_postgresql(database_path()):
                report_directory = str(Path(app.instance_path) / "temporary_uploads" / "reports")
                Path(report_directory).mkdir(parents=True, exist_ok=True)
            elif not report_directory:
                raise OSError("Configure the report output directory in Settings before saving the report.")
            output_name = request.form.get("output_name", "").strip() or None
            mode = AnalysisMode(payload["mode"])
            humidity_data = payload["humidity_limits"]
            report_path, _report_id = generate_report(
                report_directory,
                study_name=payload["study_name"],
                start=datetime.fromisoformat(payload["start"]),
                end=datetime.fromisoformat(payload["end"]),
                sampling_interval_minutes=payload["sampling_interval_minutes"],
                mode=mode,
                temperature_limits=ChannelLimits(**payload["temperature_limits"]),
                humidity_limits=ChannelLimits(**humidity_data) if humidity_data else None,
                snapshots=_preview_snapshots(payload),
                results=_preview_results(payload),
                warnings=tuple(payload["warnings"]),
                expired_certificate_confirmed=payload["expired_certificate_confirmed"],
                requested_start=datetime.fromisoformat(payload["requested_start"]),
                requested_end=datetime.fromisoformat(payload["requested_end"]),
                acquisition_system=payload["acquisition_system"],
                sensor_kit=payload["sensor_kit"],
                output_name=output_name,
            )
        except (ValueError, OSError) as exc:
            flash(str(exc), "error")
            return redirect(url_for("results_preview", token=token))
        try:
            _preview_path(app, token).unlink()
        except OSError:
            pass
        cleanup_report = is_postgresql(database_path())
        try:
            response = send_file(
                report_path,
                as_attachment=True,
                download_name=report_path.name,
                mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )
        except Exception:
            if cleanup_report:
                report_path.unlink(missing_ok=True)
            raise
        if cleanup_report:
            response.call_on_close(lambda: report_path.unlink(missing_ok=True))
        return response

    @app.route("/settings", methods=["GET", "POST"])
    def settings_page():
        settings = get_settings(database_path())
        if request.method == "POST":
            app_name = request.form.get("application_name", "").strip()
            report_directory = request.form.get("report_directory", "").strip()
            if not app_name:
                flash("Application name is required.", "error")
            else:
                save_settings(database_path(), {
                    "application_name": app_name,
                    "report_directory": report_directory,
                })
                flash("Settings saved.", "success")
                return redirect(url_for("settings_page"))
            settings.update(request.form.to_dict())
        return render_template("settings.html", settings=settings)

    @app.post("/backup")
    def manual_backup():
        backup_directory = Path(app.instance_path) / "backups"
        backup_directory.mkdir(parents=True, exist_ok=True)
        backup_path = backup_directory / f"thermal_mapping_{datetime.now():%Y%m%d_%H%M%S}.sqlite3"
        source = sqlite3.connect(database_path())
        destination = sqlite3.connect(backup_path)
        try:
            source.backup(destination)
        finally:
            destination.close()
            source.close()
        flash(f"Consistent database backup created at {backup_path}.", "success")
        return redirect(url_for("settings_page"))

    return app


def _parse_datetime(value: str, field: str) -> datetime:
    try:
        parsed = datetime.fromisoformat(value)
    except ValueError as exc:
        raise ValueError(f"A valid {field} date and time is required.") from exc
    if parsed.tzinfo is not None:
        raise ValueError(f"{field.capitalize()} must use the server's local timezone.")
    return parsed


def _perform_analysis(app: Flask, database_path: str):
    acquisition_system = request.form.get("acquisition_system", "data_logger")
    if acquisition_system == "fluke_superdaq":
        if request.form.get("mode") != AnalysisMode.TEMPERATURE.value:
            raise ValueError("Fluke SuperDAQ studies are temperature-only.")
        return _perform_superdaq_analysis(app, database_path)
    if acquisition_system != "data_logger":
        raise ValueError("Select a valid acquisition system.")

    mode = AnalysisMode(request.form.get("mode", ""))
    start = _parse_datetime(request.form.get("start", ""), "study start")
    end = _parse_datetime(request.form.get("end", ""), "study end")
    requested_start, requested_end = start, end
    try:
        temperature_limits = ChannelLimits(
            float(request.form.get("temperature_lower", "")),
            float(request.form.get("temperature_upper", "")),
        )
        humidity_limits = (
            ChannelLimits(float(request.form.get("humidity_lower", "")), float(request.form.get("humidity_upper", "")))
            if mode is AnalysisMode.TEMPERATURE_AND_HUMIDITY
            else None
        )
    except (TypeError, ValueError) as exc:
        raise ValueError("Enter valid numeric alert limits.") from exc

    uploads = [upload for upload in request.files.getlist("files") if upload and upload.filename]
    assignments = request.form.getlist("assignments")
    if not uploads:
        raise ValueError("Upload at least one Data Logger file.")
    if len(uploads) != len(assignments):
        raise ValueError("Assign a Data Logger code to every uploaded file.")
    if len(set(assignments)) != len(assignments):
        raise ValueError("Each Data Logger may be assigned to only one file per study.")
    if not request.form.get("study_name", "").strip():
        raise ValueError("Enter a study name.")

    records = get_equipment_many(database_path, assignments)
    registered_codes = {record["equipment_code"] for record in records}
    missing_codes = [code for code in assignments if code not in registered_codes]
    if missing_codes:
        raise ValueError(f"Selected Data Logger {missing_codes[0]} is not registered.")

    expired: list[dict] = []
    curves: list[tuple[CalibrationCurve, CalibrationCurve | None]] = []
    for record in records:
        curves.append(_curves_from_record(record, mode))
        if date.fromisoformat(record["due_date"]) < start.date():
            expired.append(record)
    if expired and request.form.get("confirm_expired") != "confirmed":
        details = "; ".join(
            f"{item['equipment_code']} (Serial {item['serial_number']}), due {item['due_date']}"
            for item in expired
        )
        raise ValueError(
            f"Expired calibration certificate confirmation is required for: {details}. "
            "Review the warning and explicitly confirm before proceeding."
        )

    temporary_directory = Path(app.instance_path) / "temporary_uploads"
    temporary_directory.mkdir(parents=True, exist_ok=True)
    warnings = [
        f"Data Logger {item['equipment_code']}, serial {item['serial_number']}: "
        f"calibration certificate expired on {item['due_date']}. User confirmation was recorded; "
        "confirmation does not establish metrological suitability."
        for item in expired
    ]
    assigned: list[AssignedLogger] = []
    snapshots: list[LoggerReportSnapshot] = []
    try:
        with tempfile.TemporaryDirectory(prefix="batch_", dir=temporary_directory) as batch_dir:
            for index, (upload, code, record, channel_curves) in enumerate(zip(uploads, assignments, records, curves)):
                original_name = Path(upload.filename).name
                if Path(original_name).suffix.lower() != ".xls":
                    raise ReportTableImportError(
                        f"{original_name}: unsupported format. Only the verified Report_Table .xls sample format is currently available."
                    )
                stored = Path(batch_dir) / f"{index:03d}_{original_name}"
                upload.save(stored)
                parsed = import_data_file(stored)
                if parsed.instrument_code and parsed.instrument_code.casefold() != code.casefold():
                    raise ValueError(
                        f"File {original_name} identifies Data Logger {parsed.instrument_code}, "
                        f"but was assigned to {code}. Correct the assignment."
                    )
                assigned.append(AssignedLogger(code, parsed, channel_curves[0], channel_curves[1]))
                snapshots.append(LoggerReportSnapshot(
                    equipment_code=code,
                    description=record["description"],
                    serial_number=record["serial_number"],
                    traceability=record["traceability"],
                    calibration_date=record["calibration_date"],
                    due_date=record["due_date"],
                    temperature_points=tuple(CorrectionPoint(**item) for item in parse_points(record["temperature_points_json"])),
                    temperature_convention=CorrectionConvention(record["temperature_convention"]),
                    humidity_points=tuple(CorrectionPoint(**item) for item in parse_points(record["humidity_points_json"])) if mode is AnalysisMode.TEMPERATURE_AND_HUMIDITY else (),
                    humidity_convention=CorrectionConvention(record["humidity_convention"]) if mode is AnalysisMode.TEMPERATURE_AND_HUMIDITY else None,
                ))

            start, end, boundary_warnings = snap_study_boundaries(assigned, start, end)
            warnings.extend(boundary_warnings)
            interval = infer_sampling_interval_minutes(assigned)
            results = analyze_study(
                assigned,
                start=start,
                end=end,
                sampling_interval_minutes=interval,
                mode=mode,
                temperature_limits=temperature_limits,
                humidity_limits=humidity_limits,
                strict_grid=True,
            )
            preview_payload = _preview_payload(
                study_name=request.form.get("study_name", ""),
                start=start,
                end=end,
                requested_start=requested_start,
                requested_end=requested_end,
                sampling_interval_minutes=interval,
                mode=mode,
                temperature_limits=temperature_limits,
                humidity_limits=humidity_limits,
                snapshots=tuple(snapshots),
                results=results,
                warnings=tuple(warnings),
                expired_certificate_confirmed=bool(expired),
                acquisition_system="Data Logger",
                sensor_kit="",
            )
    finally:
        try:
            temporary_directory.rmdir()
        except OSError:
            pass

    token = _write_preview(app, preview_payload)
    return redirect(url_for("results_preview", token=token))


def _perform_superdaq_analysis(app: Flask, database_path: str):
    start = _parse_datetime(request.form.get("start", ""), "study start")
    end = _parse_datetime(request.form.get("end", ""), "study end")
    requested_start, requested_end = start, end
    try:
        temperature_limits = ChannelLimits(
            float(request.form.get("temperature_lower", "")),
            float(request.form.get("temperature_upper", "")),
        )
    except (TypeError, ValueError) as exc:
        raise ValueError("Enter valid numeric temperature limits.") from exc

    kit_code = request.form.get("kit_code", "")
    kit = get_sensor_kit(database_path, kit_code)
    if kit is None or kit["status"] != "Active":
        raise ValueError("Select an active registered SuperDAQ sensor kit.")
    uploads = [upload for upload in request.files.getlist("files") if upload and upload.filename]
    if len(uploads) != 1 or Path(uploads[0].filename).suffix.lower() != ".xlsx":
        raise ValueError("Upload exactly one SuperDAQ .xlsx export.")

    channel_names = request.form.getlist("channel_names")
    sensor_assignments = request.form.getlist("sensor_assignments")
    if len(channel_names) != len(sensor_assignments):
        raise ValueError("The SuperDAQ channel mapping is incomplete. Re-identify the uploaded file.")
    if len(set(channel_names)) != len(channel_names):
        raise ValueError("Each detected SuperDAQ channel may appear only once in the mapping.")
    mapped_codes = [code for code in sensor_assignments if code]
    if not mapped_codes:
        raise ValueError("Assign at least one SuperDAQ channel to a registered sensor.")
    if len(set(mapped_codes)) != len(mapped_codes):
        raise ValueError("Each registered sensor may be assigned to only one channel per study.")
    sensors = get_superdaq_sensors_many(database_path, mapped_codes)
    sensors_by_code = {sensor["sensor_code"]: sensor for sensor in sensors}
    if len(sensors_by_code) != len(mapped_codes):
        raise ValueError("A selected SuperDAQ sensor is not registered.")
    if any(sensor["kit_code"] != kit_code for sensor in sensors):
        raise ValueError("Only sensors belonging to the selected kit may be assigned.")
    if not request.form.get("study_name", "").strip():
        raise ValueError("Enter a study name.")

    temporary_directory = Path(app.instance_path) / "temporary_uploads"
    temporary_directory.mkdir(parents=True, exist_ok=True)
    assigned: list[AssignedLogger] = []
    snapshots: list[LoggerReportSnapshot] = []
    expired: list[dict] = []
    warnings: list[str] = []
    try:
        with tempfile.TemporaryDirectory(prefix="batch_superdaq_", dir=temporary_directory) as batch_dir:
            upload = uploads[0]
            original_name = Path(upload.filename).name
            stored = Path(batch_dir) / original_name
            upload.save(stored)
            parsed = import_superdaq_file(stored)
            if set(channel_names) != set(parsed.channels):
                raise ValueError(
                    "The submitted mapping does not match the channels detected in the uploaded file. "
                    "Re-select the file and review the mapping."
                )
            for channel_name, sensor_code in zip(channel_names, sensor_assignments):
                if not sensor_code:
                    continue
                sensor = sensors_by_code[sensor_code]
                curve = _temperature_curve_from_sensor(sensor)
                if date.fromisoformat(sensor["due_date"]) < start.date():
                    expired.append(sensor)
                channel_file = ParsedFile(
                    file_name=parsed.file_name,
                    format_name=parsed.format_name,
                    instrument_code=None,
                    readings=parsed.channels[channel_name],
                )
                assigned.append(AssignedLogger(sensor_code, channel_file, curve))
                snapshots.append(LoggerReportSnapshot(
                    equipment_code=sensor_code,
                    description=sensor["name"],
                    serial_number=sensor["serial_number"],
                    traceability=sensor["traceability"],
                    calibration_date=sensor["calibration_date"],
                    due_date=sensor["due_date"],
                    temperature_points=tuple(
                        CorrectionPoint(**item)
                        for item in parse_points(sensor["temperature_points_json"])
                    ),
                    temperature_convention=CorrectionConvention(
                        sensor["temperature_convention"]
                    ),
                    source_channel=channel_name,
                    position=sensor["position"],
                    certificate_number=sensor["certificate_number"],
                    provider=sensor["provider"],
                    sensor_name=sensor["name"],
                ))

            if expired and request.form.get("confirm_expired") != "confirmed":
                details = "; ".join(
                    f"{item['sensor_code']} (Serial {item['serial_number'] or 'not recorded'}), "
                    f"due {item['due_date']}"
                    for item in expired
                )
                raise ValueError(
                    f"Expired calibration certificate confirmation is required for: {details}. "
                    "Review the warning and explicitly confirm before proceeding."
                )
            warnings.extend(
                f"SuperDAQ sensor {item['sensor_code']}, serial "
                f"{item['serial_number'] or 'not recorded'}: calibration certificate expired on "
                f"{item['due_date']}. User confirmation was recorded; confirmation does not "
                "establish metrological suitability."
                for item in expired
            )

            start, end, boundary_warnings = snap_study_boundaries(assigned, start, end)
            warnings.extend(boundary_warnings)
            interval = infer_sampling_interval_minutes(assigned)
            results = analyze_study(
                assigned,
                start=start,
                end=end,
                sampling_interval_minutes=interval,
                mode=AnalysisMode.TEMPERATURE,
                temperature_limits=temperature_limits,
                strict_grid=False,
            )
            preview_payload = _preview_payload(
                study_name=request.form.get("study_name", ""),
                start=start,
                end=end,
                requested_start=requested_start,
                requested_end=requested_end,
                sampling_interval_minutes=interval,
                mode=AnalysisMode.TEMPERATURE,
                temperature_limits=temperature_limits,
                humidity_limits=None,
                snapshots=tuple(snapshots),
                results=results,
                warnings=tuple(warnings),
                expired_certificate_confirmed=bool(expired),
                acquisition_system="Fluke SuperDAQ",
                sensor_kit=kit_code,
            )
    finally:
        try:
            temporary_directory.rmdir()
        except OSError:
            pass

    token = _write_preview(app, preview_payload)
    return redirect(url_for("results_preview", token=token))