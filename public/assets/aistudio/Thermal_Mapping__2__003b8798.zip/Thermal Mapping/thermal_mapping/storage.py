from __future__ import annotations

import json
import re
import sqlite3
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Any

try:
    import psycopg
    from psycopg import errors as postgres_errors
    from psycopg.rows import dict_row
except ImportError:  # PostgreSQL is optional for local SQLite development.
    psycopg = None
    postgres_errors = None
    dict_row = None

INTEGRITY_ERRORS = (
    sqlite3.IntegrityError,
    *((postgres_errors.UniqueViolation, postgres_errors.ForeignKeyViolation)
      if postgres_errors else ()),
)


DEFAULT_SETTINGS = {
    "application_name": "Thermal Mapping Analysis",
    "report_directory": "",
    "session_timeout_minutes": "30",
}


def is_postgresql(database_path: str | Path) -> bool:
    return str(database_path).startswith(("postgresql://", "postgres://"))


def _sqlite_target(database_path: str | Path) -> str:
    value = str(database_path)
    if value.startswith("sqlite:///"):
        value = value.removeprefix("sqlite:///")
        if not Path(value).is_absolute():
            value = str(Path.cwd() / value)
    return value


class _PostgresConnection:
    def __init__(self, connection):
        self._connection = connection

    def execute(self, query: str, params=()):
        return self._connection.execute(query.replace("?", "%s"), params)

    def executemany(self, query: str, params):
        return self._connection.executemany(query.replace("?", "%s"), params)

    def __getattr__(self, name):
        return getattr(self._connection, name)


def connect(database_path: str | Path):
    if is_postgresql(database_path):
        if psycopg is None:
            raise RuntimeError("PostgreSQL support requires the psycopg package.")
        return _PostgresConnection(
            psycopg.connect(str(database_path), row_factory=dict_row, autocommit=True)
        )
    connection = sqlite3.connect(_sqlite_target(database_path), timeout=15)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    connection.execute("PRAGMA busy_timeout = 15000")
    return connection


@contextmanager
def _connection(database_path: str | Path):
    connection = connect(database_path)
    try:
        yield connection
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


def _begin_write(connection, database_path: str | Path) -> None:
    connection.execute("BEGIN" if is_postgresql(database_path) else "BEGIN IMMEDIATE")


def initialize_database(database_path: str | Path) -> None:
    if is_postgresql(database_path):
        path = str(database_path)
    else:
        path = Path(_sqlite_target(database_path))
    if not is_postgresql(database_path):
        path.parent.mkdir(parents=True, exist_ok=True)
    with _connection(path) as connection:
        schema = """
            CREATE TABLE IF NOT EXISTS equipment (
                equipment_code TEXT PRIMARY KEY,
                description TEXT NOT NULL DEFAULT '',
                serial_number TEXT NOT NULL DEFAULT '',
                manufacturer TEXT NOT NULL DEFAULT '',
                traceability TEXT NOT NULL DEFAULT '',
                temperature_enabled INTEGER NOT NULL DEFAULT 1,
                humidity_enabled INTEGER NOT NULL DEFAULT 0,
                notes TEXT NOT NULL DEFAULT '',
                calibration_date TEXT NOT NULL DEFAULT '',
                due_date TEXT NOT NULL DEFAULT '',
                temperature_convention TEXT NOT NULL DEFAULT '',
                temperature_points_json TEXT NOT NULL DEFAULT '[]',
                humidity_convention TEXT NOT NULL DEFAULT '',
                humidity_points_json TEXT NOT NULL DEFAULT '[]',
                updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS settings (
                setting_key TEXT PRIMARY KEY,
                setting_value TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS sensor_kits (
                kit_code TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                serial_number TEXT NOT NULL DEFAULT '',
                status TEXT NOT NULL DEFAULT 'Active',
                notes TEXT NOT NULL DEFAULT '',
                updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS superdaq_sensors (
                sensor_code TEXT PRIMARY KEY,
                kit_code TEXT NOT NULL REFERENCES sensor_kits(kit_code),
                name TEXT NOT NULL DEFAULT '',
                channel_identifier TEXT NOT NULL DEFAULT '',
                serial_number TEXT NOT NULL DEFAULT '',
                position TEXT NOT NULL DEFAULT '',
                calibration_date TEXT NOT NULL DEFAULT '',
                due_date TEXT NOT NULL DEFAULT '',
                certificate_number TEXT NOT NULL DEFAULT '',
                provider TEXT NOT NULL DEFAULT '',
                traceability TEXT NOT NULL DEFAULT '',
                temperature_convention TEXT NOT NULL DEFAULT '',
                temperature_points_json TEXT NOT NULL DEFAULT '[]',
                notes TEXT NOT NULL DEFAULT '',
                updated_at TEXT NOT NULL,
                UNIQUE (kit_code, channel_identifier)
            );
            CREATE TABLE IF NOT EXISTS users (
                user_id {identity},
                username TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                role TEXT NOT NULL CHECK (role IN ('Admin', 'User')),
                is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
                created_at TEXT NOT NULL,
                last_login_at TEXT
            );
            CREATE TABLE IF NOT EXISTS equipment_calibration_history (
                history_id {history_identity},
                equipment_code TEXT NOT NULL,
                calibration_date TEXT NOT NULL DEFAULT '',
                due_date TEXT NOT NULL DEFAULT '',
                traceability TEXT NOT NULL DEFAULT '',
                temperature_convention TEXT NOT NULL DEFAULT '',
                temperature_points_json TEXT NOT NULL DEFAULT '[]',
                humidity_convention TEXT NOT NULL DEFAULT '',
                humidity_points_json TEXT NOT NULL DEFAULT '[]',
                recorded_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS sensor_calibration_history (
                history_id {history_identity},
                sensor_code TEXT NOT NULL,
                calibration_date TEXT NOT NULL DEFAULT '',
                due_date TEXT NOT NULL DEFAULT '',
                traceability TEXT NOT NULL DEFAULT '',
                temperature_convention TEXT NOT NULL DEFAULT '',
                temperature_points_json TEXT NOT NULL DEFAULT '[]',
                recorded_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS audit_log (
                audit_id {history_identity},
                action TEXT NOT NULL,
                entity_type TEXT NOT NULL,
                entity_id TEXT NOT NULL,
                details TEXT NOT NULL DEFAULT '',
                recorded_at TEXT NOT NULL
            );
            CREATE UNIQUE INDEX IF NOT EXISTS users_username_lower_unique
                ON users (LOWER(username));
            """
        identity = "SERIAL PRIMARY KEY" if is_postgresql(path) else "INTEGER PRIMARY KEY AUTOINCREMENT"
        schema = schema.format(identity=identity, history_identity=identity)
        if is_postgresql(path):
            for statement in schema.split(";"):
                if statement.strip():
                    connection.execute(statement)
        else:
            connection.execute("PRAGMA journal_mode = WAL")
            connection.executescript(schema)
        kit_columns = {
            row["name"] for row in (
                connection.execute(
                    "SELECT column_name AS name FROM information_schema.columns "
                    "WHERE table_name = 'sensor_kits'"
                ).fetchall()
                if is_postgresql(path)
                else connection.execute("PRAGMA table_info(sensor_kits)")
            )
        }
        if "serial_number" not in kit_columns:
            connection.execute(
                "ALTER TABLE sensor_kits ADD COLUMN serial_number TEXT NOT NULL DEFAULT ''"
            )
        for key, value in DEFAULT_SETTINGS.items():
            connection.execute(
                "INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) "
                "ON CONFLICT(setting_key) DO NOTHING",
                (key, value),
            )


def get_user(database_path: str | Path, user_id: int) -> dict[str, Any] | None:
    with _connection(database_path) as connection:
        row = connection.execute("SELECT * FROM users WHERE user_id = ?", (user_id,)).fetchone()
    return dict(row) if row else None


def get_user_by_username(database_path: str | Path, username: str) -> dict[str, Any] | None:
    with _connection(database_path) as connection:
        row = connection.execute("SELECT * FROM users WHERE username = ?", (username.strip(),)).fetchone()
    return dict(row) if row else None


def list_users(database_path: str | Path) -> list[dict[str, Any]]:
    with _connection(database_path) as connection:
        rows = connection.execute("SELECT * FROM users ORDER BY LOWER(username)").fetchall()
    return [dict(row) for row in rows]


def create_user(database_path: str | Path, username: str, password_hash: str, role: str) -> int:
    if role not in {"Admin", "User"}:
        raise ValueError("Select a valid user role.")
    with _connection(database_path) as connection:
        cursor = connection.execute(
            "INSERT INTO users (username, password_hash, role, created_at) VALUES (?, ?, ?, ?)"
            + (" RETURNING user_id" if is_postgresql(database_path) else ""),
            (username.strip(), password_hash, role, datetime.now().astimezone().isoformat(timespec="seconds")),
        )
    return int(cursor.fetchone()["user_id"] if is_postgresql(database_path) else cursor.lastrowid)


def update_user_login(database_path: str | Path, user_id: int) -> None:
    with _connection(database_path) as connection:
        connection.execute(
            "UPDATE users SET last_login_at = ? WHERE user_id = ?",
            (datetime.now().astimezone().isoformat(timespec="seconds"), user_id),
        )


def set_user_active(database_path: str | Path, user_id: int, active: bool) -> None:
    with _connection(database_path) as connection:
        connection.execute("UPDATE users SET is_active = ? WHERE user_id = ?", (int(active), user_id))


def set_user_password(database_path: str | Path, user_id: int, password_hash: str) -> None:
    with _connection(database_path) as connection:
        connection.execute("UPDATE users SET password_hash = ? WHERE user_id = ?", (password_hash, user_id))


def set_username(database_path: str | Path, user_id: int, username: str) -> None:
    with _connection(database_path) as connection:
        connection.execute("UPDATE users SET username = ? WHERE user_id = ?", (username.strip(), user_id))


def record_audit(
    database_path: str | Path,
    action: str,
    entity_type: str,
    entity_id: str,
    actor_username: str,
    details: str = "",
) -> None:
    with _connection(database_path) as connection:
        connection.execute(
            "INSERT INTO audit_log (action, entity_type, entity_id, details, recorded_at) "
            "VALUES (?, ?, ?, ?, ?)",
            (action, entity_type, entity_id, f"actor={actor_username}; {details}",
             datetime.now().astimezone().isoformat(timespec="seconds")),
        )


def count_active_admins(database_path: str | Path) -> int:
    with _connection(database_path) as connection:
        return int(connection.execute(
            "SELECT COUNT(*) FROM users WHERE role = 'Admin' AND is_active = 1"
        ).fetchone()[0])


def list_equipment(database_path: str | Path) -> list[dict[str, Any]]:
    with _connection(database_path) as connection:
        rows = connection.execute(
            "SELECT * FROM equipment ORDER BY LOWER(equipment_code)"
        ).fetchall()
    return [dict(row) for row in rows]


def get_equipment(database_path: str | Path, code: str) -> dict[str, Any] | None:
    with _connection(database_path) as connection:
        row = connection.execute(
            "SELECT * FROM equipment WHERE equipment_code = ?", (code,)
        ).fetchone()
    return dict(row) if row else None


def delete_equipment(database_path: str | Path, code: str) -> bool:
    with _connection(database_path) as connection:
        cursor = connection.execute(
            "DELETE FROM equipment WHERE equipment_code = ?", (code,)
        )
    return cursor.rowcount > 0


def get_equipment_many(database_path: str | Path, codes: list[str]) -> list[dict[str, Any]]:
    if not codes:
        return []
    connection = connect(database_path)
    try:
        connection.execute("BEGIN")
        placeholders = ", ".join("?" for _ in codes)
        rows = connection.execute(
            f"SELECT * FROM equipment WHERE equipment_code IN ({placeholders})",
            codes,
        ).fetchall()
        connection.commit()
        by_code = {row["equipment_code"]: dict(row) for row in rows}
        return [by_code[code] for code in codes if code in by_code]
    finally:
        connection.close()


def list_sensor_kits(database_path: str | Path) -> list[dict[str, Any]]:
    with _connection(database_path) as connection:
        rows = connection.execute(
            "SELECT * FROM sensor_kits ORDER BY LOWER(kit_code)"
        ).fetchall()
    return [dict(row) for row in rows]


def get_sensor_kit(database_path: str | Path, code: str) -> dict[str, Any] | None:
    with _connection(database_path) as connection:
        row = connection.execute(
            "SELECT * FROM sensor_kits WHERE kit_code = ?", (code,)
        ).fetchone()
    return dict(row) if row else None


def delete_sensor_kit(database_path: str | Path, code: str) -> tuple[bool, int]:
    with _connection(database_path) as connection:
        _begin_write(connection, database_path)
        sensor_count = connection.execute(
            "SELECT COUNT(*) FROM superdaq_sensors WHERE kit_code = ?", (code,)
        ).fetchone()[0]
        connection.execute("DELETE FROM superdaq_sensors WHERE kit_code = ?", (code,))
        cursor = connection.execute("DELETE FROM sensor_kits WHERE kit_code = ?", (code,))
    return cursor.rowcount > 0, sensor_count


def save_sensor_kit(database_path: str | Path, record: dict[str, Any]) -> None:
    with _connection(database_path) as connection:
        updated_at = datetime.now().isoformat(timespec="seconds")
        exists = connection.execute(
            "SELECT 1 FROM sensor_kits WHERE kit_code = ?", (record["kit_code"],)
        ).fetchone()
        if exists:
            connection.execute(
                "UPDATE sensor_kits SET name=?, serial_number=?, status=?, notes=?, updated_at=? "
                "WHERE kit_code=?",
                (
                    record.get("name", ""),
                    record.get("serial_number", ""),
                    record.get("status", "Active"),
                    record.get("notes", ""),
                    updated_at,
                    record["kit_code"],
                ),
            )
        else:
            connection.execute(
                "INSERT INTO sensor_kits "
                "(kit_code, name, serial_number, status, notes, updated_at) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (
                    record["kit_code"],
                    record.get("name", ""),
                    record.get("serial_number", ""),
                    record.get("status", "Active"),
                    record.get("notes", ""),
                    updated_at,
                ),
            )


def create_sensor_kit(database_path: str | Path, record: dict[str, Any]) -> str:
    with _connection(database_path) as connection:
        _begin_write(connection, database_path)
        codes = connection.execute(
            "SELECT kit_code FROM sensor_kits"
        ).fetchall()
        sequence = max(
            (
                int(match.group(1))
                for row in codes
                if (match := re.fullmatch(r"KIT(\d+)", row["kit_code"], re.IGNORECASE))
            ),
            default=0,
        ) + 1
        kit_code = f"KIT{sequence:03d}"
        connection.execute(
            "INSERT INTO sensor_kits "
            "(kit_code, name, serial_number, status, notes, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (
                kit_code,
                record.get("name", ""),
                record.get("serial_number", ""),
                record.get("status", "Active"),
                record.get("notes", ""),
                datetime.now().isoformat(timespec="seconds"),
            ),
        )
    return kit_code


def import_superdaq_kit(
    database_path: str | Path, kit: dict[str, Any], sensors: list[dict[str, Any]]
) -> str:
    with _connection(database_path) as connection:
        _begin_write(connection, database_path)
        existing = connection.execute(
            "SELECT kit_code FROM sensor_kits "
            "WHERE LOWER(serial_number) = LOWER(?)",
            (kit["serial_number"],),
        ).fetchone()
        if existing:
            raise ValueError(
                f"Kit serial number {kit['serial_number']} is already registered; "
                "the import did not overwrite existing data."
            )

        codes = connection.execute("SELECT kit_code FROM sensor_kits").fetchall()
        sequence = max(
            (
                int(match.group(1))
                for row in codes
                if (match := re.fullmatch(r"KIT(\d+)", row["kit_code"], re.IGNORECASE))
            ),
            default=0,
        ) + 1
        kit_code = f"KIT{sequence:03d}"
        updated_at = datetime.now().isoformat(timespec="seconds")
        connection.execute(
            "INSERT INTO sensor_kits "
            "(kit_code, name, serial_number, status, notes, updated_at) "
            "VALUES (?, ?, ?, 'Active', '', ?)",
            (kit_code, kit["name"], kit["serial_number"], updated_at),
        )

        fields = (
            "sensor_code", "kit_code", "name", "channel_identifier", "serial_number",
            "position", "calibration_date", "due_date", "certificate_number",
            "provider", "traceability", "temperature_convention",
            "temperature_points_json", "notes",
        )
        for sensor in sensors:
            values = (
                sensor["sensor_code"],
                kit_code,
                sensor["name"],
                sensor["channel_identifier"],
                sensor["serial_number"],
                "",
                sensor["calibration_date"],
                sensor["due_date"],
                "",
                "",
                sensor["traceability"],
                sensor["temperature_convention"],
                json.dumps([
                    {
                        "indication": point["indication"],
                        "correction": point["correction"],
                    }
                    for point in sensor["temperature_points"]
                ]),
                "",
            )
            connection.execute(
                f"INSERT INTO superdaq_sensors ({', '.join(fields)}, updated_at) "
                f"VALUES ({', '.join('?' for _ in fields)}, ?)",
                (*values, updated_at),
            )
    return kit_code


def list_superdaq_sensors(
    database_path: str | Path, kit_code: str | None = None
) -> list[dict[str, Any]]:
    with _connection(database_path) as connection:
        if kit_code is None:
            rows = connection.execute(
                "SELECT * FROM superdaq_sensors ORDER BY LOWER(kit_code), LOWER(sensor_code)"
            ).fetchall()
        else:
            rows = connection.execute(
                "SELECT * FROM superdaq_sensors WHERE kit_code = ? "
                "ORDER BY LOWER(sensor_code)",
                (kit_code,),
            ).fetchall()
    return [dict(row) for row in rows]


def get_superdaq_sensor(database_path: str | Path, sensor_code: str) -> dict[str, Any] | None:
    with _connection(database_path) as connection:
        row = connection.execute(
            "SELECT * FROM superdaq_sensors WHERE sensor_code = ?", (sensor_code,)
        ).fetchone()
    return dict(row) if row else None


def delete_superdaq_sensor(database_path: str | Path, sensor_code: str) -> bool:
    with _connection(database_path) as connection:
        cursor = connection.execute(
            "DELETE FROM superdaq_sensors WHERE sensor_code = ?", (sensor_code,)
        )
    return cursor.rowcount > 0


def get_superdaq_sensors_many(
    database_path: str | Path, sensor_codes: list[str]
) -> list[dict[str, Any]]:
    if not sensor_codes:
        return []
    with _connection(database_path) as connection:
        placeholders = ", ".join("?" for _ in sensor_codes)
        rows = connection.execute(
            f"SELECT * FROM superdaq_sensors WHERE sensor_code IN ({placeholders})",
            sensor_codes,
        ).fetchall()
    by_code = {row["sensor_code"]: dict(row) for row in rows}
    return [by_code[code] for code in sensor_codes if code in by_code]


def save_superdaq_sensor(database_path: str | Path, record: dict[str, Any]) -> None:
    fields = (
        "sensor_code", "kit_code", "name", "channel_identifier", "serial_number",
        "position", "calibration_date", "due_date", "certificate_number",
        "provider", "traceability", "temperature_convention",
        "temperature_points_json", "notes",
    )
    values = [record.get(field, "") for field in fields]
    values[-2] = values[-2] or "[]"
    with _connection(database_path) as connection:
        updated_at = datetime.now().isoformat(timespec="seconds")
        exists = connection.execute(
            "SELECT 1 FROM superdaq_sensors WHERE sensor_code = ?",
            (record["sensor_code"],),
        ).fetchone()
        if exists:
            previous = connection.execute(
                "SELECT calibration_date, due_date, traceability, temperature_convention, "
                "temperature_points_json FROM superdaq_sensors WHERE sensor_code = ?",
                (record["sensor_code"],),
            ).fetchone()
            connection.execute(
                "INSERT INTO sensor_calibration_history "
                "(sensor_code, calibration_date, due_date, traceability, temperature_convention, "
                "temperature_points_json, recorded_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (
                    record["sensor_code"], previous["calibration_date"], previous["due_date"],
                    previous["traceability"], previous["temperature_convention"],
                    previous["temperature_points_json"], datetime.now().isoformat(timespec="seconds"),
                ),
            )
            connection.execute(
                "UPDATE superdaq_sensors SET "
                f"{', '.join(f'{field}=?' for field in fields if field != 'sensor_code')}, "
                "updated_at=? WHERE sensor_code=?",
                (
                    *(record.get(field, "") or ("[]" if field == "temperature_points_json" else "") for field in fields if field != "sensor_code"),
                    updated_at,
                    record["sensor_code"],
                ),
            )
        else:
            connection.execute(
                f"INSERT INTO superdaq_sensors ({', '.join(fields)}, updated_at) "
                f"VALUES ({', '.join('?' for _ in fields)}, ?)",
                (*values, updated_at),
            )


def save_equipment(database_path: str | Path, record: dict[str, Any]) -> None:
    fields = (
        "equipment_code", "description", "serial_number", "manufacturer", "traceability",
        "temperature_enabled", "humidity_enabled", "notes", "calibration_date", "due_date",
        "temperature_convention", "temperature_points_json", "humidity_convention",
        "humidity_points_json",
    )
    values = [record.get(field, "") for field in fields]
    values[-1] = values[-1] or "[]"
    values[-3] = values[-3] or "[]"
    with _connection(database_path) as connection:
        previous = connection.execute(
            "SELECT calibration_date, due_date, traceability, temperature_convention, "
            "temperature_points_json, humidity_convention, humidity_points_json "
            "FROM equipment WHERE equipment_code = ?",
            (record["equipment_code"],),
        ).fetchone()
        if previous:
            connection.execute(
                "INSERT INTO equipment_calibration_history "
                "(equipment_code, calibration_date, due_date, traceability, temperature_convention, "
                "temperature_points_json, humidity_convention, humidity_points_json, recorded_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    record["equipment_code"], previous["calibration_date"], previous["due_date"],
                    previous["traceability"], previous["temperature_convention"],
                    previous["temperature_points_json"], previous["humidity_convention"],
                    previous["humidity_points_json"], datetime.now().isoformat(timespec="seconds"),
                ),
            )
        connection.execute(
            f"INSERT INTO equipment ({', '.join(fields)}, updated_at) "
            f"VALUES ({', '.join('?' for _ in fields)}, ?) "
            f"ON CONFLICT(equipment_code) DO UPDATE SET "
            f"{', '.join(f'{field}=excluded.{field}' for field in fields if field != 'equipment_code')}, "
            "updated_at=excluded.updated_at",
            (*values, datetime.now().isoformat(timespec="seconds")),
        )


def save_new_equipment_many(
    database_path: str | Path, records: list[dict[str, Any]]
) -> None:
    fields = (
        "equipment_code", "description", "serial_number", "manufacturer", "traceability",
        "temperature_enabled", "humidity_enabled", "notes", "calibration_date", "due_date",
        "temperature_convention", "temperature_points_json", "humidity_convention",
        "humidity_points_json",
    )
    with _connection(database_path) as connection:
        _begin_write(connection, database_path)
        for record in records:
            if connection.execute(
                "SELECT 1 FROM equipment WHERE equipment_code = ?",
                (record["equipment_code"],),
            ).fetchone():
                raise ValueError(
                    f"Data Logger {record['equipment_code']} already exists; "
                    "the import did not overwrite existing equipment."
                )
            values = [record.get(field, "") for field in fields]
            values[11] = values[11] or "[]"
            values[13] = values[13] or "[]"
            connection.execute(
                f"INSERT INTO equipment ({', '.join(fields)}, updated_at) "
                f"VALUES ({', '.join('?' for _ in fields)}, ?)",
                (*values, datetime.now().isoformat(timespec="seconds")),
            )


def get_settings(database_path: str | Path) -> dict[str, str]:
    with _connection(database_path) as connection:
        rows = connection.execute("SELECT setting_key, setting_value FROM settings").fetchall()
    values = DEFAULT_SETTINGS.copy()
    values.update({row["setting_key"]: row["setting_value"] for row in rows})
    return values


def save_settings(database_path: str | Path, values: dict[str, str]) -> None:
    with _connection(database_path) as connection:
        connection.executemany(
            "INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) "
            "ON CONFLICT(setting_key) DO UPDATE SET setting_value=excluded.setting_value",
            values.items(),
        )


def parse_points(value: str) -> list[dict[str, float]]:
    try:
        decoded = json.loads(value or "[]")
    except json.JSONDecodeError as exc:
        raise ValueError("Calibration points are not valid stored data.") from exc
    if not isinstance(decoded, list):
        raise ValueError("Calibration points must be stored as a list.")
    return decoded