from __future__ import annotations

from datetime import datetime, timedelta, timezone
from functools import wraps
import secrets
from typing import Callable

from flask import abort, flash, g, redirect, request, session, url_for

from werkzeug.security import check_password_hash, generate_password_hash


SESSION_USER_ID = "auth_user_id"
SESSION_LAST_ACTIVITY = "auth_last_activity"
SESSION_CSRF = "csrf_token"


def new_csrf_token() -> str:
    token = secrets.token_urlsafe(32)
    session[SESSION_CSRF] = token
    return token


def csrf_token() -> str:
    return session.get(SESSION_CSRF) or new_csrf_token()


def validate_csrf() -> None:
    expected = session.get(SESSION_CSRF)
    supplied = request.form.get("csrf_token") or request.headers.get("X-CSRF-Token")
    if not expected or not supplied or not secrets.compare_digest(expected, supplied):
        abort(400, description="The security token is missing or invalid. Refresh the page and try again.")


def login_user(user: dict) -> None:
    session.clear()
    session[SESSION_USER_ID] = user["user_id"]
    session[SESSION_LAST_ACTIVITY] = datetime.now(timezone.utc).isoformat()
    new_csrf_token()


def logout_user() -> None:
    session.clear()


def current_user():
    return getattr(g, "current_user", None)


def login_required(view: Callable):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if current_user() is None:
            return redirect(url_for("login", next=request.full_path))
        return view(*args, **kwargs)

    return wrapped


def admin_required(view: Callable):
    @wraps(view)
    def wrapped(*args, **kwargs):
        user = current_user()
        if user is None:
            return redirect(url_for("login", next=request.full_path))
        if user["role"] != "Admin":
            abort(403)
        return view(*args, **kwargs)

    return wrapped


def session_is_expired(last_activity: str | None, timeout_minutes: int) -> bool:
    if not last_activity:
        return True
    try:
        last = datetime.fromisoformat(last_activity)
    except ValueError:
        return True
    return datetime.now(timezone.utc) - last > timedelta(minutes=timeout_minutes)


def touch_session(timeout_minutes: int) -> bool:
    if session_is_expired(session.get(SESSION_LAST_ACTIVITY), timeout_minutes):
        logout_user()
        return False
    session[SESSION_LAST_ACTIVITY] = datetime.now(timezone.utc).isoformat()
    return True


def password_hash(password: str) -> str:
    return generate_password_hash(password)


def password_matches(password_hash_value: str, password: str) -> bool:
    return check_password_hash(password_hash_value, password)
