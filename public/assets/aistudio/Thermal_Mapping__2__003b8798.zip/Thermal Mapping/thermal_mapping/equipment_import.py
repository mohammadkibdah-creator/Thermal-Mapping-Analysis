from __future__ import annotations

import math
import re
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path

from openpyxl import load_workbook
from openpyxl.utils.exceptions import InvalidFileException


_INDICATION = re.compile(
    r"^\s*Data\s*Logger\s*-\s*(DL\d+)\s*-\s*\(\s*"
    r"([+-]?(?:\d+(?:\.\d*)?|\.\d+))\s*(%RH|C)\s*\)\s*$",
    re.IGNORECASE,
)
_EQUIPMENT_CODE = re.compile(r"\bDL\d+\b", re.IGNORECASE)


@dataclass(frozen=True)
class EquipmentImportPreview:
    equipment: tuple[dict, ...]
    points: dict[str, dict[str, tuple[dict, ...]]]
    counts: tuple[dict[str, str | int], ...]
    issues: tuple[str, ...]

    @property
    def can_import(self) -> bool:
        return not self.issues


def _is_empty(value: object) -> bool:
    return value is None or (isinstance(value, str) and not value.strip())


def _date_value(value: object, sheet_name: str, row_number: int, field: str) -> str | None:
    if _is_empty(value):
        return None
    if isinstance(value, datetime):
        return value.date().isoformat()
    if isinstance(value, date):
        return value.isoformat()
    text = str(value).strip()
    for date_format in (
        "%Y-%m-%d",
        "%b %d, %Y",
        "%B %d, %Y",
    ):
        try:
            return datetime.strptime(text, date_format).date().isoformat()
        except ValueError:
            continue
    raise ValueError(
        f"{sheet_name} row {row_number}: {field} must include a full calendar date; "
        f"found {text!r}."
    )


def parse_equipment_workbook(path: str | Path, existing_codes: set[str] | None = None) -> EquipmentImportPreview:
    source = Path(path)
    try:
        workbook = load_workbook(source, read_only=True, data_only=True)
    except (OSError, ValueError, InvalidFileException) as exc:
        raise ValueError(f"Could not read equipment workbook {source.name}: {exc}") from exc

    issues: list[str] = []
    equipment_by_code: dict[str, dict] = {}
    source_rows: dict[str, int] = {}
    grouped_points: dict[str, dict[str, list[dict]]] = defaultdict(
        lambda: {"temperature": [], "relative_humidity": []}
    )
    existing = {code.casefold() for code in (existing_codes or set())}

    try:
        required_sheets = {"equipment details", "corrections"}
        sheets_by_name = {sheet.title.strip().casefold(): sheet for sheet in workbook.worksheets}
        missing_sheets = required_sheets - sheets_by_name.keys()
        if missing_sheets:
            raise ValueError(
                "Workbook is missing required worksheet(s): "
                + ", ".join(sorted(missing_sheets))
                + "."
            )

        equipment_sheet = sheets_by_name["equipment details"]
        equipment_headers = {
            str(cell.value).strip().casefold(): index
            for index, cell in enumerate(equipment_sheet[1], start=0)
            if not _is_empty(cell.value)
        }
        expected_headers = (
            "instrument description",
            "equipment code",
            "serial number",
            "manufacturer",
            "traceability",
            "calibration date",
            "calibration due date",
        )
        for header in expected_headers:
            if header not in equipment_headers:
                raise ValueError(f"Equipment details worksheet is missing the {header!r} column.")

        for row_number, row in enumerate(
            equipment_sheet.iter_rows(min_row=2, values_only=True), start=2
        ):
            if all(_is_empty(value) for value in row):
                continue
            values = {
                header: row[column] if column < len(row) else None
                for header, column in equipment_headers.items()
            }
            raw_code = values["equipment code"]
            if _is_empty(raw_code):
                issues.append(f"Equipment details row {row_number}: equipment code is missing.")
                continue
            code = str(raw_code).strip().upper()
            if not re.fullmatch(r"[A-Z0-9][A-Z0-9_-]{1,31}", code):
                issues.append(
                    f"Equipment details row {row_number}: invalid equipment code {raw_code!r}."
                )
                continue
            if code.casefold() in source_rows:
                issues.append(
                    f"Equipment details row {row_number}: duplicate equipment code {code}; "
                    f"first appears on row {source_rows[code.casefold()]}."
                )
                continue
            source_rows[code.casefold()] = row_number
            if code.casefold() in existing:
                issues.append(
                    f"Equipment details row {row_number}: {code} already exists in the registry; "
                    "imports never overwrite existing equipment."
                )
            description = str(values["instrument description"] or "").strip()
            if not description:
                issues.append(
                    f"Equipment details row {row_number}: instrument description is required."
                )
            described_code = _EQUIPMENT_CODE.search(description)
            if described_code and described_code.group().casefold() != code.casefold():
                issues.append(
                    f"Equipment details row {row_number}: description identifies "
                    f"{described_code.group().upper()} but Equipment Code is {code}."
                )
            serial = "" if _is_empty(values["serial number"]) else str(values["serial number"]).strip()
            traceability = (
                "" if _is_empty(values["traceability"]) else str(values["traceability"]).strip()
            )
            manufacturer = (
                "" if _is_empty(values["manufacturer"]) else str(values["manufacturer"]).strip()
            )
            if not serial:
                issues.append(f"Equipment details row {row_number}: serial number is required.")
            if not traceability:
                issues.append(f"Equipment details row {row_number}: traceability is required.")
            try:
                calibration_date = _date_value(
                    values["calibration date"], "Equipment details", row_number, "Calibration Date"
                )
            except ValueError as exc:
                issues.append(str(exc))
                calibration_date = None
            try:
                due_date = _date_value(
                    values["calibration due date"],
                    "Equipment details",
                    row_number,
                    "Calibration Due Date",
                )
            except ValueError as exc:
                issues.append(str(exc))
                due_date = None
            if calibration_date and due_date and due_date < calibration_date:
                issues.append(
                    f"Equipment details row {row_number}: Calibration Due Date precedes Calibration Date."
                )
            equipment_by_code[code] = {
                "equipment_code": code,
                "description": description,
                "serial_number": serial,
                "manufacturer": manufacturer,
                "traceability": traceability,
                "calibration_date": calibration_date or "",
                "due_date": due_date or "",
                "temperature_enabled": 1,
                "humidity_enabled": 1,
                "temperature_convention": "",
                "humidity_convention": "",
            }

        if not equipment_by_code:
            issues.append("Equipment details worksheet contains no instruments.")

        corrections_sheet = sheets_by_name["corrections"]
        correction_headers = {
            str(cell.value).strip().casefold(): index
            for index, cell in enumerate(corrections_sheet[1], start=0)
            if not _is_empty(cell.value)
        }
        if "indication" not in correction_headers or "correction" not in correction_headers:
            raise ValueError("Corrections worksheet must contain Indication and Correction columns.")
        indication_column = correction_headers["indication"]
        correction_column = correction_headers["correction"]

        for row_number, row in enumerate(
            corrections_sheet.iter_rows(min_row=2, values_only=True), start=2
        ):
            indication = row[indication_column] if indication_column < len(row) else None
            correction = row[correction_column] if correction_column < len(row) else None
            if _is_empty(indication) and _is_empty(correction):
                continue
            if _is_empty(indication):
                issues.append(
                    f"Corrections row {row_number}: Correction is populated but Indication is blank."
                )
                continue
            if not isinstance(indication, str):
                issues.append(
                    f"Corrections row {row_number}: Indication must be text; found {indication!r}."
                )
                continue
            match = _INDICATION.fullmatch(indication)
            if not match:
                issues.append(
                    f"Corrections row {row_number}: malformed Indication {indication!r}; "
                    "expected an equipment code, numeric indication, and C or %RH unit."
                )
                continue
            code, indication_text, unit = match.groups()
            code = code.upper()
            if code not in equipment_by_code:
                issues.append(
                    f"Corrections row {row_number}: equipment code {code} has no exact match "
                    "in Equipment Code; its points were not assigned."
                )
                continue
            if _is_empty(correction) or isinstance(correction, bool):
                issues.append(
                    f"Corrections row {row_number}: correction for {code} is missing or non-numeric."
                )
                continue
            try:
                correction_value = float(correction)
                indication_value = float(indication_text)
            except (TypeError, ValueError, OverflowError):
                issues.append(
                    f"Corrections row {row_number}: indication or correction for {code} is non-numeric."
                )
                continue
            if not math.isfinite(indication_value) or not math.isfinite(correction_value):
                issues.append(
                    f"Corrections row {row_number}: indication and correction for {code} "
                    "must be finite numbers."
                )
                continue
            kind = "temperature" if unit.upper() == "C" else "relative_humidity"
            grouped_points[code][kind].append({
                "indication": indication_value,
                "correction": correction_value,
                "source_indication": indication,
                "source_correction": str(correction),
                "source_row": row_number,
            })

        for code in equipment_by_code:
            for kind in ("temperature", "relative_humidity"):
                points = grouped_points[code][kind]
                label = "temperature" if kind == "temperature" else "relative-humidity"
                if len(points) < 2:
                    issues.append(
                        f"{code}: at least two {label} correction points are required; "
                        f"found {len(points)}."
                    )
                indications = [point["indication"] for point in points]
                duplicates = sorted(value for value, count in Counter(indications).items() if count > 1)
                if duplicates:
                    issues.append(
                        f"{code}: duplicate {label} indication point(s): "
                        + ", ".join(str(value) for value in duplicates)
                        + "."
                    )

        counts = tuple(
            {
                "equipment_code": code,
                "temperature": len(grouped_points[code]["temperature"]),
                "relative_humidity": len(grouped_points[code]["relative_humidity"]),
            }
            for code in sorted(equipment_by_code, key=str.casefold)
        )
        return EquipmentImportPreview(
            equipment=tuple(equipment_by_code.values()),
            points={
                code: {
                    kind: tuple(point_rows)
                    for kind, point_rows in groups.items()
                }
                for code, groups in grouped_points.items()
            },
            counts=counts,
            issues=tuple(issues),
        )
    finally:
        workbook.close()
