from __future__ import annotations

import math
import re
from datetime import datetime
from pathlib import Path

import xlrd

from ..domain import Measurement, ParsedFile


class ReportTableImportError(ValueError):
    pass


_DATE_FORMATS = (
    "%m/%d/%Y %I:%M:%S %p",
    "%m/%d/%Y %H:%M:%S",
    "%m/%d/%Y %H:%M",
    "%Y-%m-%d %H:%M:%S",
    "%Y-%m-%d %H:%M",
)


def _normalized(value: object) -> str:
    return re.sub(r"\s+", "", str(value or "")).lower()


def _number(value: object) -> float | None:
    if value is None or (isinstance(value, str) and not value.strip()):
        return None
    try:
        result = float(value)
    except (TypeError, ValueError) as exc:
        raise ReportTableImportError(f"Invalid numeric measurement: {value!r}.") from exc
    if not math.isfinite(result):
        raise ReportTableImportError(f"Invalid non-finite measurement: {value!r}.")
    return result


def _timestamp(value: object, datemode: int) -> datetime:
    if isinstance(value, datetime):
        return value.replace(tzinfo=None)
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        try:
            year, month, day, hour, minute, second = xlrd.xldate_as_tuple(value, datemode)
            return datetime(year, month, day, hour, minute, second)
        except (ValueError, OverflowError) as exc:
            raise ReportTableImportError(f"Invalid Excel timestamp: {value!r}.") from exc
    text = str(value).strip()
    for date_format in _DATE_FORMATS:
        try:
            return datetime.strptime(text, date_format)
        except ValueError:
            continue
    raise ReportTableImportError(f"Invalid timestamp: {text!r}.")


def _find_header(sheet: xlrd.sheet.Sheet) -> int:
    for row_index in range(min(sheet.nrows, 100)):
        row = [_normalized(value) for value in sheet.row_values(row_index)]
        if "date/time" in row and any("temperature" in value for value in row):
            return row_index
    raise ReportTableImportError("Could not locate the report table header row.")


def import_report_table(path: str | Path) -> ParsedFile:
    source = Path(path)
    try:
        workbook = xlrd.open_workbook(str(source), on_demand=True)
    except (OSError, xlrd.XLRDError) as exc:
        raise ReportTableImportError(f"Could not read Excel file {source.name}: {exc}") from exc

    try:
        instrument_code: str | None = None
        header_sheet: xlrd.sheet.Sheet | None = None
        header_row = -1
        for sheet in workbook.sheets():
            for row_index in range(min(sheet.nrows, 10)):
                for value in sheet.row_values(row_index):
                    match = re.match(r"\s*Instrument\s+name:\s*(.+?)\s*$", str(value), re.I)
                    if match:
                        instrument_code = match.group(1)
            try:
                header_row = _find_header(sheet)
                header_sheet = sheet
                break
            except ReportTableImportError:
                continue

        if header_sheet is None:
            raise ReportTableImportError("No worksheet contains a recognized report table.")

        headers = [_normalized(value) for value in header_sheet.row_values(header_row)]
        timestamp_column = headers.index("date/time")
        temperature_column = next(
            index for index, value in enumerate(headers) if "temperature" in value
        )
        humidity_column = next(
            (index for index, value in enumerate(headers) if "humidity" in value), None
        )

        readings: list[Measurement] = []
        for row_index in range(header_row + 1, header_sheet.nrows):
            cells = header_sheet.row_values(row_index)
            if not any(value not in (None, "") for value in cells):
                continue
            relevant = [timestamp_column, temperature_column]
            if humidity_column is not None:
                relevant.append(humidity_column)
            if not any(index < len(cells) and cells[index] not in (None, "") for index in relevant):
                continue
            timestamp = (
                _timestamp(cells[timestamp_column], workbook.datemode)
                if timestamp_column < len(cells) and cells[timestamp_column] not in (None, "")
                else None
            )
            temperature = (
                _number(cells[temperature_column])
                if temperature_column < len(cells)
                else None
            )
            humidity = (
                _number(cells[humidity_column])
                if humidity_column is not None and humidity_column < len(cells)
                else None
            )
            readings.append(Measurement(timestamp, temperature, humidity))

        if not readings:
            raise ReportTableImportError("The report table contains no measurement rows.")
        return ParsedFile(
            file_name=source.name,
            format_name="Report_Table.xls (verified sample structure)",
            instrument_code=instrument_code,
            readings=tuple(readings),
        )
    finally:
        workbook.release_resources()