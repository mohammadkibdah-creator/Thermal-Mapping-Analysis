from __future__ import annotations

import math
import re
from datetime import datetime
from pathlib import Path
from zipfile import BadZipFile

from openpyxl import load_workbook
from openpyxl.utils.exceptions import InvalidFileException
from openpyxl.utils.datetime import from_excel

from ..domain import Measurement, ParsedMultiChannelFile


class SuperDAQImportError(ValueError):
    pass


def _timestamp(value: object, epoch) -> datetime | None:
    if value is None or (isinstance(value, str) and not value.strip()):
        return None
    if isinstance(value, datetime):
        return value.replace(tzinfo=None)
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        try:
            parsed = from_excel(value, epoch)
        except (ValueError, OverflowError) as exc:
            raise SuperDAQImportError(f"Invalid SuperDAQ Excel timestamp: {value!r}.") from exc
        if isinstance(parsed, datetime):
            return parsed.replace(tzinfo=None)
    if isinstance(value, str):
        for date_format in (
            "%m/%d/%Y %I:%M:%S %p",
            "%m/%d/%Y %H:%M:%S",
            "%Y-%m-%d %H:%M:%S",
            "%Y-%m-%d %H:%M",
        ):
            try:
                return datetime.strptime(value.strip(), date_format)
            except ValueError:
                continue
    raise SuperDAQImportError(f"Invalid SuperDAQ timestamp: {value!r}.")


def _measurement(value: object, channel: str, row_number: int) -> float | None:
    if value is None or (isinstance(value, str) and not value.strip()):
        return None
    try:
        result = float(value)
    except (TypeError, ValueError) as exc:
        raise SuperDAQImportError(
            f"{channel} row {row_number} contains a non-numeric measurement: {value!r}."
        ) from exc
    if not math.isfinite(result):
        raise SuperDAQImportError(
            f"{channel} row {row_number} contains a non-finite measurement: {value!r}."
        )
    return result


def _channel_header(value: object) -> str | None:
    if not isinstance(value, str):
        return None
    label = value.strip()
    if re.match(r"^Ch\s+\S", label, re.IGNORECASE):
        return label
    return None


def import_superdaq_file(path: str | Path) -> ParsedMultiChannelFile:
    source = Path(path)
    try:
        workbook = load_workbook(source, read_only=True, data_only=True)
    except (OSError, ValueError, BadZipFile, InvalidFileException) as exc:
        raise SuperDAQImportError(
            f"Could not read SuperDAQ Excel file {source.name}: {exc}"
        ) from exc

    try:
        selected = None
        timestamp_column = -1
        channel_columns: list[tuple[str, int]] = []
        for sheet in workbook.worksheets:
            for row_number, row in enumerate(
                sheet.iter_rows(min_row=1, max_row=min(sheet.max_row, 30), values_only=True),
                start=1,
            ):
                headers = list(row)
                time_index = next(
                    (
                        index for index, value in enumerate(headers)
                        if isinstance(value, str) and value.strip().casefold() == "time"
                    ),
                    None,
                )
                channels = [
                    (label, index)
                    for index, value in enumerate(headers)
                    if (label := _channel_header(value)) is not None
                ]
                if time_index is not None and channels:
                    selected = (sheet, row_number)
                    timestamp_column = time_index
                    channel_columns = channels
                    break
            if selected:
                break

        if selected is None:
            raise SuperDAQImportError(
                "No worksheet contains a SuperDAQ Time column and channel headers."
            )

        sheet, header_row = selected
        channel_names = [name for name, _ in channel_columns]
        if len({name.casefold() for name in channel_names}) != len(channel_names):
            raise SuperDAQImportError("The SuperDAQ export contains duplicate channel headers.")
        readings: dict[str, list[Measurement]] = {name: [] for name in channel_names}
        for row_number, row in enumerate(
            sheet.iter_rows(min_row=header_row + 1, values_only=True),
            start=header_row + 1,
        ):
            if not any(value is not None and value != "" for value in row):
                continue
            timestamp_value = row[timestamp_column] if timestamp_column < len(row) else None
            timestamp = _timestamp(timestamp_value, workbook.epoch) if timestamp_value is not None else None
            for channel, column in channel_columns:
                value = row[column] if column < len(row) else None
                temperature = _measurement(value, channel, row_number)
                readings[channel].append(Measurement(timestamp, temperature, None))

        if not any(readings.values()):
            raise SuperDAQImportError("The SuperDAQ export contains no measurement rows.")
        return ParsedMultiChannelFile(
            file_name=source.name,
            format_name="Fluke SuperDAQ Excel export (verified dat00001 structure)",
            channels={name: tuple(values) for name, values in readings.items()},
        )
    finally:
        workbook.close()
