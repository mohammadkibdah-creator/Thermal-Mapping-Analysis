from pathlib import Path

from .report_table import ReportTableImportError, import_report_table
from .superdaq import SuperDAQImportError, import_superdaq_file
from ..domain import ParsedFile


def import_data_file(path: str | Path) -> ParsedFile:
    source = Path(path)
    if source.suffix.lower() != ".xls":
        raise ReportTableImportError(
            "Only the verified Report_Table .xls format is currently supported. "
            "The second logger format has not been supplied."
        )
    return import_report_table(source)


__all__ = [
    "ReportTableImportError",
    "SuperDAQImportError",
    "import_data_file",
    "import_report_table",
    "import_superdaq_file",
]