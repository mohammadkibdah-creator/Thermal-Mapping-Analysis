from __future__ import annotations

import hashlib
import math
import re
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path
from zipfile import BadZipFile

from openpyxl import load_workbook
from openpyxl.utils.exceptions import InvalidFileException

from .calibration import CalibrationCurve, CalibrationError
from .domain import CorrectionConvention, CorrectionPoint
from .storage import parse_points


_NUMBER = re.compile(r"^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$")
_INDICATION = re.compile(
    r"^\s*(?:\(\s*([+-]?(?:\d+(?:\.\d*)?|\.\d+))\s*°?\s*C\s*\)"
    r"|([+-]?(?:\d+(?:\.\d*)?|\.\d+))\s*°?\s*C)\s*$",
    re.IGNORECASE,
)


@dataclass(frozen=True)
class SuperDAQEquipmentPreview:
    kit: dict
    sensors: tuple[dict, ...]
    issues: tuple[str, ...]
    already_imported: bool = False

    @property
    def can_import(self) -> bool:
        return not self.issues


def _empty(value: object) -> bool:
    return value is None or (isinstance(value, str) and not value.strip())


def _text(value: object) -> str:
    if isinstance(value, float) and math.isfinite(value) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def _date(value: object, row_number: int, field: str, issues: list[str]) -> str:
    if isinstance(value, datetime):
        return value.date().isoformat()
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, str) and value.strip():
        try:
            return date.fromisoformat(value.strip()).isoformat()
        except ValueError:
            pass
    issues.append(f"Equipment details row {row_number}: {field} must be a valid calendar date.")
    return ""


def _sensor_code(kit_serial: str, workbook_sensor_code: str) -> str:
    readable = re.sub(r"[^A-Z0-9]", "", f"SDQ{kit_serial}{workbook_sensor_code}".upper())
    if len(readable) <= 32:
        return readable
    digest = hashlib.sha256(
        f"{kit_serial}|{workbook_sensor_code}".encode("utf-8")
    ).hexdigest()[:16].upper()
    return f"SDQ{digest}"


def parse_superdaq_equipment_workbook(path: str | Path) -> SuperDAQEquipmentPreview:
    source = Path(path)
    try:
        workbook = load_workbook(source, read_only=True, data_only=True)
    except (OSError, ValueError, BadZipFile, InvalidFileException) as exc:
        raise ValueError(f"Could not read SuperDAQ equipment workbook {source.name}: {exc}") from exc

    issues: list[str] = []
    equipment_rows: dict[str, dict] = {}
    correction_groups: dict[tuple[str, str], list[dict]] = defaultdict(list)

    try:
        sheets = {sheet.title.strip().casefold(): sheet for sheet in workbook.worksheets}
        missing = {"equipment details", "corrections"} - sheets.keys()
        if missing:
            raise ValueError(
                "Workbook is missing required worksheet(s): "
                + ", ".join(sorted(missing))
                + "."
            )

        equipment_sheet = sheets["equipment details"]
        equipment_headers = {
            re.sub(r"[^a-z0-9]", "", str(value).casefold()): index
            for index, value in enumerate(next(equipment_sheet.iter_rows(
                min_row=1, max_row=1, values_only=True
            ), ()))
            if not _empty(value)
        }
        expected = {
            "kit name": "kitnamedescription",
            "kit serial number": "kitserialnumber",
            "sensor name": "sensorname",
            "serial number": "serialnumber",
            "sensor code": "sensorcode",
            "channel identifier": "superdaqchannelidentifier",
            "calibration date": "calibrationdate",
            "calibration due date": "calibrationduedate",
            "traceability": "traceability",
        }
        missing_headers = [label for label, key in expected.items() if key not in equipment_headers]
        if missing_headers:
            raise ValueError(
                "Equipment details worksheet is missing column(s): "
                + ", ".join(missing_headers)
                + "."
            )

        for row_number, row in enumerate(
            equipment_sheet.iter_rows(min_row=2, values_only=True), start=2
        ):
            if all(_empty(value) for value in row):
                continue
            values = {
                label: row[equipment_headers[key]] if equipment_headers[key] < len(row) else None
                for label, key in expected.items()
            }
            required_fields = (
                "kit name", "kit serial number", "sensor name", "serial number",
                "sensor code", "channel identifier", "traceability",
            )
            missing_fields = [field for field in required_fields if _empty(values[field])]
            if missing_fields:
                issues.append(
                    f"Equipment details row {row_number}: missing "
                    + ", ".join(missing_fields)
                    + "."
                )
                continue

            kit_name = _text(values["kit name"])
            kit_serial = _text(values["kit serial number"])
            sensor_name = _text(values["sensor name"])
            sensor_serial = _text(values["serial number"])
            workbook_sensor_code = _text(values["sensor code"])
            channel = _text(values["channel identifier"])
            traceability = _text(values["traceability"])
            calibration_date = _date(
                values["calibration date"], row_number, "Calibration Date", issues
            )
            due_date = _date(
                values["calibration due date"], row_number, "Calibration Due Date", issues
            )
            if calibration_date and due_date and due_date < calibration_date:
                issues.append(
                    f"Equipment details row {row_number}: Calibration Due Date precedes Calibration Date."
                )

            if kit_serial not in equipment_rows:
                equipment_rows[kit_serial] = {
                    "kit": {"name": kit_name, "serial_number": kit_serial},
                    "sensors_by_channel": {},
                }
            group = equipment_rows[kit_serial]
            if group["kit"]["name"] != kit_name:
                issues.append(
                    f"Equipment details row {row_number}: kit serial {kit_serial} has conflicting kit names."
                )

            if channel in group["sensors_by_channel"]:
                issues.append(
                    f"Equipment details row {row_number}: duplicate channel {channel!r} "
                    f"for kit serial {kit_serial}."
                )
                continue
            group["sensors_by_channel"][channel] = {
                "sensor_code": _sensor_code(kit_serial, workbook_sensor_code),
                "workbook_sensor_code": workbook_sensor_code,
                "name": sensor_name,
                "channel_identifier": channel,
                "serial_number": sensor_serial,
                "calibration_date": calibration_date,
                "due_date": due_date,
                "traceability": traceability,
                "temperature_convention": CorrectionConvention.INDICATION_PLUS_CORRECTION.value,
            }

        if not equipment_rows:
            issues.append("Equipment details worksheet contains no complete sensor records.")
        if len(equipment_rows) > 1:
            issues.append(
                "This import accepts one sensor kit per workbook; the workbook contains "
                f"{len(equipment_rows)} kit serial numbers."
            )

        correction_sheet = sheets["corrections"]
        correction_headers = {
            re.sub(r"[^a-z0-9]", "", str(value).casefold()): index
            for index, value in enumerate(next(correction_sheet.iter_rows(
                min_row=1, max_row=1, values_only=True
            ), ()))
            if not _empty(value)
        }
        correction_fields = {
            "kit serial number": "kitserialnumber",
            "channel identifier": "superdaqchannelidentifier",
        }
        missing_headers = [
            label for label, key in correction_fields.items() if key not in correction_headers
        ]
        indication_column = next(
            (index for key, index in correction_headers.items() if key.startswith("indication")),
            None,
        )
        correction_column = next(
            (index for key, index in correction_headers.items() if key.startswith("correction")),
            None,
        )
        if indication_column is None:
            missing_headers.append("Indication")
        if correction_column is None:
            missing_headers.append("Correction")
        if missing_headers:
            raise ValueError(
                "Corrections worksheet is missing column(s): "
                + ", ".join(missing_headers)
                + "."
            )

        for row_number, row in enumerate(
            correction_sheet.iter_rows(min_row=2, values_only=True), start=2
        ):
            if all(_empty(value) for value in row):
                continue
            serial_column = correction_headers["kitserialnumber"]
            channel_column = correction_headers["superdaqchannelidentifier"]
            raw_serial = row[serial_column] if serial_column < len(row) else None
            raw_channel = row[channel_column] if channel_column < len(row) else None
            raw_indication = row[indication_column] if indication_column < len(row) else None
            raw_correction = row[correction_column] if correction_column < len(row) else None
            if any(_empty(value) for value in (raw_serial, raw_channel, raw_indication, raw_correction)):
                issues.append(f"Corrections row {row_number}: populated correction row has missing values.")
                continue

            serial = _text(raw_serial)
            channel = _text(raw_channel)
            indication_text = _text(raw_indication)
            indication_match = _INDICATION.fullmatch(indication_text)
            if not indication_match:
                issues.append(
                    f"Corrections row {row_number}: malformed temperature indication "
                    f"{indication_text!r}; expected a numeric value with a C unit."
                )
                continue
            raw_numeric_correction = _text(raw_correction)
            if isinstance(raw_correction, bool) or not _NUMBER.fullmatch(raw_numeric_correction):
                issues.append(
                    f"Corrections row {row_number}: correction must be a finite numeric value."
                )
                continue
            indication = float(indication_match.group(1) or indication_match.group(2))
            correction = float(raw_numeric_correction)
            if not math.isfinite(indication) or not math.isfinite(correction):
                issues.append(
                    f"Corrections row {row_number}: indication and correction must be finite numbers."
                )
                continue
            if serial not in equipment_rows:
                issues.append(
                    f"Corrections row {row_number}: kit serial {serial!r} has no exact match "
                    "in Equipment details; this point was not assigned."
                )
                continue
            if channel not in equipment_rows[serial]["sensors_by_channel"]:
                issues.append(
                    f"Corrections row {row_number}: channel {channel!r} has no exact match "
                    f"for kit serial {serial}; this point was not assigned."
                )
                continue
            correction_groups[(serial, channel)].append({
                "indication": indication,
                "correction": correction,
                "source_indication": indication_text,
                "source_correction": raw_numeric_correction,
                "source_row": row_number,
            })

        if len(equipment_rows) == 1:
            serial, group = next(iter(equipment_rows.items()))
            sensors: list[dict] = []
            seen_codes: dict[str, str] = {}
            for channel, sensor in group["sensors_by_channel"].items():
                code = sensor["sensor_code"]
                if code in seen_codes:
                    issues.append(
                        f"Equipment details: Sensor Code values for {seen_codes[code]!r} and "
                        f"{channel!r} produce the same registry sensor code {code}."
                    )
                seen_codes[code] = channel
                points = correction_groups.get((serial, channel), [])
                if len(points) < 2:
                    issues.append(
                        f"{channel}: at least two temperature correction points are required; "
                        f"found {len(points)}."
                    )
                duplicate_indications = sorted(
                    value for value, count in Counter(
                        point["indication"] for point in points
                    ).items() if count > 1
                )
                if duplicate_indications:
                    issues.append(
                        f"{channel}: duplicate temperature indication(s): "
                        + ", ".join(str(value) for value in duplicate_indications)
                        + "."
                    )
                try:
                    CalibrationCurve(
                        [CorrectionPoint(point["indication"], point["correction"]) for point in points],
                        CorrectionConvention.INDICATION_PLUS_CORRECTION,
                    )
                except CalibrationError as exc:
                    issues.append(f"{channel}: invalid temperature correction curve: {exc}")
                sensor["temperature_points"] = tuple(points)
                sensors.append(sensor)
            return SuperDAQEquipmentPreview(
                kit=group["kit"],
                sensors=tuple(sensors),
                issues=tuple(issues),
            )

        return SuperDAQEquipmentPreview(
            kit={"name": "", "serial_number": ""},
            sensors=(),
            issues=tuple(issues),
        )
    finally:
        workbook.close()


def registry_import_status(
    preview: SuperDAQEquipmentPreview,
    kits: list[dict],
    sensors: list[dict],
) -> tuple[tuple[str, ...], str | None]:
    issues = list(preview.issues)
    serial = preview.kit["serial_number"].casefold()
    matching_kits = [
        kit for kit in kits
        if kit.get("serial_number", "").strip().casefold() == serial
    ]
    if len(matching_kits) > 1:
        issues.append(
            f"Kit serial number {preview.kit['serial_number']} is already assigned to multiple registered kits."
        )
    elif matching_kits:
        kit = matching_kits[0]
        registered = [
            sensor for sensor in sensors if sensor["kit_code"] == kit["kit_code"]
        ]
        expected_by_channel = {
            sensor["channel_identifier"]: sensor for sensor in preview.sensors
        }
        registered_by_channel = {
            sensor["channel_identifier"]: sensor for sensor in registered
        }
        identical = (
            kit["name"] == preview.kit["name"]
            and len(registered) == len(preview.sensors)
            and set(registered_by_channel) == set(expected_by_channel)
        )
        if identical:
            for channel, expected in expected_by_channel.items():
                actual = registered_by_channel[channel]
                try:
                    actual_points = parse_points(actual["temperature_points_json"])
                except (ValueError, KeyError, TypeError):
                    identical = False
                    break
                expected_points = [
                    {"indication": point["indication"], "correction": point["correction"]}
                    for point in expected["temperature_points"]
                ]
                if any(
                    actual.get(field, "") != expected.get(field, "")
                    for field in (
                        "name", "serial_number", "calibration_date", "due_date",
                        "traceability", "temperature_convention",
                    )
                ) or actual_points != expected_points:
                    identical = False
                    break
        if identical:
            return tuple(issues), kit["kit_code"]
        issues.append(
            f"Kit serial number {preview.kit['serial_number']} already exists with different "
            "kit or sensor data; the import will not overwrite it."
        )
    else:
        registered_codes = {sensor["sensor_code"].casefold() for sensor in sensors}
        for sensor in preview.sensors:
            if sensor["sensor_code"].casefold() in registered_codes:
                issues.append(
                    f"Generated sensor code {sensor['sensor_code']} already exists in the registry."
                )
    return tuple(issues), None
