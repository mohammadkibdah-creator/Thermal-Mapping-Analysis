from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import Enum
import math


class AnalysisMode(str, Enum):
    TEMPERATURE = "temperature"
    TEMPERATURE_AND_HUMIDITY = "temperature_and_humidity"


class CorrectionConvention(str, Enum):
    INDICATION_PLUS_CORRECTION = "indication_plus_correction"
    INDICATION_MINUS_CORRECTION = "indication_minus_correction"


@dataclass(frozen=True)
class CorrectionPoint:
    indication: float
    correction: float


@dataclass(frozen=True)
class CorrectionResult:
    indication: float
    correction: float
    corrected_value: float
    extrapolated: bool
    calibration_range: tuple[float, float]


@dataclass(frozen=True)
class Measurement:
    timestamp: datetime | None
    temperature: float | None
    humidity: float | None


@dataclass(frozen=True)
class ParsedFile:
    file_name: str
    format_name: str
    instrument_code: str | None
    readings: tuple[Measurement, ...]


@dataclass(frozen=True)
class ParsedMultiChannelFile:
    file_name: str
    format_name: str
    channels: dict[str, tuple[Measurement, ...]]


@dataclass(frozen=True)
class ChannelLimits:
    lower: float
    upper: float

    def __post_init__(self) -> None:
        if not math.isfinite(self.lower) or not math.isfinite(self.upper):
            raise ValueError("Limits must be finite numbers.")
        if self.lower >= self.upper:
            raise ValueError("The lower limit must be less than the upper limit.")


@dataclass(frozen=True)
class ChannelResult:
    mean: float
    minimum: float
    maximum: float
    sample_standard_deviation: float
    below_minutes: float
    below_percent: float
    above_minutes: float
    above_percent: float


@dataclass(frozen=True)
class LoggerResult:
    equipment_code: str
    temperature: ChannelResult
    humidity: ChannelResult | None


@dataclass(frozen=True)
class LoggerSeries:
    equipment_code: str
    timestamps: tuple[datetime, ...]
    temperatures: tuple[float, ...]
    humidities: tuple[float, ...] = ()
    original_temperatures: tuple[float, ...] = ()
    temperature_corrections: tuple[float, ...] = ()
    original_humidities: tuple[float, ...] = ()
    humidity_corrections: tuple[float, ...] = ()


@dataclass(frozen=True)
class StudyResults:
    logger_results: tuple[LoggerResult, ...]
    global_temperature_mean: float
    global_humidity_mean: float | None
    warnings: tuple[str, ...]
    series: tuple[LoggerSeries, ...] = ()