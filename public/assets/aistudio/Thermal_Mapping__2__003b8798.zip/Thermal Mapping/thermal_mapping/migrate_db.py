from __future__ import annotations

import argparse
import sqlite3
from pathlib import Path

from .storage import connect, initialize_database, is_postgresql


TABLES = (
    "settings",
    "equipment",
    "sensor_kits",
    "superdaq_sensors",
    "users",
    "equipment_calibration_history",
    "sensor_calibration_history",
    "audit_log",
)


def migrate(source: str | Path, target: str) -> None:
    if not is_postgresql(target):
        raise ValueError("The migration target must be a PostgreSQL DATABASE_URL.")
    initialize_database(target)
    source_connection = sqlite3.connect(str(source))
    source_connection.row_factory = sqlite3.Row
    target_connection = connect(target)
    try:
        for table in TABLES:
            columns = [
                row["name"]
                for row in source_connection.execute(f"PRAGMA table_info({table})").fetchall()
            ]
            if not columns:
                continue
            quoted_columns = ", ".join(columns)
            placeholders = ", ".join("?" for _ in columns)
            rows = source_connection.execute(
                f"SELECT {quoted_columns} FROM {table}"
            ).fetchall()
            for row in rows:
                target_connection.execute(
                    f"INSERT INTO {table} ({quoted_columns}) VALUES ({placeholders}) "
                    "ON CONFLICT DO NOTHING",
                    tuple(row[column] for column in columns),
                )
        target_connection.commit()
    finally:
        target_connection.close()
        source_connection.close()


def main() -> None:
    parser = argparse.ArgumentParser(description="Copy the local SQLite master database to PostgreSQL.")
    parser.add_argument("--source", required=True, help="Path to the existing SQLite database.")
    parser.add_argument("--target", required=True, help="PostgreSQL DATABASE_URL.")
    args = parser.parse_args()
    migrate(args.source, args.target)
    print("Database migration completed.")


if __name__ == "__main__":
    main()
