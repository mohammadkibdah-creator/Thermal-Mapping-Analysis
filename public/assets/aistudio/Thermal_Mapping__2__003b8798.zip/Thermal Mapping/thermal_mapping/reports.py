from __future__ import annotations

import os
import re
import tempfile
import uuid
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from openpyxl import Workbook
from openpyxl.chart import LineChart, Reference
from openpyxl.chart.axis import DateAxis
from openpyxl.styles import Alignment, Border, Font, Side
from openpyxl.utils import get_column_letter

from . import __version__
from .domain import AnalysisMode, ChannelLimits, CorrectionConvention, CorrectionPoint, StudyResults


@dataclass(frozen=True)
class LoggerReportSnapshot:
    equipment_code: str
    description: str
    serial_number: str
    traceability: str
    calibration_date: str
    due_date: str
    temperature_points: tuple[CorrectionPoint, ...]
    temperature_convention: CorrectionConvention
    humidity_points: tuple[CorrectionPoint, ...] = ()
    humidity_convention: CorrectionConvention | None = None
    source_channel: str = ""
    position: str = ""
    certificate_number: str = ""
    provider: str = ""
    sensor_name: str = ""


def _safe_stem(study_name: str, generated_at: datetime) -> str:
    if study_name.strip():
        cleaned = re.sub(r"[^A-Za-z0-9._-]+", "_", study_name.strip()).strip("._-")
        return cleaned[:100] or "Thermal_Mapping"
    return generated_at.strftime("Thermal_Mapping_%Y%m%d_%H%M%S")


def _unique_path(directory: Path, stem: str) -> Path:
    candidate = directory / f"{stem}.xlsx"
    suffix = 1
    while candidate.exists():
        candidate = directory / f"{stem}_{suffix:02d}.xlsx"
        suffix += 1
    return candidate


def _style_sheet(sheet, widths: tuple[int, ...] | None = None) -> None:
    thin_gray = Side(style="thin", color="B7C2CC")
    for cell in sheet[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = __import__("openpyxl").styles.PatternFill("solid", fgColor="31565B")
        cell.alignment = Alignment(vertical="center", wrap_text=True)
    for row in sheet.iter_rows(min_row=2):
        for cell in row:
            cell.border = Border(bottom=thin_gray)
            cell.alignment = Alignment(vertical="top", wrap_text=True)
    if widths:
        for index, width in enumerate(widths, 1):
            sheet.column_dimensions[get_column_letter(index)].width = width
    else:
        for column in sheet.columns:
            letter = get_column_letter(column[0].column)
            longest = max((len(str(cell.value or "")) for cell in column), default=10)
            sheet.column_dimensions[letter].width = min(max(longest + 2, 12), 48)
    sheet.freeze_panes = "A2"
    sheet.sheet_view.showGridLines = False
    sheet.page_setup.orientation = "landscape"
    sheet.page_setup.fitToWidth = 1
    sheet.page_setup.fitToHeight = 0
    sheet.sheet_properties.pageSetUpPr.fitToPage = True


def _set_numeric_formats(sheet) -> None:
    for row in sheet.iter_rows(min_row=2):
        for cell in row:
            if isinstance(cell.value, float):
                cell.number_format = "0.00"


def _sensor_sheet_name(code: str, used_names: set[str]) -> str:
    cleaned = re.sub(r"[\[\]:*?/\\]", "_", code.strip()) or "Sensor"
    cleaned = cleaned[:31]
    candidate = cleaned
    suffix = 1
    while candidate in used_names:
        suffix_text = f"_{suffix}"
        candidate = f"{cleaned[:31 - len(suffix_text)]}{suffix_text}"
        suffix += 1
    used_names.add(candidate)
    return candidate


def _date_time_chart(sheet, *, title: str, data_columns: tuple[int, ...], time_column: int, max_row: int) -> LineChart:
    chart = LineChart()
    chart.title = title
    chart.y_axis.title = "Corrected value"
    chart.x_axis = DateAxis(crossAx=100)
    chart.x_axis.title = "Date & Time"
    chart.x_axis.number_format = "yyyy-mm-dd hh:mm"
    chart.height = 8
    chart.width = 18
    chart.style = 13
    categories = Reference(sheet, min_col=time_column, min_row=2, max_row=max_row)
    for column in data_columns:
        chart.add_data(
            Reference(sheet, min_col=column, max_col=column, min_row=1, max_row=max_row),
            titles_from_data=True,
        )
    chart.set_categories(categories)
    chart.legend.position = "b"
    return chart


def _append_sensor_sheet(
    workbook: Workbook,
    series,
    *,
    mode: AnalysisMode,
    temperature_limits: ChannelLimits,
    humidity_limits: ChannelLimits | None,
    used_names: set[str],
) -> None:
    reading_count = len(series.timestamps)
    required_lengths = (
        len(series.original_temperatures),
        len(series.temperature_corrections),
        len(series.temperatures),
    )
    if any(length != reading_count for length in required_lengths):
        raise ValueError(
            f"Detailed corrected readings are unavailable for {series.equipment_code}; run the study again."
        )
    if mode is AnalysisMode.TEMPERATURE_AND_HUMIDITY and any(
        length != reading_count
        for length in (
            len(series.original_humidities),
            len(series.humidity_corrections),
            len(series.humidities),
        )
    ):
        raise ValueError(
            f"Detailed corrected humidity readings are unavailable for {series.equipment_code}; run the study again."
        )
    sheet = workbook.create_sheet(_sensor_sheet_name(series.equipment_code, used_names))
    headers = [
        "Date", "Time", "Date & Time",
        "Original Temperature (°C)", "Temperature Correction (°C)", "Corrected Temperature (°C)",
    ]
    if mode is AnalysisMode.TEMPERATURE_AND_HUMIDITY:
        headers.extend([
            "Original Relative Humidity (%RH)", "RH Correction (%RH)", "Corrected Relative Humidity (%RH)",
        ])
    headers.extend(["LTL (°C)", "UTL (°C)"])
    if mode is AnalysisMode.TEMPERATURE_AND_HUMIDITY:
        headers.extend(["LRL (%RH)", "URL (%RH)"])
    sheet.append(headers)

    for index, timestamp in enumerate(series.timestamps):
        row = [
            timestamp.date(),
            timestamp.time(),
            timestamp,
            series.original_temperatures[index],
            series.temperature_corrections[index],
            series.temperatures[index],
        ]
        if mode is AnalysisMode.TEMPERATURE_AND_HUMIDITY:
            row.extend([
                series.original_humidities[index],
                series.humidity_corrections[index],
                series.humidities[index],
            ])
        row.extend([temperature_limits.lower, temperature_limits.upper])
        if mode is AnalysisMode.TEMPERATURE_AND_HUMIDITY:
            row.extend([humidity_limits.lower, humidity_limits.upper])
        sheet.append(row)

    sheet.auto_filter.ref = sheet.dimensions
    _style_sheet(sheet)
    for row in sheet.iter_rows(min_row=2):
        row[0].number_format = "yyyy-mm-dd"
        row[1].number_format = "hh:mm:ss"
        row[2].number_format = "yyyy-mm-dd hh:mm:ss"
    _set_numeric_formats(sheet)

    max_row = sheet.max_row
    if mode is AnalysisMode.TEMPERATURE:
        chart = _date_time_chart(
            sheet,
            title=f"{series.equipment_code} — Corrected Temperature",
            data_columns=(6, 7, 8),
            time_column=3,
            max_row=max_row,
        )
        chart.y_axis.title = "Temperature (°C)"
        sheet.add_chart(chart, "M2")
        return

    temperature_chart = _date_time_chart(
        sheet,
        title=f"{series.equipment_code} — Corrected Temperature and RH",
        data_columns=(6, 10, 11),
        time_column=3,
        max_row=max_row,
    )
    temperature_chart.y_axis.title = "Temperature (°C)"
    humidity_chart = _date_time_chart(
        sheet,
        title="Relative Humidity",
        data_columns=(9, 12, 13),
        time_column=3,
        max_row=max_row,
    )
    humidity_chart.y_axis.title = "Relative Humidity (%RH)"
    humidity_chart.y_axis.axId = 200
    humidity_chart.y_axis.crosses = "max"
    temperature_chart += humidity_chart
    sheet.add_chart(temperature_chart, "O2")


def generate_report(
    output_directory: str | Path,
    *,
    study_name: str,
    start: datetime,
    end: datetime,
    sampling_interval_minutes: int,
    mode: AnalysisMode,
    temperature_limits: ChannelLimits,
    humidity_limits: ChannelLimits | None,
    snapshots: tuple[LoggerReportSnapshot, ...],
    results: StudyResults,
    warnings: tuple[str, ...] = (),
    expired_certificate_confirmed: bool = False,
    requested_start: datetime | None = None,
    requested_end: datetime | None = None,
    acquisition_system: str = "Data Logger",
    sensor_kit: str = "",
    output_name: str | None = None,
) -> tuple[Path, str]:
    destination = Path(output_directory)
    if not destination.is_dir():
        raise OSError(f"Report destination is unavailable: {destination}")
    generated_at = datetime.now().astimezone()
    report_id = str(uuid.uuid4())
    stem = _safe_stem(output_name or study_name, generated_at)
    workbook = Workbook()

    information = workbook.active
    information.title = "Study Information"
    information.append(["Field", "Value"])
    duration_minutes = (end - start).total_seconds() / 60
    info_rows = [
        ("Study name", study_name.strip() or "Not provided"),
        ("Unique report ID", report_id),
        ("Study start", start.strftime("%Y-%m-%d %H:%M:%S")),
        ("Study end", end.strftime("%Y-%m-%d %H:%M:%S")),
        ("Requested study start", requested_start.strftime("%Y-%m-%d %H:%M:%S") if requested_start else start.strftime("%Y-%m-%d %H:%M:%S")),
        ("Requested study end", requested_end.strftime("%Y-%m-%d %H:%M:%S") if requested_end else end.strftime("%Y-%m-%d %H:%M:%S")),
        ("Total study duration (h)", duration_minutes / 60),
        ("Sampling interval (min)", sampling_interval_minutes),
        ("Analysis mode", "Temperature Only" if mode is AnalysisMode.TEMPERATURE else "Temperature and Relative Humidity"),
        ("Acquisition system", acquisition_system),
        ("Sensor kit", sensor_kit or "Not applicable"),
        ("Temperature limits (°C)", f"{temperature_limits.lower:g} to {temperature_limits.upper:g}"),
        ("RH limits (%RH)", f"{humidity_limits.lower:g} to {humidity_limits.upper:g}" if humidity_limits else "Not applicable"),
        (
            "Data Loggers included" if acquisition_system == "Data Logger" else "Sensors included",
            len(snapshots),
        ),
        ("Report generated", generated_at.strftime("%Y-%m-%d %H:%M:%S %Z")),
        ("Server timezone", generated_at.tzname() or "Local timezone"),
        ("Software version", __version__),
        ("Expired certificate confirmation", "Confirmed" if expired_certificate_confirmed else "Not required"),
    ]
    for row in info_rows:
        information.append(row)
    _style_sheet(information, (36, 72))

    temperature = workbook.create_sheet("Temperature Results")
    temperature.append([
        "Sensors", "MKT (°C)", "Min (°C)", "Max (°C)", "Mean", "Standard deviation",
        "Safe range", "Accumulated time below lower alert (min)", "% below lower alert",
        "Accumulated time above upper alert (min)", "% above upper alert",
    ])
    for item in results.logger_results:
        result = item.temperature
        temperature.append([
            item.equipment_code,
            result.mean,
            result.minimum,
            result.maximum,
            results.global_temperature_mean,
            result.sample_standard_deviation,
            f"{temperature_limits.lower:g} to {temperature_limits.upper:g} °C",
            result.below_minutes,
            result.below_percent,
            result.above_minutes,
            result.above_percent,
        ])
    _style_sheet(temperature, (16, 14, 12, 12, 12, 18, 24, 30, 20, 32, 20))
    _set_numeric_formats(temperature)

    if mode is AnalysisMode.TEMPERATURE_AND_HUMIDITY:
        humidity = workbook.create_sheet("Relative Humidity Results")
        humidity.append([
            "Sensors", "Average corrected RH (%RH)", "Min (%RH)", "Max (%RH)",
            "Global Mean (%RH)", "Standard deviation", "Safe range",
            "Accumulated time below lower alert (min)", "% below lower alert",
            "Accumulated time above upper alert (min)", "% above upper alert",
        ])
        for item in results.logger_results:
            result = item.humidity
            humidity.append([
                item.equipment_code,
                result.mean,
                result.minimum,
                result.maximum,
                results.global_humidity_mean,
                result.sample_standard_deviation,
                f"{humidity_limits.lower:g} to {humidity_limits.upper:g} %RH",
                result.below_minutes,
                result.below_percent,
                result.above_minutes,
                result.above_percent,
            ])
        _style_sheet(humidity, (16, 24, 12, 12, 20, 18, 24, 30, 20, 32, 20))
        _set_numeric_formats(humidity)

    device_sheet = workbook.create_sheet(
        "Data Logger Information" if acquisition_system == "Data Logger" else "SuperDAQ Sensor Information"
    )
    if acquisition_system == "Data Logger":
        device_sheet.append(["No.", "Reference Standard Description", "Serial No.", "Traceability", "Cal. Date", "Due Date"])
    else:
        device_sheet.append([
            "No.", "Sensor Code", "Sensor Name", "SuperDAQ Channel", "Position",
            "Serial No.", "Traceability", "Cal. Date", "Due Date", "Kit",
        ])
    for index, snapshot in enumerate(snapshots, 1):
        description = snapshot.description.strip()
        if snapshot.equipment_code not in description:
            description = f"{description} ({snapshot.equipment_code})"
        if acquisition_system == "Data Logger":
            device_sheet.append([
                index, description, snapshot.serial_number, snapshot.traceability,
                snapshot.calibration_date, snapshot.due_date,
            ])
        else:
            device_sheet.append([
                index, snapshot.equipment_code, snapshot.sensor_name or snapshot.description,
                snapshot.source_channel, snapshot.position, snapshot.serial_number,
                snapshot.traceability, snapshot.calibration_date, snapshot.due_date, sensor_kit,
            ])
    _style_sheet(device_sheet, (8, 18, 24, 22, 20, 24, 28, 18, 18, 16))

    calibration = workbook.create_sheet("Calibration Snapshot")
    calibration.append([
        "Equipment / Sensor", "Channel", "Correction convention", "Indication", "Correction"
    ])
    for snapshot in snapshots:
        channel_name = (
            f"Temperature ({snapshot.source_channel})"
            if snapshot.source_channel else "Temperature"
        )
        channels = [(channel_name, snapshot.temperature_points, snapshot.temperature_convention)]
        if snapshot.humidity_points:
            channels.append(("Relative humidity", snapshot.humidity_points, snapshot.humidity_convention))
        for channel, points, convention in channels:
            for point in points:
                calibration.append([
                    snapshot.equipment_code,
                    channel,
                    convention.value if convention else "Not configured",
                    point.indication,
                    point.correction,
                ])
    _style_sheet(calibration, (18, 22, 38, 16, 16))
    _set_numeric_formats(calibration)

    warning_sheet = workbook.create_sheet("Warnings and Validation")
    warning_sheet.append(["Type", "Details"])
    warning_sheet.append(["Validation", "All mandatory data validation checks passed."])
    if expired_certificate_confirmed:
        warning_sheet.append(["Calibration", "Expired certificate use was explicitly confirmed by the user; this does not establish metrological suitability."])
    for message in tuple(results.warnings) + tuple(warnings):
        warning_sheet.append(["Warning", message])
    _style_sheet(warning_sheet, (24, 120))

    used_names = {sheet.title for sheet in workbook.worksheets}
    for series in results.series:
        _append_sensor_sheet(
            workbook,
            series,
            mode=mode,
            temperature_limits=temperature_limits,
            humidity_limits=humidity_limits,
            used_names=used_names,
        )

    for sheet in workbook.worksheets:
        sheet.print_title_rows = "1:1"
        sheet.sheet_properties.pageSetUpPr.fitToPage = True

    temporary_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            prefix=".thermal_mapping_", suffix=".tmp.xlsx", dir=destination, delete=False
        ) as temporary:
            temporary_path = Path(temporary.name)
        workbook.save(temporary_path)
        while True:
            final_path = _unique_path(destination, stem)
            try:
                os.rename(temporary_path, final_path)
                temporary_path = None
                break
            except FileExistsError:
                continue
        return final_path, report_id
    finally:
        if temporary_path is not None:
            temporary_path.unlink(missing_ok=True)