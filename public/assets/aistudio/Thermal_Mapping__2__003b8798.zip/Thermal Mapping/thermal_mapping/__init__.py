"""Thermal mapping analysis package."""

__version__ = "0.1.0"