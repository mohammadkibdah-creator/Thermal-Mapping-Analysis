from __future__ import annotations

import os
from contextlib import contextmanager
from pathlib import Path
from typing import IO, Iterator


class AnalysisAlreadyRunning(RuntimeError):
    pass


def _acquire(file: IO[bytes]) -> None:
    file.seek(0)
    if os.name == "nt":
        import msvcrt

        try:
            msvcrt.locking(file.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError as exc:
            raise AnalysisAlreadyRunning("Another analysis is already in progress.") from exc
    else:
        import fcntl

        try:
            fcntl.flock(file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise AnalysisAlreadyRunning("Another analysis is already in progress.") from exc


def _release(file: IO[bytes]) -> None:
    file.seek(0)
    if os.name == "nt":
        import msvcrt

        msvcrt.locking(file.fileno(), msvcrt.LK_UNLCK, 1)
    else:
        import fcntl

        fcntl.flock(file.fileno(), fcntl.LOCK_UN)


def analysis_is_running(path: str | Path) -> bool:
    lock_path = Path(path)
    if not lock_path.exists():
        return False
    with lock_path.open("a+b") as lock_file:
        try:
            _acquire(lock_file)
        except AnalysisAlreadyRunning:
            return True
        _release(lock_file)
        return False


@contextmanager
def analysis_lock(path: str | Path) -> Iterator[None]:
    lock_path = Path(path)
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    with lock_path.open("a+b") as lock_file:
        _acquire(lock_file)
        try:
            lock_file.seek(0)
            lock_file.truncate()
            lock_file.write(f"{os.getpid()}\n".encode("ascii"))
            lock_file.flush()
            yield
        finally:
            _release(lock_file)