from __future__ import annotations

import os
from pathlib import Path

from .storage import initialize_database


def main() -> None:
    default_path = Path(__file__).resolve().parents[1] / "instance" / "thermal_mapping.sqlite3"
    database_value = os.environ.get("DATABASE_URL") or os.environ.get(
        "THERMAL_MAPPING_DATABASE", str(default_path)
    )
    database_path = database_value
    initialize_database(database_path)
    print(f"Database initialized: {database_path}")


if __name__ == "__main__":
    main()