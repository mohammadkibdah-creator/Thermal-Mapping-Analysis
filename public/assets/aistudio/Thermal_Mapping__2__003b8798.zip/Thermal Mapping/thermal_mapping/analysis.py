from __future__ import annotations

import math
import statistics
from dataclasses import dataclass
from datetime import datetime, timedelta

from .calibration import CalibrationCurve
from .domain import (
    AnalysisMode,
    ChannelLimits,
    ChannelResult,
    LoggerResult,
    LoggerSeries,
    ParsedFile,
    StudyResults,
)


class StudyValidationError(ValueError):
    def __init__(self, issues: list[str] | tuple[str, ...]) -> None:
        self.issues = tuple(issues)
        super().__init__("\n".join(self.issues))


@dataclass(frozen=True)
class AssignedLogger:
    equipment_code: str
    parsed_file: ParsedFile
    temperature_curve: CalibrationCurve
    humidity_curve: CalibrationCurve | None = None


def snap_study_boundaries(
    loggers: list[AssignedLogger] | tuple[AssignedLogger, ...],
    requested_start: datetime,
    requested_end: datetime,
) -> tuple[datetime, datetime, tuple[str, ...]]:
    if not loggers:
        raise StudyValidationError(["At least one Data Logger file must be assigned."])
    if requested_start.tzinfo is not None or requested_end.tzinfo is not None:
        raise StudyValidationError(["Study timestamps must use the server's local timezone (naive timestamps)."])

    timestamp_sets: list[set[datetime]] = []
    for logger in loggers:
        timestamps = [reading.timestamp for reading in logger.parsed_file.readings]
        if any(timestamp is None for timestamp in timestamps):
            raise StudyValidationError([
                f"Data Logger {logger.equipment_code}: timestamps must be valid before study boundaries can be selected."
            ])
        timestamp_sets.append(set(timestamps))

    common_timestamps = set.intersection(*timestamp_sets)
    if not common_timestamps:
        raise StudyValidationError([
            "Assigned Data Loggers do not share any timestamps, so common study boundaries cannot be selected."
        ])

    warnings: list[str] = []

    def next_boundary(requested: datetime, label: str) -> datetime:
        if requested in common_timestamps:
            return requested

        later = [timestamp for timestamp in common_timestamps if timestamp > requested]
        if not later:
            raise StudyValidationError([
                f"Requested study {label} {requested.isoformat(sep=' ')} is outside the recorded range. "
                "The next shared recorded timestamp does not exist."
            ])
        selected = min(later)
        difference = selected - requested
        warnings.append(
            f"Requested study {label} {requested.isoformat(sep=' ')} was rounded up to the next shared "
            f"recorded timestamp {selected.isoformat(sep=' ')} (difference {difference})."
        )
        return selected

    effective_start = next_boundary(requested_start, "start")
    effective_end = next_boundary(requested_end, "end")
    if effective_end <= effective_start:
        raise StudyValidationError([
            "Rounded study boundaries do not form a positive study duration. Adjust the requested start or end."
        ])
    return effective_start, effective_end, tuple(warnings)


def infer_sampling_interval_minutes(
    loggers: list[AssignedLogger] | tuple[AssignedLogger, ...],
) -> int:
    if not loggers:
        raise StudyValidationError(["At least one Data Logger file must be assigned."])
    intervals: list[timedelta] = []
    for logger in loggers:
        timestamps = sorted(
            reading.timestamp
            for reading in logger.parsed_file.readings
            if reading.timestamp is not None
        )
        if len(timestamps) < 2:
            raise StudyValidationError([
                f"Data Logger {logger.equipment_code}: at least two timestamped readings are required "
                "to determine the sampling interval."
            ])
        interval = timestamps[1] - timestamps[0]
        if interval <= timedelta(0):
            raise StudyValidationError([
                f"Data Logger {logger.equipment_code}: the first two readings do not define a positive sampling interval."
            ])
        intervals.append(interval)
    if any(interval != intervals[0] for interval in intervals[1:]):
        raise StudyValidationError([
            "Assigned Data Loggers use different sampling intervals. The system cannot determine one "
            "sampling interval for the study."
        ])
    seconds = intervals[0].total_seconds()
    return max(1, int(seconds / 60 + 0.5))


def _validate_grid(
    code: str,
    parsed_file: ParsedFile,
    start: datetime,
    end: datetime,
    interval: timedelta,
    mode: AnalysisMode,
    strict_grid: bool = True,
) -> tuple[list, list[str]]:
    issues: list[str] = []
    if any(reading.timestamp is None for reading in parsed_file.readings):
        issues.append(f"Data Logger {code}: one or more measurement timestamps are invalid.")
        return [], issues

    readings = sorted(parsed_file.readings, key=lambda reading: reading.timestamp)
    timestamps = [reading.timestamp for reading in readings]
    if len(set(timestamps)) != len(timestamps):
        issues.append(f"Data Logger {code}: duplicate timestamps were found in the file.")
        return [], issues

    window = [reading for reading in readings if start <= reading.timestamp <= end]
    window_timestamps = {reading.timestamp for reading in window}
    if start not in window_timestamps:
        issues.append(f"Data Logger {code}: required study start {start.isoformat(sep=' ')} is missing.")
    if end not in window_timestamps:
        issues.append(f"Data Logger {code}: required study end {end.isoformat(sep=' ')} is missing.")

    if strict_grid:
        expected_count = int((end - start) / interval) + 1
        for index in range(expected_count):
            expected = start + index * interval
            if expected not in window_timestamps:
                issues.append(
                    f"Data Logger {code}: missing expected reading at {expected.isoformat(sep=' ')}. "
                    f"Expected sampling interval: {int(interval.total_seconds() // 60)} minutes. "
                    "Analysis cannot proceed."
                )

    for reading in window:
        if reading.temperature is None or not math.isfinite(reading.temperature):
            issues.append(
                f"Data Logger {code}: missing or invalid temperature at "
                f"{reading.timestamp.isoformat(sep=' ')}."
            )
        if mode is AnalysisMode.TEMPERATURE_AND_HUMIDITY and (
            reading.humidity is None or not math.isfinite(reading.humidity)
        ):
            issues.append(
                f"Data Logger {code}: missing or invalid relative humidity at "
                f"{reading.timestamp.isoformat(sep=' ')}."
            )
    if len(window) < 2:
        issues.append(
            f"Data Logger {code}: fewer than two measurements are available; "
            "sample standard deviation cannot be calculated."
        )
    return window, issues


def _channel_result(
    values: list[float],
    timestamps: list[datetime],
    interval: timedelta,
    study_start: datetime,
    study_end: datetime,
    limits: ChannelLimits,
) -> ChannelResult:
    duration_minutes = (study_end - study_start).total_seconds() / 60
    below_minutes = 0.0
    above_minutes = 0.0
    for timestamp, value in zip(timestamps, values):
        interval_end = min(timestamp + interval, study_end)
        counted_minutes = max(0.0, (interval_end - max(timestamp, study_start)).total_seconds() / 60)
        if value < limits.lower:
            below_minutes += counted_minutes
        elif value > limits.upper:
            above_minutes += counted_minutes

    return ChannelResult(
        mean=statistics.fmean(values),
        minimum=min(values),
        maximum=max(values),
        sample_standard_deviation=statistics.stdev(values),
        below_minutes=below_minutes,
        below_percent=below_minutes / duration_minutes * 100,
        above_minutes=above_minutes,
        above_percent=above_minutes / duration_minutes * 100,
    )


def analyze_study(
    loggers: list[AssignedLogger] | tuple[AssignedLogger, ...],
    *,
    start: datetime,
    end: datetime,
    sampling_interval_minutes: int,
    mode: AnalysisMode,
    temperature_limits: ChannelLimits,
    humidity_limits: ChannelLimits | None = None,
    strict_grid: bool = True,
) -> StudyResults:
    if start.tzinfo is not None or end.tzinfo is not None:
        raise StudyValidationError(["Study timestamps must use the server's local timezone (naive timestamps)."])
    if end <= start:
        raise StudyValidationError(["Study end must be later than study start."])
    if (
        isinstance(sampling_interval_minutes, bool)
        or not isinstance(sampling_interval_minutes, int)
        or sampling_interval_minutes <= 0
    ):
        raise StudyValidationError(["Sampling interval must be a positive whole number of minutes."])
    interval = timedelta(minutes=sampling_interval_minutes)
    duration_seconds = (end - start).total_seconds()
    if strict_grid and duration_seconds % interval.total_seconds() != 0:
        raise StudyValidationError([
            "Study start and end are incompatible with the configured sampling interval. "
            "Adjust the study boundaries or sampling interval."
        ])
    if mode is AnalysisMode.TEMPERATURE_AND_HUMIDITY and humidity_limits is None:
        raise StudyValidationError(["Relative humidity limits are required for this analysis mode."])
    if not loggers:
        raise StudyValidationError(["At least one Data Logger file must be assigned."])
    codes = [logger.equipment_code for logger in loggers]
    if len(set(codes)) != len(codes):
        raise StudyValidationError(["Each Data Logger may be assigned to only one file in a study."])

    issues: list[str] = []
    windows: dict[str, list] = {}
    for logger in loggers:
        if mode is AnalysisMode.TEMPERATURE_AND_HUMIDITY and logger.humidity_curve is None:
            issues.append(f"Data Logger {logger.equipment_code}: RH calibration points are required.")
        window, logger_issues = _validate_grid(
            logger.equipment_code,
            logger.parsed_file,
            start,
            end,
            interval,
            mode,
            strict_grid,
        )
        windows[logger.equipment_code] = window
        issues.extend(logger_issues)
    if issues:
        raise StudyValidationError(issues)

    logger_results: list[LoggerResult] = []
    logger_series: list[LoggerSeries] = []
    pooled_temperature: list[float] = []
    pooled_humidity: list[float] = []
    warnings: set[str] = set()
    for logger in loggers:
        rows = windows[logger.equipment_code]
        timestamps = [row.timestamp for row in rows]
        corrected_temperature: list[float] = []
        corrected_humidity: list[float] = []
        original_temperatures: list[float] = []
        temperature_corrections: list[float] = []
        original_humidities: list[float] = []
        humidity_corrections: list[float] = []
        for row in rows:
            temperature_result = logger.temperature_curve.correct(row.temperature)
            original_temperatures.append(temperature_result.indication)
            temperature_corrections.append(temperature_result.correction)
            corrected_temperature.append(temperature_result.corrected_value)
            if temperature_result.extrapolated:
                edge = "lower-range" if row.temperature < temperature_result.calibration_range[0] else "upper-range"
                warnings.add(
                    f"Data Logger {logger.equipment_code}, temperature: indication "
                    f"{row.temperature:g} °C used {edge} calibration extrapolation; "
                    f"calibration range {temperature_result.calibration_range[0]:g} to "
                    f"{temperature_result.calibration_range[1]:g} °C. Mathematical extrapolation "
                    "does not establish metrological validity outside the calibration range."
                )
            if mode is AnalysisMode.TEMPERATURE_AND_HUMIDITY:
                humidity_result = logger.humidity_curve.correct(row.humidity)
                original_humidities.append(humidity_result.indication)
                humidity_corrections.append(humidity_result.correction)
                corrected_humidity.append(humidity_result.corrected_value)
                if humidity_result.extrapolated:
                    edge = "lower-range" if row.humidity < humidity_result.calibration_range[0] else "upper-range"
                    warnings.add(
                        f"Data Logger {logger.equipment_code}, relative humidity: indication "
                        f"{row.humidity:g} %RH used {edge} calibration extrapolation; "
                        f"calibration range {humidity_result.calibration_range[0]:g} to "
                        f"{humidity_result.calibration_range[1]:g} %RH. Mathematical extrapolation "
                        "does not establish metrological validity outside the calibration range."
                    )

        pooled_temperature.extend(corrected_temperature)
        temperature_result = _channel_result(
            corrected_temperature, timestamps, interval, start, end, temperature_limits
        )
        humidity_channel_result = None
        if mode is AnalysisMode.TEMPERATURE_AND_HUMIDITY:
            pooled_humidity.extend(corrected_humidity)
            humidity_channel_result = _channel_result(
                corrected_humidity, timestamps, interval, start, end, humidity_limits
            )
        logger_results.append(
            LoggerResult(logger.equipment_code, temperature_result, humidity_channel_result)
        )
        logger_series.append(
            LoggerSeries(
                logger.equipment_code,
                tuple(timestamps),
                tuple(corrected_temperature),
                tuple(corrected_humidity),
                tuple(original_temperatures),
                tuple(temperature_corrections),
                tuple(original_humidities),
                tuple(humidity_corrections),
            )
        )

    return StudyResults(
        logger_results=tuple(logger_results),
        global_temperature_mean=statistics.fmean(pooled_temperature),
        global_humidity_mean=statistics.fmean(pooled_humidity) if pooled_humidity else None,
        warnings=tuple(sorted(warnings)),
        series=tuple(logger_series),
    )