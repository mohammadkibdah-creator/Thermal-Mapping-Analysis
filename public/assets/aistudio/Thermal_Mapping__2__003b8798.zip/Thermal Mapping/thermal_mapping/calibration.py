from __future__ import annotations

import math

from .domain import CorrectionConvention, CorrectionPoint, CorrectionResult


class CalibrationError(ValueError):
    pass


class CalibrationCurve:
    def __init__(
        self,
        points: list[CorrectionPoint] | tuple[CorrectionPoint, ...],
        convention: CorrectionConvention,
    ) -> None:
        if len(points) < 2:
            raise CalibrationError("At least two calibration points are required.")
        if not all(
            math.isfinite(point.indication) and math.isfinite(point.correction)
            for point in points
        ):
            raise CalibrationError("Calibration values must be finite numbers.")
        ordered = tuple(sorted(points, key=lambda point: point.indication))
        if any(
            left.indication == right.indication
            for left, right in zip(ordered, ordered[1:])
        ):
            raise CalibrationError("Calibration indication points must be unique.")
        self.points = ordered
        self.convention = convention

    def correct(self, indication: float) -> CorrectionResult:
        if not math.isfinite(indication):
            raise CalibrationError("The indication must be a finite number.")
        points = self.points
        extrapolated = indication < points[0].indication or indication > points[-1].indication

        if indication <= points[0].indication:
            left, right = points[0], points[1]
        elif indication >= points[-1].indication:
            left, right = points[-2], points[-1]
        else:
            right_index = next(
                index for index, point in enumerate(points) if point.indication >= indication
            )
            left, right = points[right_index - 1], points[right_index]

        fraction = (indication - left.indication) / (right.indication - left.indication)
        correction = left.correction + fraction * (right.correction - left.correction)
        sign = 1 if self.convention is CorrectionConvention.INDICATION_PLUS_CORRECTION else -1
        return CorrectionResult(
            indication=indication,
            correction=correction,
            corrected_value=indication + sign * correction,
            extrapolated=extrapolated,
            calibration_range=(points[0].indication, points[-1].indication),
        )