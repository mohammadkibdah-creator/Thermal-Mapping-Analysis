import os

from waitress import serve

from thermal_mapping.web import create_app


app = create_app()


if __name__ == "__main__":
    serve(
        app,
        host=os.environ.get("THERMAL_MAPPING_HOST", "0.0.0.0"),
        port=int(os.environ.get("PORT") or os.environ.get("THERMAL_MAPPING_PORT", "8080")),
        threads=8,
    )