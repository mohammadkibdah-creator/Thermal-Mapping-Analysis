from datetime import date
from io import BytesIO
import json
from pathlib import Path
import tempfile
import unittest

from openpyxl import Workbook

from thermal_mapping.equipment_import import parse_equipment_workbook
from thermal_mapping.storage import get_equipment, list_equipment, parse_points
from thermal_mapping.web import create_app


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SAMPLE_WORKBOOK = PROJECT_ROOT / "data logger data.xlsx"


def valid_workbook() -> BytesIO:
    workbook = Workbook()
    equipment = workbook.active
    equipment.title = "Equipment details"
    equipment.append([
        "Instrument Description", "Equipment Code", "Serial Number", "Manufacturer",
        "Traceability", "Calibration Date", "Calibration Due Date",
    ])
    equipment.append([
        "Data Logger (DL001)", "DL001", "SN-001", "Testo", "Lab standard",
        date(2026, 1, 15), date(2028, 1, 15),
    ])
    equipment.append([
        "Data Logger (DL002)", "DL002", "SN-002", "Testo", "Lab standard",
        date(2026, 4, 12), date(2028, 4, 12),
    ])
    corrections = workbook.create_sheet("corrections")
    corrections.append(["Indication ", "Correction"])
    corrections.append(["Data Logger - DL001 - (-20 C)", -0.123456789])
    corrections.append(["Data Logger - DL001 - (0 C)", 0.134])
    corrections.append([None, None])
    corrections.append(["Data Logger - DL001 - (20 %RH)", 1.23456789])
    corrections.append(["Data Logger - DL001 - (90 %RH )", -0.5])
    corrections.append(["Data Logger - DL002 - (.5 C)", 0.125])
    corrections.append(["Data Logger - DL002 - (10 C)", -0.25])
    corrections.append(["Data Logger - DL002 - (20 C)", 0.375])
    corrections.append(["Data Logger - DL002 - (10 %RH)", 0])
    corrections.append(["Data Logger - DL002 - (20 %RH)", 0.25])
    corrections["BD2"] = 123
    output = BytesIO()
    workbook.save(output)
    output.seek(0)
    return output


class EquipmentImportTests(unittest.TestCase):
    def test_import_parser_groups_variable_points_and_keeps_source_precision(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "equipment.xlsx"
            path.write_bytes(valid_workbook().getvalue())
            preview = parse_equipment_workbook(path)

        self.assertTrue(preview.can_import, preview.issues)
        self.assertEqual(len(preview.equipment), 2)
        self.assertEqual(preview.counts, (
            {"equipment_code": "DL001", "temperature": 2, "relative_humidity": 2},
            {"equipment_code": "DL002", "temperature": 3, "relative_humidity": 2},
        ))
        self.assertEqual(
            preview.points["DL001"]["temperature"][0]["indication"],
            -20.0,
        )
        self.assertEqual(
            preview.points["DL001"]["temperature"][0]["source_indication"],
            "Data Logger - DL001 - (-20 C)",
        )
        self.assertEqual(
            preview.points["DL001"]["temperature"][0]["source_correction"],
            "-0.123456789",
        )
        self.assertEqual(preview.equipment[0]["calibration_date"], "2026-01-15")

    @unittest.skipUnless(SAMPLE_WORKBOOK.is_file(), "The supplied workbook is not available.")
    def test_real_workbook_preview_groups_registered_equipment(self):
        preview = parse_equipment_workbook(SAMPLE_WORKBOOK)
        self.assertEqual(len(preview.equipment), 37)
        self.assertTrue(preview.can_import, preview.issues)
        self.assertEqual(sum(row["temperature"] for row in preview.counts), 333)
        self.assertEqual(sum(row["relative_humidity"] for row in preview.counts), 185)
        self.assertEqual(preview.counts[0]["equipment_code"], "DL001")

    @unittest.skipUnless(SAMPLE_WORKBOOK.is_file(), "The supplied workbook is not available.")
    def test_real_workbook_commit_requires_conventions_and_writes_nothing(self):
        with SAMPLE_WORKBOOK.open("rb") as workbook:
            response = self.client.post(
                "/equipment/import/commit",
                data={"workbook": (workbook, SAMPLE_WORKBOOK.name), "conventions": "{}"},
            )
        self.assertEqual(response.status_code, 422)
        self.assertIn("conventions", " ".join(response.json["issues"]))
        self.assertEqual(list_equipment(self.app.config["DATABASE"]), [])

    def setUp(self):
        self.temporary_directory = tempfile.TemporaryDirectory()
        root = Path(self.temporary_directory.name)
        self.app = create_app({
            "TESTING": True,
            "INSTANCE_PATH": str(root / "instance"),
            "DATABASE": str(root / "database.sqlite3"),
            "ANALYSIS_LOCK": str(root / "analysis.lock"),
            "SECRET_KEY": "test-only-key",
        })
        self.client = self.app.test_client()

    def tearDown(self):
        self.temporary_directory.cleanup()

    def test_preview_then_import_and_rerun_is_blocked_without_overwrite(self):
        preview = self.client.post("/equipment/import/preview", data={
            "workbook": (valid_workbook(), "data logger data.xlsx"),
        })
        self.assertEqual(preview.status_code, 200)
        self.assertTrue(preview.json["can_import"])
        self.assertEqual(
            [row["temperature_count"] for row in preview.json["equipment"]],
            [2, 3],
        )

        conventions = {
            "DL001": {
                "temperature": "indication_plus_correction",
                "relative_humidity": "indication_minus_correction",
            },
            "DL002": {
                "temperature": "indication_plus_correction",
                "relative_humidity": "indication_plus_correction",
            },
        }
        imported = self.client.post("/equipment/import/commit", data={
            "workbook": (valid_workbook(), "data logger data.xlsx"),
            "conventions": json.dumps(conventions),
        })
        self.assertEqual(imported.status_code, 200, imported.get_data(as_text=True))
        self.assertEqual(imported.json["imported"], 2)
        record = get_equipment(self.app.config["DATABASE"], "DL001")
        self.assertEqual(record["temperature_convention"], "indication_plus_correction")
        self.assertEqual(record["humidity_convention"], "indication_minus_correction")
        self.assertEqual(len(parse_points(record["temperature_points_json"])), 2)
        self.assertEqual(len(parse_points(record["humidity_points_json"])), 2)

        repeated = self.client.post("/equipment/import/commit", data={
            "workbook": (valid_workbook(), "data logger data.xlsx"),
            "conventions": json.dumps(conventions),
        })
        self.assertEqual(repeated.status_code, 422)
        self.assertIn("already exists", repeated.json["issues"][0])
        self.assertEqual(get_equipment(self.app.config["DATABASE"], "DL001")["serial_number"], "SN-001")

    def test_import_page_is_available_from_equipment_registry(self):
        response = self.client.get("/equipment")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Import from Excel", response.data)
        self.assertEqual(self.client.get("/equipment/import").status_code, 200)


if __name__ == "__main__":
    unittest.main()
