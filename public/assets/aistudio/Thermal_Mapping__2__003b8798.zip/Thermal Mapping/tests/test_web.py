from io import BytesIO
import tempfile
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import patch

from openpyxl import load_workbook

from thermal_mapping.analysis_lock import AnalysisAlreadyRunning, analysis_is_running, analysis_lock
from thermal_mapping.domain import Measurement, ParsedFile
from thermal_mapping.storage import get_equipment, list_equipment
from thermal_mapping.web import create_app


SAMPLE_FILE = Path(__file__).resolve().parents[2] / "CodeGeex" / "Report_Table.xls"


class WebApplicationTests(unittest.TestCase):
    def setUp(self):
        self.temporary_directory = tempfile.TemporaryDirectory()
        root = Path(self.temporary_directory.name)
        self.app = create_app({
            "TESTING": True,
            "INSTANCE_PATH": str(root / "instance"),
            "DATABASE": str(root / "database.sqlite3"),
            "ANALYSIS_LOCK": str(root / "analysis.lock"),
            "SECRET_KEY": "test-only-key",
        })
        self.client = self.app.test_client()

    def tearDown(self):
        self.temporary_directory.cleanup()

    def test_dashboard_and_equipment_registration(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Registered Data Loggers", response.data)
        self.assertIn(b"Registered SuperDAQ Kits", response.data)
        self.assertIn(b"<strong>0</strong>", response.data)
        self.client.post("/sensor-kits/new", data={
            "name": "Temperature Kit",
            "serial_number": "KIT-001",
            "status": "Active",
        })
        response = self.client.get("/")
        self.assertIn(b"<strong>1</strong>", response.data)
        saved = self.client.post("/equipment/new", data={
            "equipment_code": "DL001",
            "description": "Temperature Data Logger",
            "serial_number": "SN-001",
            "traceability": "UME / Turkey",
            "temperature_enabled": "on",
            "action": "save_equipment",
        }, follow_redirects=True)
        self.assertEqual(saved.status_code, 200)
        self.assertIn(b"DL001", saved.data)
        self.assertIn(b"Incomplete", saved.data)

    def test_equipment_list_can_remove_registered_data_logger(self):
        self.client.post("/equipment/new", data={
            "equipment_code": "DL009",
            "description": "Temperature Data Logger",
            "serial_number": "SN-009",
            "action": "save_equipment",
        })
        page = self.client.get("/equipment")
        self.assertIn(b"Remove", page.data)
        removed = self.client.post("/equipment/DL009/delete", follow_redirects=True)
        self.assertEqual(removed.status_code, 200)
        self.assertIn(b"Data Logger DL009 was removed", removed.data)
        self.assertIsNone(get_equipment(self.app.config["DATABASE"], "DL009"))

    def test_equipment_delete_is_blocked_during_analysis(self):
        self.client.post("/equipment/new", data={
            "equipment_code": "DL010",
            "description": "Temperature Data Logger",
            "serial_number": "SN-010",
            "action": "save_equipment",
        })
        with patch(
            "thermal_mapping.web.analysis_lock",
            side_effect=AnalysisAlreadyRunning("Another analysis is already in progress."),
        ):
            response = self.client.post("/equipment/DL010/delete", follow_redirects=True)
        self.assertIn(b"Another analysis is already in progress", response.data)
        self.assertIsNotNone(get_equipment(self.app.config["DATABASE"], "DL010"))

    def test_save_equipment_details_persists_entered_calibration(self):
        response = self.client.post("/equipment/new", data={
            "equipment_code": "DL007",
            "description": "Temperature Data Logger",
            "serial_number": "SN-007",
            "traceability": "UME / Turkey",
            "temperature_enabled": "on",
            "calibration_date": "2026-01-01",
            "due_date": "2027-01-01",
            "temperature_convention": "indication_plus_correction",
            "temperature_indication": ["0", "50"],
            "temperature_correction": ["0.1", "-0.2"],
            "action": "save_equipment",
        })
        self.assertEqual(response.status_code, 302)
        record = get_equipment(self.app.config["DATABASE"], "DL007")
        self.assertEqual(record["calibration_date"], "2026-01-01")
        self.assertEqual(record["due_date"], "2027-01-01")
        self.assertEqual(record["temperature_convention"], "indication_plus_correction")
        self.assertIn('"correction": -0.2', record["temperature_points_json"])

    def test_settings_and_manual_backup(self):
        saved = self.client.post("/settings", data={
            "application_name": "Lab Thermal Mapping",
            "report_directory": str(Path(self.temporary_directory.name) / "reports"),
        }, follow_redirects=True)
        self.assertEqual(saved.status_code, 200)
        self.assertIn(b"Settings saved", saved.data)
        backed_up = self.client.post("/backup", follow_redirects=True)
        self.assertEqual(backed_up.status_code, 200)
        backup_files = list((Path(self.app.instance_path) / "backups").glob("*.sqlite3"))
        self.assertEqual(len(backup_files), 1)
        self.assertGreater(backup_files[0].stat().st_size, 0)

    def test_rejected_analysis_releases_server_lock(self):
        response = self.client.post("/study/analyze", data={}, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertFalse(analysis_is_running(self.app.config["ANALYSIS_LOCK"]))

    def test_study_page_explains_boundary_snapping(self):
        response = self.client.get("/study")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"rounded up to the next timestamp shared by all assigned Data Loggers", response.data)

    @unittest.skipUnless(SAMPLE_FILE.is_file(), "The supplied Report_Table.xls sample is not available.")
    def test_file_identification_matches_registered_equipment_code(self):
        saved = self.client.post("/equipment/new", data={
            "equipment_code": "DL001",
            "description": "Temperature Data Logger",
            "serial_number": "TEST-DL001",
            "temperature_enabled": "on",
            "calibration_date": "2025-01-01",
            "due_date": "2027-01-01",
            "traceability": "Synthetic test fixture only",
            "temperature_convention": "indication_plus_correction",
            "temperature_indication": ["0", "50"],
            "temperature_correction": ["0", "0"],
            "action": "update_certificate",
        })
        self.assertEqual(saved.status_code, 302)
        with SAMPLE_FILE.open("rb") as source:
            response = self.client.post("/study/identify", data={
                "mode": "temperature",
                "files": (source, "Report_Table.xls"),
            })
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json[0]["equipment_code"], "DL001")
        self.assertTrue(response.json[0]["matched"])
        self.assertTrue(response.json[0]["selectable"])

    def test_analysis_lock_rejects_second_owner_and_recovers_stale_lock(self):
        lock_path = Path(self.temporary_directory.name) / "analysis.lock"
        with analysis_lock(lock_path):
            self.assertTrue(analysis_is_running(lock_path))
            with self.assertRaises(AnalysisAlreadyRunning):
                with analysis_lock(lock_path):
                    self.fail("A second analysis acquired the lock.")
        self.assertFalse(analysis_is_running(lock_path))

        lock_path.write_text("999999999\n", encoding="ascii")
        with analysis_lock(lock_path):
            self.assertTrue(analysis_is_running(lock_path))
        self.assertFalse(analysis_is_running(lock_path))

    @unittest.skipUnless(SAMPLE_FILE.is_file(), "The supplied Report_Table.xls sample is not available.")
    def test_verified_sample_can_generate_report_with_test_only_calibration(self):
        report_directory = Path(self.temporary_directory.name) / "reports"
        report_directory.mkdir()
        self.client.post("/settings", data={
            "application_name": "Thermal Mapping Test",
            "report_directory": str(report_directory),
        })
        saved = self.client.post("/equipment/new", data={
            "equipment_code": "DL001",
            "description": "Temperature Data Logger",
            "serial_number": "SYNTHETIC-TEST-ONLY",
            "temperature_enabled": "on",
            "calibration_date": "2025-01-01",
            "due_date": "2027-01-01",
            "traceability": "Synthetic test fixture only",
            "temperature_convention": "indication_plus_correction",
            "temperature_indication": ["0", "50"],
            "temperature_correction": ["0", "0"],
            "action": "update_certificate",
        })
        self.assertEqual(saved.status_code, 302)
        with SAMPLE_FILE.open("rb") as source:
            response = self.client.post("/study/analyze", data={
                "study_name": "Synthetic test run",
                "start": "2025-04-06T17:00",
                "end": "2025-04-06T17:23",
                "sampling_interval_minutes": "15",
                "mode": "temperature",
                "temperature_lower": "15",
                "temperature_upper": "25",
                "assignments": ["DL001"],
                "files": (source, "Report_Table.xls"),
            })
        self.assertEqual(response.status_code, 302)
        preview = self.client.get(response.location)
        self.assertEqual(preview.status_code, 200)
        self.assertIn(b"Results Preview", preview.data)
        export = self.client.post(response.location.rstrip("/") + "/export")
        self.assertEqual(export.status_code, 200)
        self.assertIn(
            "attachment; filename=Synthetic_test_run.xlsx",
            export.headers.get("Content-Disposition", ""),
        )
        export.close()
        reports = list(report_directory.glob("*.xlsx"))
        self.assertEqual(len(reports), 1)
        self.assertNotIn("SYNTHETIC-TEST-ONLY", reports[0].name)
        workbook = load_workbook(reports[0], read_only=True)
        information = workbook["Study Information"]
        self.assertEqual(information["B4"].value, "2025-04-06 17:11:00")
        self.assertEqual(information["B5"].value, "2025-04-06 17:26:00")
        self.assertEqual(information["B6"].value, "2025-04-06 17:00:00")
        self.assertEqual(information["B7"].value, "2025-04-06 17:23:00")
        warning_rows = list(workbook["Warnings and Validation"].values)
        self.assertTrue(any("rounded up to the next shared recorded timestamp" in str(row) for row in warning_rows))
        workbook.close()

    def test_batch_upload_pairs_two_files_with_two_logger_codes(self):
        report_directory = Path(self.temporary_directory.name) / "batch-reports"
        report_directory.mkdir()
        self.client.post("/settings", data={
            "application_name": "Thermal Mapping Test",
            "report_directory": str(report_directory),
        })
        for code in ("DL001", "DL002"):
            saved = self.client.post("/equipment/new", data={
                "equipment_code": code,
                "description": "Temperature Data Logger",
                "serial_number": f"TEST-{code}",
                "temperature_enabled": "on",
                "calibration_date": "2025-01-01",
                "due_date": "2027-01-01",
                "traceability": "Synthetic test fixture only",
                "temperature_convention": "indication_plus_correction",
                "temperature_indication": ["0", "50"],
                "temperature_correction": ["0", "0"],
                "action": "update_certificate",
            })
            self.assertEqual(saved.status_code, 302)

        start = datetime(2025, 4, 6, 16, 56)
        parsed_files = [
            ParsedFile(
                "DL001.xls", "test adapter", "DL001",
                (Measurement(start, 20.0, None), Measurement(start + timedelta(minutes=15), 21.0, None)),
            ),
            ParsedFile(
                "DL002.xls", "test adapter", "DL002",
                (Measurement(start, 22.0, None), Measurement(start + timedelta(minutes=15), 23.0, None)),
            ),
        ]
        batch = [
            (BytesIO(b"first test workbook"), "DL001.xls"),
            (BytesIO(b"second test workbook"), "DL002.xls"),
        ]
        with patch("thermal_mapping.web.import_data_file", side_effect=parsed_files) as importer:
            response = self.client.post("/study/analyze", data={
                "study_name": "Two logger test",
                "start": start.isoformat(timespec="minutes"),
                "end": (start + timedelta(minutes=15)).isoformat(timespec="minutes"),
                "sampling_interval_minutes": "15",
                "mode": "temperature",
                "temperature_lower": "15",
                "temperature_upper": "25",
                "assignments": ["DL001", "DL002"],
                "files": batch,
            })
        self.assertEqual(response.status_code, 302)
        self.assertEqual(importer.call_count, 2)
        preview = self.client.get(response.location)
        self.assertEqual(preview.status_code, 200)
        self.assertIn(b"Temperature Distribution", preview.data)
        export = self.client.post(response.location.rstrip("/") + "/export")
        self.assertEqual(export.status_code, 200)
        export.close()
        reports = list(report_directory.glob("*.xlsx"))
        self.assertEqual(len(reports), 1)
        workbook = load_workbook(reports[0], read_only=True)
        self.assertEqual(workbook["Temperature Results"]["A2"].value, "DL001")
        self.assertEqual(workbook["Temperature Results"]["A3"].value, "DL002")
        workbook.close()


if __name__ == "__main__":
    unittest.main()