import unittest

from thermal_mapping.calibration import CalibrationCurve, CalibrationError
from thermal_mapping.domain import CorrectionConvention, CorrectionPoint


class CalibrationTests(unittest.TestCase):
    def test_exact_point_and_linear_interpolation(self):
        curve = CalibrationCurve(
            [CorrectionPoint(20, 0.2), CorrectionPoint(10, 0.0)],
            CorrectionConvention.INDICATION_PLUS_CORRECTION,
        )
        self.assertAlmostEqual(curve.correct(10).corrected_value, 10.0)
        result = curve.correct(15)
        self.assertAlmostEqual(result.correction, 0.1)
        self.assertAlmostEqual(result.corrected_value, 15.1)
        self.assertFalse(result.extrapolated)

    def test_extrapolates_both_ends(self):
        curve = CalibrationCurve(
            [CorrectionPoint(0, 0), CorrectionPoint(10, 1)],
            CorrectionConvention.INDICATION_PLUS_CORRECTION,
        )
        self.assertAlmostEqual(curve.correct(-5).corrected_value, -5.5)
        self.assertTrue(curve.correct(-5).extrapolated)
        self.assertAlmostEqual(curve.correct(15).corrected_value, 16.5)
        self.assertTrue(curve.correct(15).extrapolated)

    def test_minus_convention_is_explicit(self):
        curve = CalibrationCurve(
            [CorrectionPoint(0, -0.4), CorrectionPoint(10, -0.4)],
            CorrectionConvention.INDICATION_MINUS_CORRECTION,
        )
        self.assertAlmostEqual(curve.correct(5).corrected_value, 5.4)

    def test_duplicate_indications_are_rejected(self):
        with self.assertRaises(CalibrationError):
            CalibrationCurve(
                [CorrectionPoint(5, 0), CorrectionPoint(5, 1)],
                CorrectionConvention.INDICATION_PLUS_CORRECTION,
            )


if __name__ == "__main__":
    unittest.main()