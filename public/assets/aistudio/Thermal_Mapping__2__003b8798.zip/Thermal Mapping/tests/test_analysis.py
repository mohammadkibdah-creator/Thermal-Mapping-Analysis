import unittest
from datetime import datetime, timedelta

from thermal_mapping.analysis import (
    AssignedLogger,
    StudyValidationError,
    analyze_study,
    infer_sampling_interval_minutes,
    snap_study_boundaries,
)
from thermal_mapping.calibration import CalibrationCurve
from thermal_mapping.domain import (
    AnalysisMode,
    ChannelLimits,
    CorrectionConvention,
    CorrectionPoint,
    Measurement,
    ParsedFile,
)


START = datetime(2025, 1, 1, 10, 0)
INTERVAL = 15


def curve():
    return CalibrationCurve(
        [CorrectionPoint(-100, 0), CorrectionPoint(100, 0)],
        CorrectionConvention.INDICATION_PLUS_CORRECTION,
    )


def logger(code, temperatures, timestamps=None, humidities=None):
    if timestamps is None:
        timestamps = [START + timedelta(minutes=INTERVAL * index) for index in range(len(temperatures))]
    if humidities is None:
        humidities = [50.0] * len(temperatures)
    rows = tuple(
        Measurement(timestamp, temperature, humidity)
        for timestamp, temperature, humidity in zip(timestamps, temperatures, humidities)
    )
    return AssignedLogger(code, ParsedFile(f"{code}.xls", "test", code, rows), curve(), curve())


class AnalysisTests(unittest.TestCase):
    def run_analysis(self, loggers, **kwargs):
        return analyze_study(
            loggers,
            start=kwargs.pop("start", START),
            end=kwargs.pop("end", START + timedelta(minutes=45)),
            sampling_interval_minutes=kwargs.pop("sampling_interval_minutes", INTERVAL),
            mode=kwargs.pop("mode", AnalysisMode.TEMPERATURE),
            temperature_limits=kwargs.pop("temperature_limits", ChannelLimits(15, 25)),
            humidity_limits=kwargs.pop("humidity_limits", None),
            **kwargs,
        )

    def test_time_outside_limits_clips_last_interval_at_study_end(self):
        results = self.run_analysis([logger("DL001", [10, 15, 30, 10])])
        channel = results.logger_results[0].temperature
        self.assertEqual(channel.below_minutes, 15)
        self.assertEqual(channel.above_minutes, 15)
        self.assertAlmostEqual(channel.below_percent, 100 / 3)
        self.assertAlmostEqual(channel.above_percent, 100 / 3)

    def test_values_equal_to_limits_are_within_limits(self):
        results = self.run_analysis([logger("DL001", [15, 25, 20, 15])])
        channel = results.logger_results[0].temperature
        self.assertEqual(channel.below_minutes, 0)
        self.assertEqual(channel.above_minutes, 0)

    def test_global_mean_pools_all_readings(self):
        results = self.run_analysis([
            logger("DL001", [10, 10, 10, 10]),
            logger("DL002", [20, 20, 20, 20]),
        ])
        self.assertEqual(results.global_temperature_mean, 15)

    def test_extra_readings_outside_study_window_do_not_change_results(self):
        extra = [
            Measurement(START - timedelta(minutes=15), 999, 0),
            Measurement(START + timedelta(minutes=60), -999, 0),
        ]
        base = logger("DL001", [16, 17, 18, 19])
        parsed = ParsedFile(base.parsed_file.file_name, "test", "DL001", tuple(extra) + base.parsed_file.readings)
        result = self.run_analysis([AssignedLogger("DL001", parsed, curve())])
        self.assertEqual(result.logger_results[0].temperature.mean, 17.5)

    def test_missing_expected_timestamp_rejects_entire_analysis(self):
        missing = logger("DL001", [10, 20, 30], timestamps=[
            START,
            START + timedelta(minutes=30),
            START + timedelta(minutes=45),
        ])
        with self.assertRaises(StudyValidationError) as context:
            self.run_analysis([missing])
        self.assertIn("missing expected reading at 2025-01-01 10:15:00", str(context.exception))

    def test_off_grid_study_end_is_rounded_up(self):
        assigned = logger("DL001", [10, 20, 30])
        _, end, _ = snap_study_boundaries([assigned], START, START + timedelta(minutes=20))
        result = self.run_analysis([assigned], end=end)
        self.assertEqual(result.logger_results[0].temperature.mean, 20)

    def test_off_grid_boundaries_round_up_to_next_recorded_points(self):
        assigned = logger("DL001", [10, 20, 30, 40])
        snapped_start, snapped_end, warnings = snap_study_boundaries(
            [assigned],
            START + timedelta(minutes=7),
            START + timedelta(minutes=43),
        )
        self.assertEqual(snapped_start, START + timedelta(minutes=15))
        self.assertEqual(snapped_end, START + timedelta(minutes=45))
        self.assertEqual(len(warnings), 2)

    def test_boundary_tie_selects_next_timestamp(self):
        assigned = logger("DL001", [10, 20, 30, 40])
        snapped_start, _, _ = snap_study_boundaries(
            [assigned],
            START + timedelta(minutes=7, seconds=30),
            START + timedelta(minutes=45),
        )
        self.assertEqual(snapped_start, START + timedelta(minutes=15))

    def test_boundary_outside_recorded_range_is_rejected(self):
        assigned = logger("DL001", [10, 20, 30, 40])
        with self.assertRaises(StudyValidationError) as context:
            snap_study_boundaries(
                [assigned],
                START + timedelta(minutes=60),
                START + timedelta(minutes=45),
            )
        self.assertIn("outside the recorded range", str(context.exception))

    def test_rounding_uses_next_timestamp_shared_by_all_loggers(self):
        complete = logger("DL001", [10, 20, 30, 40])
        incomplete = logger(
            "DL002",
            [10, 30, 40],
            timestamps=[START, START + timedelta(minutes=30), START + timedelta(minutes=45)],
        )
        snapped_start, _, _ = snap_study_boundaries(
            [complete, incomplete],
            START + timedelta(minutes=15),
            START + timedelta(minutes=45),
        )
        self.assertEqual(snapped_start, START + timedelta(minutes=30))

    def test_sampling_interval_is_inferred_from_first_two_readings(self):
        self.assertEqual(infer_sampling_interval_minutes([logger("DL001", [10, 20])]), 15)

    def test_sampling_interval_rounds_to_nearest_minute(self):
        assigned = logger(
            "DL001",
            [10, 20],
            timestamps=[START, START + timedelta(minutes=14, seconds=31)],
        )
        self.assertEqual(infer_sampling_interval_minutes([assigned]), 15)

    def test_relative_humidity_is_required_in_combined_mode(self):
        with self.assertRaises(StudyValidationError) as context:
            self.run_analysis(
                [AssignedLogger(
                    "DL001",
                    logger("DL001", [20, 20, 20, 20]).parsed_file,
                    curve(),
                    None,
                )],
                mode=AnalysisMode.TEMPERATURE_AND_HUMIDITY,
                humidity_limits=ChannelLimits(30, 70),
            )
        self.assertIn("RH calibration points are required", str(context.exception))

    def test_sample_standard_deviation_uses_n_minus_one(self):
        result = self.run_analysis([logger("DL001", [1, 2, 3, 4])])
        self.assertAlmostEqual(result.logger_results[0].temperature.sample_standard_deviation, (5 / 3) ** 0.5)


if __name__ == "__main__":
    unittest.main()