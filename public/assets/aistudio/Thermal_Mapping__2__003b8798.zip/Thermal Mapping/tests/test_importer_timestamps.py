import unittest
from datetime import datetime

from thermal_mapping.importers.report_table import _timestamp


class LoggerTimestampTests(unittest.TestCase):
    def test_padded_and_unpadded_12_hour_timestamps(self):
        self.assertEqual(
            _timestamp("04/06/2025 04:56:00 PM", 0),
            datetime(2025, 4, 6, 16, 56),
        )
        self.assertEqual(
            _timestamp("4/6/2025 4:56:00 PM", 0),
            datetime(2025, 4, 6, 16, 56),
        )

    def test_noon_and_midnight_are_parsed_correctly(self):
        self.assertEqual(
            _timestamp("04/06/2025 12:05:00 AM", 0),
            datetime(2025, 4, 6, 0, 5),
        )
        self.assertEqual(
            _timestamp("04/06/2025 12:05:00 PM", 0),
            datetime(2025, 4, 6, 12, 5),
        )


if __name__ == "__main__":
    unittest.main()