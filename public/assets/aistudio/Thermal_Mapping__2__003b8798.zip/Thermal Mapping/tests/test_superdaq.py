from datetime import datetime, timedelta
from io import BytesIO
from pathlib import Path
import tempfile
import unittest

from openpyxl import Workbook, load_workbook

from thermal_mapping.importers.superdaq import import_superdaq_file
from thermal_mapping.storage import (
    connect,
    get_superdaq_sensor,
    get_sensor_kit,
    initialize_database,
    list_superdaq_sensors,
    list_sensor_kits,
    save_superdaq_sensor,
)
from thermal_mapping.web import create_app


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SUPERDAQ_SAMPLE = PROJECT_ROOT / "dat00001.xlsx"


def superdaq_workbook() -> BytesIO:
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "dat00001"
    sheet.append(["Record #", "Time", "Ch 101 (C)", "Ch 102 (C)", "Alarm Output"])
    start = datetime(2025, 1, 1, 10, 0)
    for index in range(3):
        sheet.append([index + 1, start + timedelta(minutes=15 * index), 20 + index, 18, ""])
    output = BytesIO()
    workbook.save(output)
    output.seek(0)
    return output


class SuperDAQTests(unittest.TestCase):
    def test_inspected_export_channels_are_preserved_exactly(self):
        if not SUPERDAQ_SAMPLE.is_file():
            self.skipTest("The supplied SuperDAQ sample is not available.")
        parsed = import_superdaq_file(SUPERDAQ_SAMPLE)
        self.assertIn("Ch 101 (C)", parsed.channels)
        self.assertIn("Ch 120 (C)", parsed.channels)
        self.assertEqual(len(parsed.channels), 21)
        self.assertEqual(len(parsed.channels["Ch 101 (C)"]), 1477)
        self.assertEqual(parsed.channels["Ch 001 (C)"][0].temperature, -9.9e37)
        self.assertEqual(
            parsed.channels["Ch 101 (C)"][0].timestamp,
            datetime(2025, 8, 6, 13, 27, 42, 285000),
        )

    def setUp(self):
        self.temporary_directory = tempfile.TemporaryDirectory()
        root = Path(self.temporary_directory.name)
        self.app = create_app({
            "TESTING": True,
            "INSTANCE_PATH": str(root / "instance"),
            "DATABASE": str(root / "database.sqlite3"),
            "ANALYSIS_LOCK": str(root / "analysis.lock"),
            "SECRET_KEY": "test-only-key",
        })
        self.client = self.app.test_client()
        self.report_directory = root / "reports"
        self.report_directory.mkdir()
        self.client.post("/settings", data={
            "application_name": "Test",
            "report_directory": str(self.report_directory),
        })

    def tearDown(self):
        self.temporary_directory.cleanup()

    def register_sensor(self, sensor_code="SENSOR01", channel="Ch 101 (C)"):
        response = self.client.post("/sensor-kits/new", data={
            "name": "Test Kit",
            "status": "Active",
        })
        self.assertEqual(response.status_code, 302)
        kits = list_sensor_kits(self.app.config["DATABASE"])
        kit_code = f"KIT{len(kits):03d}"
        response = self.client.post(f"/sensor-kits/{kit_code}/sensors/new", data={
            "sensor_code": sensor_code,
            "name": "Temperature Sensor",
            "channel_identifier": channel,
            "serial_number": "SN-001",
            "position": "Shelf A",
            "calibration_date": "2025-01-01",
            "due_date": "2027-01-01",
            "certificate_number": "CERT-001",
            "provider": "Test Lab",
            "traceability": "Test standard",
            "temperature_convention": "indication_plus_correction",
            "temperature_indication": ["0", "50"],
            "temperature_correction": ["0", "0"],
            "action": "update_certificate",
        })
        self.assertEqual(response.status_code, 302)

    def test_new_sensor_form_defaults_to_indication_plus_correction(self):
        response = self.client.post("/sensor-kits/new", data={
            "name": "Test Kit",
            "status": "Active",
        })
        self.assertEqual(response.status_code, 302)

        page = self.client.get("/sensor-kits/KIT001/sensors/new")
        self.assertEqual(page.status_code, 200)
        self.assertIn(
            b'<option value="indication_plus_correction" selected>Indication + correction</option>',
            page.data,
        )
        self.assertNotIn(
            b'<option value="indication_minus_correction" selected>Indication - correction</option>',
            page.data,
        )

    def test_existing_database_migrates_kit_serial_number(self):
        database = Path(self.temporary_directory.name) / "legacy.sqlite3"
        connection = connect(database)
        try:
            connection.execute(
                "CREATE TABLE sensor_kits ("
                "kit_code TEXT PRIMARY KEY, name TEXT NOT NULL, "
                "status TEXT NOT NULL DEFAULT 'Active', notes TEXT NOT NULL DEFAULT '', "
                "updated_at TEXT NOT NULL)"
            )
            connection.execute(
                "INSERT INTO sensor_kits (kit_code, name, status, notes, updated_at) "
                "VALUES ('KIT009', 'Legacy Kit', 'Active', '', '2026-01-01T00:00:00')"
            )
            connection.commit()
        finally:
            connection.close()

        initialize_database(database)
        kit = get_sensor_kit(database, "KIT009")
        self.assertEqual(kit["serial_number"], "")
        self.assertEqual(kit["name"], "Legacy Kit")

    def test_sensor_kit_codes_are_generated_and_preserved_on_edit(self):
        new_page = self.client.get("/sensor-kits/new")
        self.assertEqual(new_page.status_code, 200)
        self.assertNotIn(b'name="kit_code"', new_page.data)
        self.assertIn(b"assigned automatically", new_page.data)

        created = self.client.post("/sensor-kits/new", data={
            "name": "First Kit",
            "serial_number": "KIT-SN-001",
            "status": "Active",
        })
        self.assertEqual(created.status_code, 302)
        kits = list_sensor_kits(self.app.config["DATABASE"])
        self.assertEqual(kits[0]["kit_code"], "KIT001")
        self.assertEqual(kits[0]["serial_number"], "KIT-SN-001")

        edit_page = self.client.get("/sensor-kits/KIT001/edit")
        self.assertEqual(edit_page.status_code, 200)
        self.assertNotIn(b'name="kit_code"', edit_page.data)
        self.assertIn(b'name="serial_number"', edit_page.data)
        updated = self.client.post("/sensor-kits/KIT001/edit", data={
            "name": "Renamed Kit",
            "serial_number": "KIT-SN-UPDATED",
            "status": "Active",
        })
        self.assertEqual(updated.status_code, 302)
        kits = list_sensor_kits(self.app.config["DATABASE"])
        self.assertEqual(kits[0]["kit_code"], "KIT001")
        self.assertEqual(kits[0]["name"], "Renamed Kit")
        self.assertEqual(kits[0]["serial_number"], "KIT-SN-UPDATED")

        self.client.post("/sensor-kits/new", data={
            "name": "Second Kit",
            "status": "Active",
        })
        self.assertEqual(
            [kit["kit_code"] for kit in list_sensor_kits(self.app.config["DATABASE"])],
            ["KIT001", "KIT002"],
        )

    def test_sensor_registry_and_superdaq_study_report(self):
        self.register_sensor()
        sensor = get_superdaq_sensor(self.app.config["DATABASE"], "SENSOR01")
        self.assertEqual(sensor["channel_identifier"], "Ch 101 (C)")
        self.assertEqual(list_superdaq_sensors(self.app.config["DATABASE"], "KIT001")[0]["sensor_code"], "SENSOR01")

        detected = self.client.post("/study/identify", data={
            "acquisition_system": "fluke_superdaq",
            "kit_code": "KIT001",
            "files": (superdaq_workbook(), "dat00001.xlsx"),
        })
        self.assertEqual(detected.status_code, 200)
        self.assertEqual(detected.json["channels"][0]["channel_name"], "Ch 101 (C)")
        automatic_mapping = {
            item["channel_name"]: item["sensor_code"]
            for item in detected.json["channels"]
        }
        self.assertEqual(automatic_mapping["Ch 101 (C)"], "SENSOR01")
        self.assertIsNone(automatic_mapping["Ch 102 (C)"])

        analyzed = self.client.post("/study/analyze", data={
            "acquisition_system": "fluke_superdaq",
            "kit_code": "KIT001",
            "study_name": "SuperDAQ test",
            "start": "2025-01-01T10:00",
            "end": "2025-01-01T10:30",
            "sampling_interval_minutes": "15",
            "mode": "temperature",
            "temperature_lower": "15",
            "temperature_upper": "25",
            "channel_names": ["Ch 101 (C)", "Ch 102 (C)"],
            "sensor_assignments": ["SENSOR01", ""],
            "files": (superdaq_workbook(), "dat00001.xlsx"),
        })
        self.assertEqual(analyzed.status_code, 302)
        preview = self.client.get(analyzed.location)
        self.assertEqual(preview.status_code, 200)
        self.assertIn(b"Temperature Distribution", preview.data)
        self.assertNotIn(b"MKT Comparison", preview.data)
        self.client.post(analyzed.location.rstrip("/") + "/export")
        reports = list(self.report_directory.glob("*.xlsx"))
        self.assertEqual(len(reports), 1)
        report = load_workbook(reports[0], read_only=True, data_only=True)
        info = {row[0]: row[1] for row in report["Study Information"].iter_rows(min_row=2, values_only=True)}
        self.assertEqual(info["Acquisition system"], "Fluke SuperDAQ")
        self.assertEqual(info["Sensor kit"], "KIT001")
        self.assertEqual(info["Analysis mode"], "Temperature Only")
        self.assertNotIn("Relative Humidity Results", report.sheetnames)
        sensor_info = list(report["SuperDAQ Sensor Information"].iter_rows(values_only=True))
        self.assertEqual(sensor_info[1][3], "Ch 101 (C)")
        calibration_rows = list(report["Calibration Snapshot"].iter_rows(values_only=True))
        self.assertEqual(calibration_rows[1][1], "Temperature (Ch 101 (C))")
        report.close()

    def test_mapping_rejects_sensor_from_another_kit(self):
        self.register_sensor()
        self.register_sensor(sensor_code="SENSOR02", channel="Ch 101 (C)")
        response = self.client.post("/study/analyze", data={
            "acquisition_system": "fluke_superdaq",
            "kit_code": "KIT001",
            "start": "2025-01-01T10:00",
            "end": "2025-01-01T10:30",
            "sampling_interval_minutes": "15",
            "mode": "temperature",
            "temperature_lower": "15",
            "temperature_upper": "25",
            "channel_names": ["Ch 101 (C)", "Ch 102 (C)"],
            "sensor_assignments": ["SENSOR02", ""],
            "files": (superdaq_workbook(), "dat00001.xlsx"),
        }, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Only sensors belonging to the selected kit", response.data)
        self.assertEqual(list(self.report_directory.glob("*.xlsx")), [])

    def test_mapping_rejects_duplicate_sensor_assignments(self):
        self.register_sensor()
        response = self.client.post("/study/analyze", data={
            "acquisition_system": "fluke_superdaq",
            "kit_code": "KIT001",
            "start": "2025-01-01T10:00",
            "end": "2025-01-01T10:30",
            "sampling_interval_minutes": "15",
            "mode": "temperature",
            "temperature_lower": "15",
            "temperature_upper": "25",
            "channel_names": ["Ch 101 (C)", "Ch 102 (C)"],
            "sensor_assignments": ["SENSOR01", "SENSOR01"],
            "files": (superdaq_workbook(), "dat00001.xlsx"),
        }, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Each registered sensor may be assigned to only one channel", response.data)
        self.assertEqual(list(self.report_directory.glob("*.xlsx")), [])

    def test_duplicate_sensor_code_does_not_move_an_existing_sensor(self):
        self.register_sensor()
        self.client.post("/sensor-kits/new", data={
            "name": "Second Kit",
            "status": "Active",
        })
        response = self.client.post("/sensor-kits/KIT002/sensors/new", data={
            "sensor_code": "SENSOR01",
            "name": "Replacement",
            "channel_identifier": "Ch 102 (C)",
        }, follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"already registered", response.data)
        sensor = get_superdaq_sensor(self.app.config["DATABASE"], "SENSOR01")
        self.assertEqual(sensor["kit_code"], "KIT001")
        self.assertEqual(sensor["name"], "Temperature Sensor")

    def test_sensor_can_be_removed_without_removing_its_kit(self):
        self.register_sensor()
        response = self.client.post(
            "/sensor-kits/KIT001/sensors/SENSOR01/delete",
            follow_redirects=True,
        )
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"SuperDAQ sensor SENSOR01 was removed", response.data)
        self.assertIsNone(get_superdaq_sensor(self.app.config["DATABASE"], "SENSOR01"))
        self.assertEqual(self.client.get("/sensor-kits").status_code, 200)
        self.assertIn(b"KIT001", self.client.get("/sensor-kits").data)

    def test_deleting_kit_removes_its_registered_sensors(self):
        self.register_sensor()
        response = self.client.post("/sensor-kits/KIT001/delete", follow_redirects=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"kit KIT001 and its 1 registered sensor(s) were removed", response.data)
        self.assertIsNone(get_superdaq_sensor(self.app.config["DATABASE"], "SENSOR01"))
        page = self.client.get("/sensor-kits")
        self.assertNotIn(b"KIT001", page.data)
        self.assertIn(b"No SuperDAQ sensor kits registered", page.data)

    def test_sensor_form_hides_position_and_preserves_existing_value_on_edit(self):
        self.register_sensor()
        sensor = get_superdaq_sensor(self.app.config["DATABASE"], "SENSOR01")
        sensor["position"] = "Shelf A, front"
        sensor["certificate_number"] = "CERT-KEEP"
        sensor["provider"] = "Lab to keep"
        save_superdaq_sensor(self.app.config["DATABASE"], sensor)

        page = self.client.get("/sensor-kits/KIT001/sensors/SENSOR01/edit")
        self.assertEqual(page.status_code, 200)
        self.assertNotIn(b"Position / Description", page.data)
        self.assertNotIn(b'name="position"', page.data)
        self.assertNotIn(b"Certificate / Report Number", page.data)
        self.assertNotIn(b'name="certificate_number"', page.data)
        self.assertNotIn(b"Calibration Provider / Laboratory", page.data)
        self.assertNotIn(b'name="provider"', page.data)

        response = self.client.post(
            "/sensor-kits/KIT001/sensors/SENSOR01/edit",
            data={
                "sensor_code": "SENSOR01",
                "name": "Temperature Sensor Updated",
                "channel_identifier": "Ch 101 (C)",
                "serial_number": "SN-001",
                "traceability": "Test standard",
                "temperature_indication": ["0", "50"],
                "temperature_correction": ["0", "0"],
                "action": "save_sensor",
            },
        )
        self.assertEqual(response.status_code, 302)
        updated = get_superdaq_sensor(self.app.config["DATABASE"], "SENSOR01")
        self.assertEqual(updated["position"], "Shelf A, front")
        self.assertEqual(updated["certificate_number"], "CERT-KEEP")
        self.assertEqual(updated["provider"], "Lab to keep")


if __name__ == "__main__":
    unittest.main()
