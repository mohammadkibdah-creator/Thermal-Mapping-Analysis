import unittest
from datetime import timedelta
from pathlib import Path

from thermal_mapping.importers import import_report_table


SAMPLE_FILE = Path(__file__).resolve().parents[2] / "CodeGeex" / "Report_Table.xls"


@unittest.skipUnless(SAMPLE_FILE.is_file(), "The supplied Report_Table.xls sample is not available.")
class SuppliedReportTableTests(unittest.TestCase):
    def test_supplied_sample_structure_and_time_series(self):
        parsed = import_report_table(SAMPLE_FILE)
        self.assertEqual(parsed.instrument_code, "DL001")
        self.assertEqual(len(parsed.readings), 673)
        self.assertEqual(parsed.readings[0].timestamp.isoformat(sep=" "), "2025-04-06 16:56:00")
        self.assertEqual(parsed.readings[-1].timestamp.isoformat(sep=" "), "2025-04-13 16:56:00")
        self.assertTrue(all(row.temperature is not None and row.humidity is not None for row in parsed.readings))
        intervals = {
            (right.timestamp - left.timestamp)
            for left, right in zip(parsed.readings, parsed.readings[1:])
        }
        self.assertEqual(intervals, {timedelta(minutes=15)})


if __name__ == "__main__":
    unittest.main()