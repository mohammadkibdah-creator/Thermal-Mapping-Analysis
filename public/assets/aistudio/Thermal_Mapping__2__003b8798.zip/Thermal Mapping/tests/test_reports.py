import tempfile
import unittest
from datetime import datetime, timedelta
from pathlib import Path

from openpyxl import load_workbook

from thermal_mapping.analysis import AssignedLogger, analyze_study
from thermal_mapping.calibration import CalibrationCurve
from thermal_mapping.domain import (
    AnalysisMode,
    ChannelLimits,
    CorrectionConvention,
    CorrectionPoint,
    Measurement,
    ParsedFile,
)
from thermal_mapping.reports import LoggerReportSnapshot, generate_report


class ReportTests(unittest.TestCase):
    def test_report_is_complete_and_collision_safe(self):
        start = datetime(2025, 1, 1, 10, 0)
        end = start + timedelta(minutes=15)
        convention = CorrectionConvention.INDICATION_PLUS_CORRECTION
        points = (CorrectionPoint(0, 0), CorrectionPoint(50, 0))
        curve = CalibrationCurve(points, convention)
        parsed = ParsedFile(
            "DL001.xls",
            "verified sample",
            "DL001",
            (
                Measurement(start, 20, 50),
                Measurement(end, 21, 51),
            ),
        )
        results = analyze_study(
            [AssignedLogger("DL001", parsed, curve)],
            start=start,
            end=end,
            sampling_interval_minutes=15,
            mode=AnalysisMode.TEMPERATURE,
            temperature_limits=ChannelLimits(15, 25),
        )
        snapshot = LoggerReportSnapshot(
            "DL001", "Temperature Data Logger", "SN-1", "UME / Turkey",
            "2025-01-01", "2026-01-01", points, convention,
        )
        with tempfile.TemporaryDirectory() as directory:
            args = dict(
                output_directory=directory,
                study_name="Cold Room / Mapping",
                start=start,
                end=end,
                sampling_interval_minutes=15,
                mode=AnalysisMode.TEMPERATURE,
                temperature_limits=ChannelLimits(15, 25),
                humidity_limits=None,
                snapshots=(snapshot,),
                results=results,
            )
            first, report_id = generate_report(**args)
            second, _ = generate_report(**args)
            self.assertNotEqual(first, second)
            self.assertTrue(first.exists())
            self.assertTrue(report_id)
            workbook = load_workbook(first)
            self.assertEqual(
                workbook.sheetnames,
                [
                    "Study Information", "Temperature Results", "Data Logger Information",
                    "Calibration Snapshot", "Warnings and Validation", "DL001",
                ],
            )
            detail = workbook["DL001"]
            self.assertEqual(detail.max_row, 3)
            self.assertEqual(detail["C2"].value, datetime(2025, 1, 1, 10, 0))
            self.assertEqual(detail["D2"].value, 20)
            self.assertEqual(detail["F2"].value, 20)
            self.assertEqual(detail["D3"].value, 21)
            self.assertEqual(detail["F3"].value, 21)
            self.assertEqual(len(detail._charts), 1)
            workbook.close()
            self.assertEqual(workbook["Temperature Results"]["A2"].value, "DL001")
            self.assertEqual(workbook["Calibration Snapshot"]["A2"].value, "DL001")
            workbook.close()


if __name__ == "__main__":
    unittest.main()