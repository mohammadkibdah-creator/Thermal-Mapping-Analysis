from datetime import datetime
from io import BytesIO
from pathlib import Path
import tempfile
import unittest

from openpyxl import Workbook

from thermal_mapping.storage import (
    get_superdaq_sensor,
    list_sensor_kits,
    list_superdaq_sensors,
    parse_points,
)
from thermal_mapping.superdaq_equipment_import import parse_superdaq_equipment_workbook
from thermal_mapping.web import create_app


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SAMPLE_WORKBOOK = PROJECT_ROOT / "SuperDaq Data.xlsx"


def small_workbook(unknown_correction_channel: bool = False) -> BytesIO:
    workbook = Workbook()
    equipment = workbook.active
    equipment.title = "Equipment details"
    equipment.append([
        "Kit Name / Description", "Kit Serial Number", "Sensor Name", "Serial Number",
        "Sensor Code", "SuperDAQ Channel Identifier", "Calibration Date",
        "Calibration Due Date", "Traceability",
    ])
    equipment.append([
        "Test Kit", "KIT-SERIAL", "PT100", "SN-1", "Ch 101 (C)", "Ch 101 (C)",
        datetime(2026, 1, 1), datetime(2027, 1, 1), "Test standard",
    ])
    equipment.append([None] * 9)
    equipment.append([
        "Test Kit", "KIT-SERIAL", "PT100", "SN-2", "Ch 102 (C)", "Ch 102 (C)",
        datetime(2026, 1, 1), datetime(2027, 1, 1), "Test standard",
    ])
    corrections = workbook.create_sheet("corrections")
    corrections.append([
        "Kit Serial Number", "SuperDAQ Channel Identifier", "Indication (C)",
        "Correction (C)",
    ])
    corrections.append([
        "KIT-SERIAL",
        "Ch 999 (C)" if unknown_correction_channel else "Ch 101 (C)",
        "(-10 C)",
        0.125,
    ])
    corrections.append([None, None, None, None])
    corrections.append(["KIT-SERIAL", "Ch 101 (C)", "10 C", -0.25])
    corrections.append(["KIT-SERIAL", "Ch 102 (C)", "0 C", "0.001"])
    corrections.append(["KIT-SERIAL", "Ch 102 (C)", "20 C", "0.002"])
    output = BytesIO()
    workbook.save(output)
    output.seek(0)
    return output


class SuperDAQEquipmentImportTests(unittest.TestCase):
    def setUp(self):
        self.temporary_directory = tempfile.TemporaryDirectory()
        root = Path(self.temporary_directory.name)
        self.app = create_app({
            "TESTING": True,
            "INSTANCE_PATH": str(root / "instance"),
            "DATABASE": str(root / "database.sqlite3"),
            "ANALYSIS_LOCK": str(root / "analysis.lock"),
            "SECRET_KEY": "test-only-key",
        })
        self.client = self.app.test_client()

    def tearDown(self):
        self.temporary_directory.cleanup()

    def test_supplied_workbook_matches_all_channels_and_points(self):
        if not SAMPLE_WORKBOOK.is_file():
            self.skipTest("The supplied SuperDAQ equipment workbook is not available.")
        preview = parse_superdaq_equipment_workbook(SAMPLE_WORKBOOK)
        self.assertTrue(preview.can_import, preview.issues)
        self.assertEqual(preview.kit, {
            "name": "Super DAQ System with PT100 Sensors",
            "serial_number": "44070036",
        })
        self.assertEqual(len(preview.sensors), 9)
        self.assertEqual(sum(len(sensor["temperature_points"]) for sensor in preview.sensors), 108)
        for sensor in preview.sensors:
            self.assertEqual(len(sensor["temperature_points"]), 12)
            self.assertEqual(sensor["temperature_convention"], "indication_plus_correction")
            self.assertTrue(sensor["sensor_code"].startswith("SDQ44070036"))

    def test_parser_continues_after_blank_rows_and_matches_serial_and_channel(self):
        workbook = small_workbook()
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "small.xlsx"
            path.write_bytes(workbook.getvalue())
            preview = parse_superdaq_equipment_workbook(path)
        self.assertTrue(preview.can_import, preview.issues)
        self.assertEqual(len(preview.sensors), 2)
        first, second = preview.sensors
        self.assertEqual(len(first["temperature_points"]), 2)
        self.assertEqual(first["temperature_points"][1]["source_row"], 4)
        self.assertEqual(first["temperature_points"][0]["source_correction"], "0.125")
        self.assertEqual(len(second["temperature_points"]), 2)

    def test_parser_flags_unknown_correction_channel_instead_of_guessing(self):
        workbook = small_workbook(unknown_correction_channel=True)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "unknown-channel.xlsx"
            path.write_bytes(workbook.getvalue())
            preview = parse_superdaq_equipment_workbook(path)
        self.assertFalse(preview.can_import)
        self.assertTrue(any("no exact match" in issue for issue in preview.issues))

    def test_preview_commit_and_exact_rerun(self):
        registry_page = self.client.get("/sensor-kits")
        self.assertIn(b"Import from Excel", registry_page.data)
        self.assertEqual(self.client.get("/sensor-kits/import").status_code, 200)
        with SAMPLE_WORKBOOK.open("rb") as file:
            preview_response = self.client.post(
                "/sensor-kits/import/preview",
                data={"workbook": (file, SAMPLE_WORKBOOK.name)},
                content_type="multipart/form-data",
            )
        self.assertEqual(preview_response.status_code, 200, preview_response.get_json())
        self.assertTrue(preview_response.json["can_import"])
        self.assertEqual(preview_response.json["total_points"], 108)
        self.assertEqual(len(preview_response.json["sensors"]), 9)

        with SAMPLE_WORKBOOK.open("rb") as file:
            commit_response = self.client.post(
                "/sensor-kits/import/commit",
                data={"workbook": (file, SAMPLE_WORKBOOK.name)},
                content_type="multipart/form-data",
            )
        self.assertEqual(commit_response.status_code, 200, commit_response.get_json())
        self.assertEqual(commit_response.json["sensors_imported"], 9)
        kits = list_sensor_kits(self.app.config["DATABASE"])
        sensors = list_superdaq_sensors(self.app.config["DATABASE"])
        self.assertEqual(len(kits), 1)
        self.assertEqual(len(sensors), 9)
        self.assertEqual(kits[0]["serial_number"], "44070036")
        imported = get_superdaq_sensor(
            self.app.config["DATABASE"], "SDQ44070036CH101C"
        )
        self.assertEqual(imported["temperature_convention"], "indication_plus_correction")
        points = parse_points(imported["temperature_points_json"])
        self.assertEqual(len(points), 12)
        self.assertEqual(points[0], {"indication": -80.0, "correction": 0.002})

        with SAMPLE_WORKBOOK.open("rb") as file:
            rerun = self.client.post(
                "/sensor-kits/import/commit",
                data={"workbook": (file, SAMPLE_WORKBOOK.name)},
                content_type="multipart/form-data",
            )
        self.assertEqual(rerun.status_code, 200, rerun.get_json())
        self.assertTrue(rerun.json["already_imported"])
        self.assertEqual(len(list_sensor_kits(self.app.config["DATABASE"])), 1)
        self.assertEqual(len(list_superdaq_sensors(self.app.config["DATABASE"])), 9)

    def test_existing_kit_with_same_serial_but_different_data_blocks_import(self):
        response = self.client.post("/sensor-kits/new", data={
            "name": "Different Kit",
            "serial_number": "44070036",
            "status": "Active",
        })
        self.assertEqual(response.status_code, 302)
        with SAMPLE_WORKBOOK.open("rb") as file:
            preview = self.client.post(
                "/sensor-kits/import/preview",
                data={"workbook": (file, SAMPLE_WORKBOOK.name)},
                content_type="multipart/form-data",
            )
        self.assertEqual(preview.status_code, 200)
        self.assertFalse(preview.json["can_import"])
        self.assertTrue(any("will not overwrite" in issue for issue in preview.json["issues"]))


if __name__ == "__main__":
    unittest.main()
