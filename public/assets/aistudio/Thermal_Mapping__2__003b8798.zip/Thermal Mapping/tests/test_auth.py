from __future__ import annotations

from pathlib import Path

from thermal_mapping.auth import password_hash
from thermal_mapping.storage import create_user, get_user, initialize_database, set_user_active
from thermal_mapping.web import create_app


def _app(tmp_path: Path):
    database = tmp_path / "auth.sqlite3"
    initialize_database(database)
    create_user(database, "admin", password_hash("admin-password-123"), "Admin")
    create_user(database, "operator", password_hash("operator-password-123"), "User")
    return create_app({
        "TESTING": True,
        "AUTH_DISABLED": False,
        "SECRET_KEY": "test-secret",
        "DATABASE": str(database),
        "INSTANCE_PATH": str(tmp_path),
    }), database


def _csrf(client, path="/login"):
    body = client.get(path).get_data(as_text=True)
    return body.split('name="csrf_token" value="')[1].split('"')[0]


def test_unauthenticated_requests_redirect_to_login(tmp_path):
    app, _ = _app(tmp_path)
    assert app.test_client().get("/").status_code == 302


def test_user_can_run_application_but_cannot_manage_registry(tmp_path):
    app, database = _app(tmp_path)
    client = app.test_client()
    token = _csrf(client)
    client.post("/login", data={
        "username": "operator",
        "password": "operator-password-123",
        "csrf_token": token,
    })
    assert client.get("/").status_code == 200
    assert client.get("/equipment/new").status_code == 200
    token = _csrf(client, "/equipment/new")
    response = client.post("/equipment/new", data={
        "csrf_token": token,
        "equipment_code": "DLNEW",
        "description": "New logger",
        "serial_number": "SNNEW",
        "traceability": "JNMI",
        "temperature_enabled": "on",
        "action": "save_equipment",
    })
    assert response.status_code == 302
    assert client.post("/equipment/DLNEW/edit", data={
        "csrf_token": token,
        "equipment_code": "DLNEW",
        "description": "Changed",
        "temperature_enabled": "on",
        "action": "save_equipment",
    }).status_code == 403
    assert client.post("/sensor-kits/new", data={
        "csrf_token": token,
        "name": "Shared kit",
        "status": "Active",
    }).status_code == 302
    assert client.get("/users").status_code == 403
    user = get_user(database, 2)
    set_user_active(database, user["user_id"], False)
    assert client.get("/").status_code == 302


def test_admin_can_access_user_management(tmp_path):
    app, _ = _app(tmp_path)
    client = app.test_client()
    token = _csrf(client)
    client.post("/login", data={
        "username": "admin",
        "password": "admin-password-123",
        "csrf_token": token,
    })
    assert client.get("/users").status_code == 200
