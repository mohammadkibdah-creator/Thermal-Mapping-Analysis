const previewData = JSON.parse(document.querySelector("#preview-data").textContent);
const colors = ["#2864dc", "#bd4d42", "#3b8d5e", "#94620c", "#8356b8", "#168a9a", "#c45b8a", "#5d718d"];
const temperatureColors = ["#2864dc", "#3b8d5e", "#8356b8", "#168a9a", "#5d718d", "#2457a6", "#287a59", "#68439b"];
const humidityColors = ["#d17821", "#bd4d42", "#c45b8a", "#94620c", "#a44838", "#b45c18", "#9d3e6e", "#76500d"];

function combinedChart() {
  const svg = document.querySelector("#combined-chart");
  const legend = document.querySelector("#combined-legend");
  const selector = document.querySelector("#sensor-selector");
  const saveButton = document.querySelector("#save-chart");
  if (!svg || !legend || !previewData.series.length) return;
  const humidityEnabled = previewData.series.some((item) => item.humidities.length);
  const width = 1100, height = 390;
  const pad = { left: 76, right: humidityEnabled ? 76 : 24, top: 24, bottom: 56 };
  const plotWidth = width - pad.left - pad.right, plotHeight = height - pad.top - pad.bottom;
  const times = previewData.series[0].timestamps.map((value) => new Date(value).getTime());
  const timeMin = times[0], timeMax = times[times.length - 1] || timeMin + 1;
  const temperatureValues = previewData.series.flatMap((item) => item.temperatures);
  const humidityValues = humidityEnabled ? previewData.series.flatMap((item) => item.humidities) : [];
  const bounds = (values, limits = []) => {
    const finiteValues = [...values, ...limits].filter((value) => Number.isFinite(value));
    const min = Math.min(...finiteValues), max = Math.max(...finiteValues);
    const margin = (max - min || 1) * .08;
    return { min: min - margin, max: max + margin };
  };
  const temperatureLimits = previewData.temperatureLimits || null;
  const humidityLimits = humidityEnabled ? (previewData.humidityLimits || null) : null;
  const temperatureBounds = bounds(temperatureValues, temperatureLimits ? [temperatureLimits.lower, temperatureLimits.upper] : []);
  const humidityBounds = humidityEnabled ? bounds(humidityValues, humidityLimits ? [humidityLimits.lower, humidityLimits.upper] : []) : null;
  let selectedSensor = previewData.series[0].equipment_code;
  const seriesEntries = previewData.series.flatMap((item, index) => {
    const entries = [{ item, index, key: "temperatures", unit: "°C", label: `${item.equipment_code} – Temperature`, axis: "temperature" }];
    if (humidityEnabled) entries.push({ item, index, key: "humidities", unit: "%RH", label: `${item.equipment_code} – Humidity`, axis: "humidity" });
    return entries;
  });
  const limitEntries = temperatureLimits ? [
    { value: temperatureLimits.lower, axis: "temperature", label: `LTL — Temperature (${temperatureLimits.lower} °C)` },
    { value: temperatureLimits.upper, axis: "temperature", label: `UTL — Temperature (${temperatureLimits.upper} °C)` },
    ...(humidityLimits ? [
      { value: humidityLimits.lower, axis: "humidity", label: `LRL — Relative Humidity (${humidityLimits.lower} %RH)` },
      { value: humidityLimits.upper, axis: "humidity", label: `URL — Relative Humidity (${humidityLimits.upper} %RH)` },
    ] : []),
  ] : [];
  let zoom = 1, pan = 0, dragStart = null;
  const clampPan = () => {
    pan = Math.max(0, Math.min(1 - 1 / zoom, pan));
  };
  const x = (time) => pad.left + (((time - timeMin) / (timeMax - timeMin) - pan) * zoom) * plotWidth;
  const y = (value, axis) => {
    const range = axis === "humidity" ? humidityBounds : temperatureBounds;
    return pad.top + (range.max - value) / (range.max - range.min) * plotHeight;
  };
  const axisTicks = (range, axisX, side) => Array.from({ length: 5 }, (_, index) => {
    const value = range.max - (range.max - range.min) * index / 4;
    const yPosition = pad.top + plotHeight * index / 4;
    const labelX = side === "right" ? width - pad.right + 8 : pad.left - 8;
    return `<text x="${labelX}" y="${yPosition + 4}" text-anchor="${side === "right" ? "start" : "end"}" class="chart-label">${value.toFixed(2)}</text>`;
  }).join("");
  function formatTime(value, visibleDuration) {
    const options = visibleDuration <= 36 * 60 * 60 * 1000
      ? { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }
      : { month: "short", day: "numeric", hour: "2-digit" };
    return new Date(value).toLocaleString([], options);
  }
  function draw() {
    const visibleStart = timeMin + pan * (timeMax - timeMin);
    const visibleDuration = (timeMax - timeMin) / zoom;
    const grid = Array.from({ length: 5 }, (_, index) => {
      const yPosition = pad.top + plotHeight * index / 4;
      return `<line x1="${pad.left}" x2="${width - pad.right}" y1="${yPosition}" y2="${yPosition}" class="chart-gridline"/>`;
    }).join("");
    const tickCount = zoom >= 8 ? 9 : zoom >= 3 ? 8 : 7;
    const xLabels = Array.from({ length: tickCount }, (_, index) => {
      const ratio = index / (tickCount - 1);
      const time = visibleStart + visibleDuration * ratio;
      return `<line x1="${pad.left + plotWidth * ratio}" x2="${pad.left + plotWidth * ratio}" y1="${pad.top + plotHeight}" y2="${pad.top + plotHeight + 6}" class="chart-tick"/><text x="${pad.left + plotWidth * ratio}" y="${height - 18}" text-anchor="middle" class="chart-label">${formatTime(time, visibleDuration)}</text>`;
    }).join("");
    const limitLines = limitEntries.map((entry) => {
      const yPosition = y(entry.value, entry.axis);
      const side = entry.axis === "humidity" ? "right" : "left";
      const labelX = side === "right" ? width - pad.right - 8 : pad.left + 8;
      return `<line x1="${pad.left}" x2="${width - pad.right}" y1="${yPosition}" y2="${yPosition}" class="acceptance-limit ${entry.axis}-acceptance-limit"/><text x="${labelX}" y="${yPosition - 5}" text-anchor="${side === "right" ? "end" : "start"}" class="acceptance-limit-label">${entry.label}</text>`;
    }).join("");
    const lines = seriesEntries.map((entry, index) => {
      if (entry.item.equipment_code !== selectedSensor) return "";
      const points = entry.item[entry.key].map((value, pointIndex) => {
        const timestamp = entry.item.timestamps[pointIndex];
        return { x: x(new Date(timestamp).getTime()), y: y(value, entry.axis), value, timestamp };
      });
      const path = points.map((point, pointIndex) => `${pointIndex ? "L" : "M"}${point.x.toFixed(1)},${point.y.toFixed(1)}`).join(" ");
      const color = (entry.axis === "humidity" ? humidityColors : temperatureColors)[entry.index % temperatureColors.length];
      const nodes = points.map((point) => `<circle cx="${point.x}" cy="${point.y}" r="${entry.axis === "humidity" ? "4" : "3"}" fill="${color}" stroke="white" stroke-width="1"><title>${entry.item.equipment_code} — ${entry.axis === "temperature" ? "Temperature" : "Humidity"}: ${new Date(point.timestamp).toLocaleString()} — ${point.value} ${entry.unit}</title></circle>`).join("");
      return `<g class="chart-series ${entry.axis}-series"><path d="${path}" fill="none" stroke="${color}" stroke-width="${entry.axis === "humidity" ? "2.5" : "2"}"/>${nodes}</g>`;
    }).join("");
    svg.innerHTML = `<defs><clipPath id="combined-plot-clip"><rect x="${pad.left}" y="${pad.top}" width="${plotWidth}" height="${plotHeight}"/></clipPath></defs><rect x="0" y="0" width="${width}" height="${height}" fill="white"/>${grid}${limitLines}${axisTicks(temperatureBounds, pad.left, "left")}${humidityEnabled ? axisTicks(humidityBounds, width - pad.right, "right") : ""}<line x1="${pad.left}" x2="${width - pad.right}" y1="${pad.top + plotHeight}" y2="${pad.top + plotHeight}" class="chart-axis-line"/>${xLabels}<text transform="translate(22 ${pad.top + plotHeight / 2}) rotate(-90)" text-anchor="middle" class="chart-axis-title">Temperature (°C)</text>${humidityEnabled ? `<text transform="translate(${width - 22} ${pad.top + plotHeight / 2}) rotate(90)" text-anchor="middle" class="chart-axis-title">Relative Humidity (%RH)</text>` : ""}<g clip-path="url(#combined-plot-clip)">${lines}</g>`;
  }
  svg.setAttribute("viewBox", `0 0 ${width} ${height}`);
  svg.setAttribute("preserveAspectRatio", "xMidYMid meet");
  function renderLegend() {
    legend.replaceChildren();
    seriesEntries.filter((entry) => entry.item.equipment_code === selectedSensor).forEach((entry) => {
      const button = document.createElement("span");
      button.className = "legend-button";
      const color = (entry.axis === "humidity" ? humidityColors : temperatureColors)[entry.index % temperatureColors.length];
      button.innerHTML = `<span style="background:${color}"></span>${entry.label}`;
      legend.append(button);
    });
    limitEntries.forEach((entry) => {
      const item = document.createElement("span");
      item.className = "legend-button acceptance-limit-legend";
      item.innerHTML = `<span class="${entry.axis}-acceptance-limit"></span>${entry.label}`;
      legend.append(item);
    });
  }
  previewData.series.forEach((item) => {
    const option = document.createElement("option");
    option.value = item.equipment_code;
    option.textContent = item.equipment_code;
    selector.append(option);
  });
  selector.value = selectedSensor;
  selector.addEventListener("change", () => { selectedSensor = selector.value; renderLegend(); draw(); });
  renderLegend();
  saveButton.addEventListener("click", () => {
    const source = new XMLSerializer().serializeToString(svg);
    const blob = new Blob([source], { type: "image/svg+xml;charset=utf-8" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `thermal_mapping_${selectedSensor}_chart.svg`;
    document.body.append(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(link.href);
  });
  draw();
  svg.addEventListener("wheel", (event) => {
    event.preventDefault();
    const rect = svg.getBoundingClientRect();
    const scale = rect.width / width;
    const pointerRatio = Math.max(0, Math.min(1, (event.clientX - rect.left - pad.left * scale) / (plotWidth * scale)));
    const anchor = pan + pointerRatio / zoom;
    zoom = Math.max(1, Math.min(20, zoom * (event.deltaY < 0 ? 1.2 : .83)));
    pan = anchor - pointerRatio / zoom;
    clampPan();
    draw();
  }, { passive: false });
  svg.addEventListener("pointerdown", (event) => {
    event.preventDefault();
    dragStart = event.clientX;
    try {
      svg.setPointerCapture(event.pointerId);
    } catch (error) {
      dragStart = event.clientX;
    }
  });
  svg.addEventListener("pointermove", (event) => {
    if (dragStart === null) return;
    const rect = svg.getBoundingClientRect();
    pan -= (event.clientX - dragStart) / rect.width * width / plotWidth / zoom;
    clampPan();
    dragStart = event.clientX;
    draw();
  });
  svg.addEventListener("pointerup", (event) => {
    dragStart = null;
    if (svg.hasPointerCapture(event.pointerId)) {
      svg.releasePointerCapture(event.pointerId);
    }
  });
  svg.addEventListener("pointercancel", (event) => {
    dragStart = null;
    if (svg.hasPointerCapture(event.pointerId)) {
      svg.releasePointerCapture(event.pointerId);
    }
  });
}

function chartMkt() {
  const svg = document.querySelector("#mkt-chart");
  if (!svg || !previewData.mkt.length) return;
  const width = 900, height = 300, pad = { left: 58, right: 20, top: 28, bottom: 56 };
  const values = previewData.mkt.map((item) => item.value);
  let low = Math.min(...values, previewData.average), high = Math.max(...values, previewData.average);
  if (high === low) {
    low -= .5;
    high += .5;
  }
  const range = high - low || 1;
  svg.setAttribute("viewBox", `0 0 ${width} ${height}`);
  const plotHeight = height - pad.top - pad.bottom;
  const y = (value) => pad.top + (high - value) / range * plotHeight;
  svg.innerHTML = `<rect x="0" y="0" width="${width}" height="${height}" fill="white"/>`;
  const averageY = y(previewData.average);
  svg.insertAdjacentHTML("beforeend", `<line x1="${pad.left}" x2="${width - pad.right}" y1="${averageY}" y2="${averageY}" class="average-line"/><text x="${width - pad.right}" y="${averageY - 7}" text-anchor="end" class="average-label">Overall average: ${previewData.average}</text>`);
  const slot = (width - pad.left - pad.right) / previewData.mkt.length;
  previewData.mkt.forEach((item, index) => {
    const barWidth = Math.min(64, slot * .58), x = pad.left + slot * index + (slot - barWidth) / 2;
    const top = y(item.value);
    svg.insertAdjacentHTML("beforeend", `<rect x="${x}" y="${top}" width="${barWidth}" height="${Math.max(1, y(low) - top)}" rx="4" fill="${colors[index % colors.length]}"><title>${item.name}: ${item.value} °C</title></rect><text x="${x + barWidth / 2}" y="${top - 8}" text-anchor="middle" class="chart-value">${item.value}</text><text x="${x + barWidth / 2}" y="${height - pad.bottom + 22}" text-anchor="middle" class="chart-label">${item.name}</text>`);
  });
}

combinedChart();
