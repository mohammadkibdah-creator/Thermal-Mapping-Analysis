function appendPointRow(channel) {
  const body = document.querySelector(`[data-point-rows="${channel}"]`);
  const row = document.createElement("tr");
  for (const kind of ["indication", "correction"]) {
    const cell = document.createElement("td");
    const input = document.createElement("input");
    input.type = "number";
    input.step = "any";
    input.name = `${channel}_${kind}`;
    input.setAttribute("aria-label", `${channel} ${kind}`);
    cell.append(input);
    row.append(cell);
  }
  const removeCell = document.createElement("td");
  const removeButton = document.createElement("button");
  removeButton.type = "button";
  removeButton.className = "text-link remove-point";
  removeButton.textContent = "Remove";
  removeButton.addEventListener("click", () => row.remove());
  removeCell.append(removeButton);
  row.append(removeCell);
  body.append(row);
}

document.querySelectorAll(".add-point").forEach((button) => {
  button.addEventListener("click", () => appendPointRow(button.dataset.channel));
});

document.querySelectorAll("[data-point-rows]").forEach((body) => {
  body.querySelectorAll(".remove-point").forEach((button) => {
    button.addEventListener("click", () => button.closest("tr").remove());
  });
  if (!body.children.length) {
    appendPointRow(body.dataset.pointRows);
    appendPointRow(body.dataset.pointRows);
  }
});