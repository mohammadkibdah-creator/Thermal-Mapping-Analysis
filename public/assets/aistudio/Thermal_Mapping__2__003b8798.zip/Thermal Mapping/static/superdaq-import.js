const form = document.querySelector("#superdaq-import-form");
const fileInput = document.querySelector("#superdaq-import-file");
const previewSection = document.querySelector("#superdaq-import-preview");
const sensorRows = document.querySelector("#superdaq-import-sensor-rows");
const issueList = document.querySelector("#superdaq-import-issues");
const errorBox = document.querySelector("#superdaq-import-error");
const importButton = document.querySelector("#superdaq-import-submit");
const previewSummary = document.querySelector("#superdaq-preview-summary");
const previewStatus = document.querySelector("#superdaq-preview-status");
let latestPreview = null;
let requestNumber = 0;

function showError(message) {
  errorBox.textContent = message;
  errorBox.classList.remove("hidden");
}

function addCell(row, value) {
  const cell = document.createElement("td");
  cell.textContent = value == null || value === "" ? "Not entered" : String(value);
  row.append(cell);
  return cell;
}

function addPointDetails(cell, sensor) {
  const details = document.createElement("details");
  const summary = document.createElement("summary");
  summary.textContent = `${sensor.temperature_count} points`;
  details.append(summary);
  const table = document.createElement("table");
  const header = document.createElement("tr");
  for (const label of ["Workbook row", "Original indication", "Correction"]) {
    const heading = document.createElement("th");
    heading.textContent = label;
    header.append(heading);
  }
  table.append(header);
  for (const point of sensor.temperature_points) {
    const row = document.createElement("tr");
    for (const value of [
      point.source_row,
      point.source_indication,
      point.source_correction,
    ]) {
      const item = document.createElement("td");
      item.textContent = String(value);
      row.append(item);
    }
    table.append(row);
  }
  details.append(table);
  cell.append(details);
}

function renderPreview(data) {
  latestPreview = data;
  sensorRows.replaceChildren();
  issueList.replaceChildren();
  previewSection.classList.remove("hidden");
  const sensors = data.sensors || [];
  const issues = data.issues || [];
  previewSummary.textContent =
    `${data.kit.name} (serial ${data.kit.serial_number}); ${sensors.length} sensor(s); `
    + `${data.total_points} temperature correction points.`;
  previewStatus.textContent = issues.length
    ? `${issues.length} validation issue(s)`
    : data.already_imported ? "Already imported; no changes needed" : "Ready for review";
  previewStatus.classList.toggle("status-expired", issues.length > 0);

  if (issues.length) {
    issueList.classList.remove("hidden");
    const heading = document.createElement("h3");
    heading.textContent = "Resolve all issues before import";
    issueList.append(heading);
    const list = document.createElement("ul");
    for (const issue of issues) {
      const item = document.createElement("li");
      item.textContent = issue;
      list.append(item);
    }
    issueList.append(list);
  } else {
    issueList.classList.add("hidden");
  }

  for (const sensor of sensors) {
    const row = document.createElement("tr");
    addCell(row, data.kit.name);
    addCell(row, data.kit.serial_number);
    addCell(row, sensor.workbook_sensor_code);
    addCell(row, sensor.name);
    addCell(row, sensor.channel_identifier);
    addCell(row, sensor.serial_number);
    addCell(row, `${sensor.calibration_date} / ${sensor.due_date}`);
    addCell(row, sensor.traceability);
    addPointDetails(addCell(row, ""), sensor);
    sensorRows.append(row);
  }
  importButton.textContent = data.already_imported
    ? "Finish (No Changes)"
    : "Import Kit and Sensors";
  importButton.disabled = !data.can_import || !fileInput.files.length;
}

async function postWorkbook(url) {
  const body = new FormData();
  body.append("workbook", fileInput.files[0], fileInput.files[0].name);
  const response = await fetch(url, {
    method: "POST",
    body,
    headers: { "X-CSRF-Token": document.querySelector("#superdaq-import-form").dataset.csrfToken },
  });
  const result = await response.json();
  return { response, result };
}

fileInput.addEventListener("change", async () => {
  const currentRequest = ++requestNumber;
  latestPreview = null;
  previewSection.classList.add("hidden");
  errorBox.classList.add("hidden");
  importButton.disabled = true;
  if (!fileInput.files.length) return;
  try {
    const { response, result } = await postWorkbook(form.dataset.previewUrl);
    if (currentRequest !== requestNumber) return;
    if (!response.ok) throw new Error(result.error || "Could not preview the workbook.");
    renderPreview(result);
  } catch (error) {
    if (currentRequest === requestNumber) showError(error.message);
  }
});

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (!latestPreview || !latestPreview.can_import) return;
  importButton.disabled = true;
  errorBox.classList.add("hidden");
  try {
    const { response, result } = await postWorkbook(form.dataset.commitUrl);
    if (!response.ok) {
      const issues = Array.isArray(result.issues) ? ` ${result.issues.join(" ")}` : "";
      throw new Error((result.error || "Import failed.") + issues);
    }
    const kitsUrl = new URL(form.dataset.kitsUrl, window.location.origin);
    if (result.already_imported) {
      kitsUrl.searchParams.set("already_imported", "1");
    } else {
      kitsUrl.searchParams.set("imported", String(result.sensors_imported));
    }
    window.location.assign(kitsUrl);
  } catch (error) {
    showError(error.message);
    importButton.disabled = false;
  }
});
