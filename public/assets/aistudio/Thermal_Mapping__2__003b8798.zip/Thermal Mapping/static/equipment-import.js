const form = document.querySelector("#equipment-import-form");
const fileInput = document.querySelector("#equipment-import-file");
const previewSection = document.querySelector("#import-preview");
const equipmentRows = document.querySelector("#import-equipment-rows");
const issueList = document.querySelector("#import-issues");
const errorBox = document.querySelector("#import-error");
const importButton = document.querySelector("#import-submit");
const previewSummary = document.querySelector("#preview-summary");
const previewStatus = document.querySelector("#preview-status");
let latestPreview = null;
let requestNumber = 0;

function showError(message) {
  errorBox.textContent = message;
  errorBox.classList.remove("hidden");
}

function conventionSelect(code, channel, label) {
  const select = document.createElement("select");
  select.dataset.code = code;
  select.dataset.channel = channel;
  select.setAttribute("aria-label", `${code} ${label} correction convention`);
  const options = [
    ["", "Select convention"],
    ["indication_plus_correction", "Indication + correction"],
    ["indication_minus_correction", "Indication - correction"],
  ];
  for (const [value, text] of options) {
    const option = document.createElement("option");
    option.value = value;
    option.textContent = text;
    select.append(option);
  }
  select.value = "indication_plus_correction";
  select.addEventListener("change", updateImportButton);
  return select;
}

function addPointDetails(details, label, points) {
  const heading = document.createElement("summary");
  heading.textContent = `${label}: ${points.length} points`;
  details.append(heading);
  const table = document.createElement("table");
  const header = document.createElement("tr");
  for (const text of ["Workbook row", "Original indication", "Correction"]) {
    const cell = document.createElement("th");
    cell.textContent = text;
    header.append(cell);
  }
  table.append(header);
  for (const point of points) {
    const row = document.createElement("tr");
    for (const value of [
      point.source_row,
      point.source_indication,
      point.source_correction ?? point.correction,
    ]) {
      const cell = document.createElement("td");
      cell.textContent = String(value);
      row.append(cell);
    }
    table.append(row);
  }
  details.append(table);
}

function renderPreview(data) {
  latestPreview = data;
  equipmentRows.replaceChildren();
  issueList.replaceChildren();
  previewSection.classList.remove("hidden");
  const equipment = data.equipment || [];
  const issues = data.issues || [];
  previewSummary.textContent =
    `${equipment.length} instruments; ${equipment.reduce((sum, item) => sum + item.temperature_count, 0)} temperature points; `
    + `${equipment.reduce((sum, item) => sum + item.humidity_count, 0)} relative-humidity points.`;
  previewStatus.textContent = issues.length ? `${issues.length} validation issue(s)` : "Ready for review";
  previewStatus.classList.toggle("status-expired", issues.length > 0);
  if (issues.length) {
    issueList.classList.remove("hidden");
    const heading = document.createElement("h3");
    heading.textContent = "Resolve all issues before import";
    issueList.append(heading);
    const list = document.createElement("ul");
    for (const issue of issues) {
      const item = document.createElement("li");
      item.textContent = issue;
      list.append(item);
    }
    issueList.append(list);
  } else {
    issueList.classList.add("hidden");
  }
  for (const record of equipment) {
    const row = document.createElement("tr");
    for (const value of [
      record.equipment_code,
      record.description,
      record.serial_number,
      record.calibration_date || "Invalid / missing",
      record.due_date || "Invalid / missing",
    ]) {
      const cell = document.createElement("td");
      cell.textContent = value;
      row.append(cell);
    }
    const temperatureCell = document.createElement("td");
    temperatureCell.append(
      document.createTextNode(`${record.temperature_count} points`),
      conventionSelect(record.equipment_code, "temperature", "temperature"),
    );
    const humidityCell = document.createElement("td");
    humidityCell.append(
      document.createTextNode(`${record.humidity_count} points`),
      conventionSelect(record.equipment_code, "relative_humidity", "relative humidity"),
    );
    const detailsCell = document.createElement("td");
    const details = document.createElement("details");
    addPointDetails(details, "Temperature", record.temperature_points || []);
    addPointDetails(details, "Relative humidity", record.humidity_points || []);
    detailsCell.append(details);
    row.append(temperatureCell, humidityCell, detailsCell);
    equipmentRows.append(row);
  }
  updateImportButton();
}

function updateImportButton() {
  if (!latestPreview || !latestPreview.can_import || !fileInput.files.length) {
    importButton.disabled = true;
    return;
  }
  const selects = Array.from(equipmentRows.querySelectorAll("select"));
  importButton.disabled = selects.some((select) => !select.value);
}

async function postWorkbook(url, conventions) {
  const body = new FormData();
  body.append("workbook", fileInput.files[0], fileInput.files[0].name);
  if (conventions) body.append("conventions", JSON.stringify(conventions));
  const response = await fetch(url, {
    method: "POST",
    body,
    headers: { "X-CSRF-Token": document.querySelector("#equipment-import-form").dataset.csrfToken },
  });
  const result = await response.json();
  return { response, result };
}

fileInput.addEventListener("change", async () => {
  const currentRequest = ++requestNumber;
  latestPreview = null;
  previewSection.classList.add("hidden");
  errorBox.classList.add("hidden");
  importButton.disabled = true;
  if (!fileInput.files.length) return;
  try {
    const { response, result } = await postWorkbook(form.dataset.previewUrl);
    if (currentRequest !== requestNumber) return;
    if (!response.ok) throw new Error(result.error || "Could not preview the workbook.");
    renderPreview(result);
  } catch (error) {
    if (currentRequest === requestNumber) showError(error.message);
  }
});

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (!latestPreview || !latestPreview.can_import) return;
  const conventions = {};
  for (const select of equipmentRows.querySelectorAll("select")) {
    if (!conventions[select.dataset.code]) conventions[select.dataset.code] = {};
    conventions[select.dataset.code][select.dataset.channel] = select.value;
  }
  importButton.disabled = true;
  errorBox.classList.add("hidden");
  try {
    const { response, result } = await postWorkbook(form.dataset.commitUrl, conventions);
    if (!response.ok) {
      const issues = Array.isArray(result.issues) ? ` ${result.issues.join(" ")}` : "";
      throw new Error((result.error || "Import failed.") + issues);
    }
    const equipmentUrl = new URL(form.dataset.equipmentUrl, window.location.origin);
    equipmentUrl.searchParams.set("imported", String(result.imported));
    window.location.assign(equipmentUrl);
  } catch (error) {
    showError(error.message);
    updateImportButton();
  }
});
