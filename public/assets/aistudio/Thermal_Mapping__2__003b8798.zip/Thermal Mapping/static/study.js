const fileInput = document.querySelector("#data-files");
const assignmentRows = document.querySelector("#assignment-rows");
const assignmentHeading = document.querySelector("#assignment-heading");
const modeSelect = document.querySelector("#analysis-mode");
const humidityField = document.querySelector(".humidity-field");
const studyForm = document.querySelector("#study-form");
const studyStart = document.querySelector("[name='start']");
const confirmationField = document.querySelector("#confirm-expired");
const acquisitionSelect = document.querySelector("#acquisition-system");
const kitSelect = document.querySelector("#kit-code");
const modeField = document.querySelector(".mode-field");
const kitField = document.querySelector(".kit-field");
const uploadHelp = document.querySelector("#upload-help");
const fileLabel = document.querySelector("#file-label");
const devices = JSON.parse(document.querySelector("#device-data").textContent);
const sensorKits = JSON.parse(document.querySelector("#sensor-kit-data").textContent);
let identificationRequest = 0;

function isSuperDAQ() {
  return acquisitionSelect.value === "fluke_superdaq";
}

function selectedKit() {
  return sensorKits.find((kit) => kit.kit_code === kitSelect.value);
}

function setTableHeadings() {
  const labels = isSuperDAQ()
    ? ["Excel Channel", "Sensor Kit Channel", "File Validation", "Registered Sensor", ""]
    : ["File Name", "Detected Format", "File Validation", "Data Logger Code", ""];
  assignmentHeading.replaceChildren();
  const row = document.createElement("tr");
  for (const label of labels) {
    const cell = document.createElement("th");
    cell.textContent = label;
    row.append(cell);
  }
  assignmentHeading.append(row);
}

function showEmptyState(message) {
  assignmentRows.replaceChildren();
  const row = document.createElement("tr");
  const cell = document.createElement("td");
  cell.colSpan = 5;
  cell.className = "empty-state";
  cell.textContent = message;
  row.append(cell);
  assignmentRows.append(row);
}

async function identifySelectedFiles(files) {
  const requestId = ++identificationRequest;
  if (!files.length) return;
  if (isSuperDAQ() && !kitSelect.value) {
    showEmptyState("Select a sensor kit before identifying SuperDAQ channels.");
    return;
  }
  const formData = new FormData();
  formData.append("acquisition_system", acquisitionSelect.value);
  formData.append("mode", modeSelect.value);
  if (isSuperDAQ()) formData.append("kit_code", kitSelect.value);
  for (const file of files) formData.append("files", file, file.name);
  for (const cell of assignmentRows.querySelectorAll("[data-validation]")) {
    cell.textContent = isSuperDAQ() ? "Detecting SuperDAQ channels..." : "Identifying Data Logger...";
  }
  try {
    const response = await fetch(studyForm.dataset.identifyUrl, {
      method: "POST",
      body: formData,
      headers: { "X-CSRF-Token": studyForm.querySelector("[name=csrf_token]").value },
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "Identification request failed.");
    if (requestId !== identificationRequest) return;
    if (isSuperDAQ()) {
      renderSuperDAQMappings(files[0], result);
      return;
    }
    const rows = Array.from(assignmentRows.querySelectorAll("tr"));
    const assignedCodes = new Set();
    result.forEach((match, index) => {
      const row = rows[index];
      if (!row) return;
      const statusCell = row.querySelector("[data-validation]");
      const select = row.querySelector("select[name='assignments']");
      if (match.selectable && match.equipment_code) {
        if (assignedCodes.has(match.equipment_code)) {
          statusCell.textContent = `${match.equipment_code} is already assigned to another file.`;
          statusCell.classList.add("validation-error");
          return;
        }
        select.value = match.equipment_code;
        assignedCodes.add(match.equipment_code);
        statusCell.textContent = match.message;
        statusCell.classList.remove("validation-error");
      } else {
        statusCell.textContent = match.message;
        statusCell.classList.add("validation-error");
      }
    });
  } catch (error) {
    if (requestId !== identificationRequest) return;
    showEmptyState(error.message || "Identification failed. Check the file and retry.");
  }
}

function renderSuperDAQMappings(file, result) {
  assignmentRows.replaceChildren();
  for (const channel of result.channels) {
    const row = document.createElement("tr");
    const channelCell = document.createElement("td");
    channelCell.textContent = channel.channel_name;
    const formatCell = document.createElement("td");
    formatCell.textContent = result.format_name;
    const statusCell = document.createElement("td");
    statusCell.dataset.validation = "true";
    statusCell.textContent = channel.sensor_code
      ? `Matched ${channel.sensor_code} from the selected kit.`
      : "No exact kit channel match; assign manually or leave unmapped.";
    statusCell.dataset.unmappedMessage = "No exact kit channel match; assign manually or leave unmapped.";
    if (!channel.sensor_code) statusCell.classList.add("validation-error");
    const assignmentCell = document.createElement("td");
    const select = document.createElement("select");
    select.name = "sensor_assignments";
    const prompt = document.createElement("option");
    prompt.value = "";
    prompt.textContent = "Leave unmapped";
    select.append(prompt);
    const kit = selectedKit();
    for (const sensor of kit ? kit.sensors : []) {
      const option = document.createElement("option");
      option.value = sensor.sensor_code;
      option.textContent = `${sensor.sensor_code} — ${sensor.name} (${sensor.channel_identifier})`;
      select.append(option);
    }
    if (channel.sensor_code) select.value = channel.sensor_code;
    const channelInput = document.createElement("input");
    channelInput.type = "hidden";
    channelInput.name = "channel_names";
    channelInput.value = channel.channel_name;
    assignmentCell.append(select, channelInput);
    select.addEventListener("change", validateSensorAssignments);
    const removeCell = document.createElement("td");
    removeCell.textContent = "";
    row.append(channelCell, formatCell, statusCell, assignmentCell, removeCell);
    assignmentRows.append(row);
  }
  if (!result.channels.length) showEmptyState("No SuperDAQ channels were detected.");
}

function validateSensorAssignments() {
  const selects = Array.from(assignmentRows.querySelectorAll("select[name='sensor_assignments']"));
  const counts = new Map();
  for (const select of selects) {
    if (select.value) counts.set(select.value, (counts.get(select.value) || 0) + 1);
  }
  for (const select of selects) {
    const status = select.closest("tr").querySelector("[data-validation]");
    if (select.value && counts.get(select.value) > 1) {
      status.textContent = `${select.value} is assigned more than once.`;
      status.classList.add("validation-error");
    } else {
      status.textContent = select.value
        ? `Assigned to ${select.value}.`
        : status.dataset.unmappedMessage;
      status.classList.toggle("validation-error", !select.value);
    }
  }
}

function renderAssignments() {
  const files = Array.from(fileInput.files || []);
  identificationRequest += 1;
  setTableHeadings();
  assignmentRows.replaceChildren();
  if (!files.length) {
    showEmptyState(isSuperDAQ() ? "Select one SuperDAQ .xlsx export." : "Select files to assign Data Loggers.");
    return;
  }
  if (isSuperDAQ() && files.length !== 1) {
    showEmptyState("Select exactly one SuperDAQ .xlsx export.");
    return;
  }
  for (const file of files) {
    const row = document.createElement("tr");
    const nameCell = document.createElement("td");
    nameCell.textContent = file.name;
    const formatCell = document.createElement("td");
    const supported = isSuperDAQ()
      ? file.name.toLowerCase().endsWith(".xlsx")
      : file.name.toLowerCase().endsWith(".xls");
    formatCell.textContent = supported
      ? (isSuperDAQ() ? "Fluke SuperDAQ .xlsx" : "Report_Table .xls")
      : "Unsupported";
    const validationCell = document.createElement("td");
    validationCell.dataset.validation = "true";
    validationCell.textContent = supported ? "Pending server validation" : "Unsupported format";
    const assignmentCell = document.createElement("td");
    const select = document.createElement("select");
    select.name = "assignments";
    select.required = true;
    const prompt = document.createElement("option");
    prompt.value = "";
    prompt.textContent = "Select Data Logger code";
    select.append(prompt);
    const combined = modeSelect.value === "temperature_and_humidity";
    for (const device of devices) {
      if (!device.temperature_eligible || (combined && !device.humidity_eligible)) continue;
      const option = document.createElement("option");
      option.value = device.equipment_code;
      option.textContent = device.equipment_code;
      select.append(option);
    }
    assignmentCell.append(select);
    const removeCell = document.createElement("td");
    if (!isSuperDAQ()) {
      const removeButton = document.createElement("button");
      removeButton.type = "button";
      removeButton.className = "text-link remove-file";
      removeButton.textContent = "Remove";
      removeButton.setAttribute("aria-label", `Remove ${file.name}`);
      removeButton.addEventListener("click", () => {
        const replacement = new DataTransfer();
        for (const currentFile of Array.from(fileInput.files)) {
          if (currentFile !== file) replacement.items.add(currentFile);
        }
        fileInput.files = replacement.files;
        renderAssignments();
      });
      removeCell.append(removeButton);
    }
    row.append(nameCell, formatCell, validationCell, assignmentCell, removeCell);
    assignmentRows.append(row);
  }
  identifySelectedFiles(files);
}

function updateAcquisitionSystem() {
  const superdaq = isSuperDAQ();
  modeField.classList.toggle("hidden", superdaq);
  kitField.classList.toggle("hidden", !superdaq);
  humidityField.classList.toggle("hidden", superdaq || modeSelect.value !== "temperature_and_humidity");
  const humidityInputs = humidityField.querySelectorAll("input");
  for (const input of humidityInputs) {
    input.required = !superdaq && modeSelect.value === "temperature_and_humidity";
  }
  modeSelect.value = superdaq ? "temperature" : modeSelect.value;
  fileInput.accept = superdaq ? ".xlsx" : ".xls";
  fileInput.multiple = !superdaq;
  fileLabel.textContent = superdaq ? "Select one SuperDAQ Excel export" : "Select multiple logger files";
  uploadHelp.textContent = superdaq
    ? "Upload one Fluke SuperDAQ .xlsx export. Detected channel names are shown separately from their registered sensor assignments."
    : "Select all logger files in one batch, then choose the matching Data Logger code for each file below. Files are temporary and removed after processing.";
  renderAssignments();
}

fileInput.addEventListener("change", renderAssignments);
kitSelect.addEventListener("change", renderAssignments);
acquisitionSelect.addEventListener("change", updateAcquisitionSystem);
modeSelect.addEventListener("change", () => {
  humidityField.classList.toggle("hidden", modeSelect.value !== "temperature_and_humidity");
  const humidityInputs = humidityField.querySelectorAll("input");
  for (const input of humidityInputs) input.required = modeSelect.value === "temperature_and_humidity";
  renderAssignments();
});
studyForm.addEventListener("submit", (event) => {
  if (isSuperDAQ()) {
    const selectedCodes = Array.from(
      assignmentRows.querySelectorAll("select[name='sensor_assignments']"),
      (select) => select.value,
    );
    const kit = selectedKit();
    const analysisDate = studyStart.value.slice(0, 10);
    const expired = (kit ? kit.sensors : []).filter((sensor) =>
      selectedCodes.includes(sensor.sensor_code) && sensor.due_date && sensor.due_date < analysisDate
    );
    if (!expired.length || confirmationField.value === "confirmed") return;
    event.preventDefault();
    const details = expired.map((sensor) =>
      `${sensor.sensor_code} (Serial ${sensor.serial_number || "not recorded"}), due ${sensor.due_date}`
    ).join("\n");
    if (window.confirm(
      `The following calibration certificates expired before the study date:\n\n${details}\n\nProceed? This confirmation does not establish metrological suitability.`
    )) {
      confirmationField.value = "confirmed";
      studyForm.requestSubmit(event.submitter);
    }
    return;
  }
  const selectedCodes = Array.from(assignmentRows.querySelectorAll("select[name='assignments']"), (select) => select.value);
  const analysisDate = studyStart.value.slice(0, 10);
  const expired = devices.filter((device) =>
    selectedCodes.includes(device.equipment_code)
    && device.due_date
    && device.due_date < analysisDate
  );
  if (!expired.length || confirmationField.value === "confirmed") return;
  event.preventDefault();
  const details = expired.map((device) =>
    `${device.equipment_code} (Serial ${device.serial_number || "not recorded"}), due ${device.due_date}`
  ).join("\n");
  const accepted = window.confirm(
    `The following calibration certificates expired before the study date:\n\n${details}\n\nProceed? This confirmation does not establish metrological suitability.`
  );
  if (accepted) {
    confirmationField.value = "confirmed";
    studyForm.requestSubmit(event.submitter);
  }
});
updateAcquisitionSystem();
